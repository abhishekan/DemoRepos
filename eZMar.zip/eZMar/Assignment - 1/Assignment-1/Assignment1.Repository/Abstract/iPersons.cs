﻿using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Abstract
{
    interface iPersons
    {
        void i_AddPerson(PERSON person);
        IEnumerable<PERSON> i_displayPerson();
        PERSON i_findPersonById(int id);
        void i_updatePersonById(PERSON person);
        void i_RemovePersonById(int id);
        IEnumerable<PERSON> i_searchPersonByTitle(string name);
    }
}
