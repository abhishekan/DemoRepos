﻿using Assignment1.Repository.Abstract;
using Assignment1.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1.Repository.Concrete
{
    public class Employees : iEmployees
    {
        Assignment1Entities context = new Assignment1Entities();

        //Method for ADDING a Employee.
        public void i_AddEmployee(EMPLOYEE employee)
        {
            context.EMPLOYEES.Add(employee);
            context.SaveChanges();
        }


        //Method for DISPLAYING ALL the Employees.
        public IEnumerable<EMPLOYEE> i_displayEmployee()
        {
            return context.EMPLOYEES.ToList();
        }


        //Method for DISPLAYING the Employees by id.
        public EMPLOYEE i_findEmployeeById(int id)
        {
            return context.EMPLOYEES.Find(id);
        }


        //Method for UPDATING the Employee by id.
        public void i_updateEmployeeById(EMPLOYEE OldEmployeeDetails)
        {
            EMPLOYEE NewEmployeeDetails = i_findEmployeeById(OldEmployeeDetails.Id);

            NewEmployeeDetails.Id = OldEmployeeDetails.Id;
            NewEmployeeDetails.JoiningDate = OldEmployeeDetails.JoiningDate;
            NewEmployeeDetails.TerminationDate = OldEmployeeDetails.TerminationDate;

            context.SaveChanges();
        }


        //Method for DELETING the Employee by id.
        public void i_RemoveEmployeeById(int id)
        {
            EMPLOYEE company = context.EMPLOYEES.Find(id);
            context.EMPLOYEES.Remove(company);
            context.SaveChanges();
        }


        //Method for SEARCHING the Employee by Name.
        public IEnumerable<EMPLOYEE> i_searchEmployeeByTitle(string name)
        {
            IEnumerable<EMPLOYEE> search = context.EMPLOYEES.Where(p => p.Title.Contains(name));
            return search;
        }

    }
}
