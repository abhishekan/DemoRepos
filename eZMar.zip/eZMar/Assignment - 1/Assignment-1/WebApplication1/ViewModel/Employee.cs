﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignmnet1.ViewModel
{
    public class Employee
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int CompanyId { get; set; }
        public int PersonId { get; set; }
        public bool Active { get; set; }
        public System.DateTime JoiningDate { get; set; }
        public Nullable<System.DateTime> TerminationDate { get; set; }
        public string CompanyEmailAddress { get; set; }

        public string Name { get; set; }
        public string Address { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address_Street { get; set; }
        public string Address_City { get; set; }
        public string Address_Zip { get; set; }
        public string Address_State { get; set; }
        public string Address_Country { get; set; }
        public string EmailAddress { get; set; }
        public string CellPhone { get; set; }
    }
}