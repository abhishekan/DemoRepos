﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EventDelegateFileConsoleDemo
{
    //delegate..
     public delegate void WritingDelegate();

     class EventDelegateDemo
    {
        //method for writing into the file...
        public static void Writingintofile()
        {
            using (FileStream file = new FileStream(@"D:\Anand.txt", FileMode.OpenOrCreate))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    writer.Write("Abhishek Anand");
                    Console.WriteLine("Writing Into File Through Delegate is done. . .");
                    Console.ReadLine();
                }
            } 
                    
        }

        //method for reading from the file...
        public static void Readingfromfile()
        {

            using (FileStream fs = new FileStream(@"D:\Anand.txt", FileMode.OpenOrCreate))
            {
                using (StreamReader reader = new StreamReader(fs))
                {
                    string name = reader.ReadLine();
                    Console.WriteLine("Name is :" + name);

                    Console.WriteLine("Reading from file....");
                    Console.ReadLine();
                }
            }
        }

        //method for writing into Console....
        public static void WritingintoConsole()
        {
            Console.WriteLine("Writing into Console Through Delegate. . . . . . . ");
            Console.WriteLine("Abhishek Anand");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            WritingDelegate wd1 = new WritingDelegate(Writingintofile);
            wd1();

            WritingDelegate wd2 = new WritingDelegate(Readingfromfile);
            wd2();

            WritingDelegate wd3 = new WritingDelegate(WritingintoConsole);
            wd3();
        }
    }
}
