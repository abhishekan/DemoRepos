﻿
-- Assignment - 5 :

-- Triggers

-- 5. Let’s assume that we have a table name “Book_History” table. If a particular book is deleted from the “Book” table, 
-- 	  an entry with same book records to “Book_History” table must take place. Automate this process using trigger.

CREATE TABLE BOOK_HISTORY(

	BookId int NOT NULL,
	Title char(50),
	Description char(50),
	Price bigint,
	ISBN bigint,
	PublicationDate date,
	Image char(100),
	B_Cid int,
	B_Pid int
)
ALTER TABLE BOOK_HISTORY ADD CONSTRAINT pk_BookId PRIMARY KEY (BookId)
 

CREATE TRIGGER uspDELETE
ON BOOK
FOR DELETE
AS
DECLARE @ID INT,
		@BOOKNAME VARCHAR(20),
		@BOOKDESC VARCHAR(20),
		@BOOKPRICE INT,
		@BOOKISBN INT,
		@BOOKPUBDATE DATE,
		@IMAGE VARCHAR(50),
		@B_CID int,
		@B_PID int 

 BEGIN
	SELECT @ID = BookId,
		@BOOKNAME = Title,
		@BOOKDESC = Description,
		@BOOKPRICE = Price,
		@BOOKISBN = ISBN,
		@BOOKPUBDATE = PublicationDate,
		@IMAGE = Image,
		@B_CID = B_Cid,
		@B_PID = B_Pid
	FROM DELETED

	INSERT INTO BOOK_HISTORY (BookId, Title, Description, Price, ISBN, PublicationDate)
	VALUES (@ID, @BOOKNAME, @BOOKDESC, @BOOKPRICE, @BOOKISBN, @BOOKPUBDATE)
END

DELETE FROM BOOK WHERE BookId = 2

SELECT * FROM BOOK
SELECT * FROM BOOK_HISTORY



-- 6. The “Book” table got an attribute “Price”. Let’s assume that we have a business requirement where we must ensure that the “Price” 
--		should not be less than 1. If any insert or update statement tries to make the “Price” less than 1, the SQL Server must terminate 
--		such insert or update statements. Write an appropriate trigger to implement the business requirement.

CREATE TRIGGER CHECKPRICE
ON BOOK
FOR INSERT, UPDATE
AS
BEGIN
	DECLARE @PRICE INT
	SELECT @PRICE = Price FROM INSERTED
	
	IF @PRICE < 1
		BEGIN
			ROLLBACK
			PRINT 'Price should not be less than 1.'
		END
	ELSE
		BEGIN
			PRINT 'SUCCESSFULLY INSERTED'
		END
END

INSERT INTO BOOK (Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Dot Net', 'Dot_Net_Description', 0, 10767, '11-21-2016', 'C:\Users\omkarpa\Pictures\Dot_Net.jpeg', 1, 3)




-- 7. Create a trigger on the table “Order” and add the following functionalities. When a new order is placed, it should check whether
--	the required quantity is available in the “Book” table. If not, it should show appropriate message and the insert statement to 
--	“Order” table should be terminated. If the quantity in book table is sufficient, it should deduct the quantity ordered from the 
--	quantity in hand in the book table and update the quantity.

ALTER TABLE BOOK
ADD Available_Book INT

SELECT * FROM BOOK

UPDATE  BOOK SET Available_Book = 10 WHERE BookId = 1
UPDATE  BOOK SET Available_Book = 20 WHERE BookId = 2

CREATE TRIGGER Check_Order
ON [ORDER] 
FOR INSERT
AS
BEGIN
	DECLARE @avilabelbooks INT, @bookid INT, @Quantity INT
	
	SELECT @bookid = O_Bid, @Quantity = Quantity FROM INSERTED
	SELECT @avilabelbooks = Available_Book FROM BOOK WHERE BookId = @bookid
	
	IF @avilabelbooks < @Quantity
		BEGIN
			ROLLBACK
			PRINT'Book Out Of Stock !!'
		END
	ELSE
		BEGIN
			PRINT'Book is Availabe !!'
			PRINT'Your Order is Placeced !!'
			UPDATE BOOK SET Available_Book = Available_Book - @Quantity
		END
END

INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('05-01-2013', 17, 9000, 'Mumbai', 1)
INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('06-02-2015', 7, 8000, 'Delhi', 1)
