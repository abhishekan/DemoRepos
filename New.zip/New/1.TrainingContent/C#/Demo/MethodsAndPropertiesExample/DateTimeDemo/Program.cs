﻿using System;


namespace DateTimeDemo
{
    class Program
    {
        static void Main(string[] args)
        {               
            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.Now.ToShortDateString());
            Console.WriteLine(DateTime.Now.ToLongDateString());
            Console.WriteLine(DateTime.Now.ToLongTimeString());
            Console.WriteLine(DateTime.Now.ToShortTimeString());
            Console.WriteLine(DateTime.Now.Year);
            Console.WriteLine(DateTime.Now.Month);
            Console.WriteLine(DateTime.Now.AddYears(1));

            DateTime dt = new DateTime(2017, 07, 20);
            Console.WriteLine(dt.Year);
        }
    }
}
