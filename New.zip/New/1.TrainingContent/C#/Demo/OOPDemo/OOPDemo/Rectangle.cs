﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    class Rectangle : Shape
    {
        public Rectangle()
        {

        }

        public Rectangle(int l, int b) : base(l, b)
        {
            //Console.WriteLine("Rectangle.Constructor is called");
        }

        public void CalculateArea()
        {
            Console.WriteLine("Rectangle.CalculateArea called");
        }
    }
}
