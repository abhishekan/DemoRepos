﻿using MyProductStore.Core;
using System.Collections.Generic;

namespace MyProductStore.Repository.Abstract
{
    interface ICustomerRepository
    {
        IEnumerable<Customer> GetCustomers();

        //here customer is taken as return type because we have to edit and enter the values and get
        // all the feautures of Customer
        Customer GetCustomerById(int id);

        //here void type is used becausewe don't want to return as such any value jsut view the result
        void SaveCustomer(Customer customer);

        //same as for the Customerid
        Customer DeleteCustomer(int id);
    }
}
