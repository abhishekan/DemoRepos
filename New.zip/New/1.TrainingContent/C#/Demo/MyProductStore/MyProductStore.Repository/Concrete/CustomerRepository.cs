﻿using MyProductStore.Core;
using MyProductStore.Repository.Abstract;
using System.Collections.Generic;
using System.Linq;

namespace MyProductStore.Repository.Concrete
{
    public class CustomerRepository : ICustomerRepository
    {
        private static List<Customer> db = new List<Customer>()
        {
            new Customer{ CustomerId=1, Name="Sachin", City="Mumbai"},
            new Customer{ CustomerId=2, Name="Dhoni", City="Ranchi"}
        };

        public IEnumerable<Customer> GetCustomers()
        {
            return db.ToList();
        }

        public Customer GetCustomerById(int id)
        {
            Customer c = db.Find(cu => cu.CustomerId == id);
            return c;
        }

        public void SaveCustomer(Customer customer)
        {
            Customer existingCustomer = null;

            if(customer != null)
            {
                existingCustomer = db.Find(c => c.CustomerId== customer.CustomerId);
            }
            if(existingCustomer != null)
            {
                db.Remove(existingCustomer);
            }
            db.Add(customer);
        }

        public Customer DeleteCustomer(int id)
        {
            Customer existingCustomer = existingCustomer = db.Find(c => c.CustomerId == id);
            if (existingCustomer != null)
            {
                db.Remove(existingCustomer);
            }

            return existingCustomer;
        }
    }
}
