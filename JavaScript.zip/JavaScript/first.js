a={b:"c"};
console.log(typeof a);
