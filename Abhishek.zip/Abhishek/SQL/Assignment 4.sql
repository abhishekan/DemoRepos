USE BookStoreDB

--Procedure 

CREATE PROCEDURE FirstProcedure
AS

Select b.Title as 'Book Name',a.AuthorName as 'Author Name' from Book b,Author a where b.BookId IN(select ab.BookId from AuthorBookPublisher ab where AuthorId=(select AuthorId from Author where AuthorName='Yashwant')) AND AuthorId=(select AuthorId from Author where AuthorName='Yashwant')

Select b.Title as 'Book Name',a.AuthorName as 'Author Name',p.PublisherName as 'Publisher Name' from Book b,Author a,Publisher p where a.AuthorId=(select AuthorId from Author where AuthorName='Robin_Sharma') AND p.PublisherId=(select PublisherId from Publisher where PublisherName='Robin_Sharma')  AND CategoryId=(select CategoryId from Category where CategoryName='NonTechnical')
Select PublisherId as 'Publisher Id',COUNT(BookId) as 'Total no. of books published' from Book group by PublisherId

INSERT INTO Book(Title,Description,Price,ISBN,PublicationDate,Image,CategoryId,PublisherId)
VALUES('Sherlock Holmes','Adventures',250,9440,'3-09-95','d',1,1)
UPDATE Book
SET Title='CPP Book'
WHERE BookId=18
DELETE FROM Book 
WHERE BookId=20


EXECUTE FirstProcedure
 



