--Creating Database

CREATE DATABASE BookStoreDB

USE BookStoreDB


--Creating Tables

CREATE TABLE Author
(
  AuthorId INT PRIMARY KEY IDENTITY(1,1),
  AuthorName CHAR(20) NOT NULL,
  DateOfBirth DATE,
  StateName CHAR(20) NOT NULL,
  City CHAR(20) NOT NULL,
  Phone BIGINT NOT NULL,
)

CREATE TABLE Publisher
(
  PublisherId INT PRIMARY KEY IDENTITY(1,1),
  PublisherName CHAR(20) NOT NULL,
  StateName CHAR(20) NOT NULL,
  City CHAR(20) NOT NULL,
  Phone BIGINT NOT NULL,
)
Drop Table Category

CREATE TABLE Category
(
  CategoryId INT PRIMARY KEY IDENTITY(1,1),
  CategoryName CHAR(20) NOT NULL,
  Description CHAR(50) NOT NULL,
 
)


CREATE TABLE Book
(
  BookId INT PRIMARY KEY IDENTITY(1,1),
  Title CHAR(20) NOT NULL,
  Description CHAR(20) NOT NULL,
  Price INT NOT NULL,
  ISBN INT NOT NULL,
  PublicationDate DATE,
  Image VARCHAR,
)


CREATE TABLE Orders(
	OrderId INT PRIMARY KEY IDENTITY(1,1),
	Date DATE,
	Quantity INT,
	UnitPrice INT,
	ShippingAddress VARCHAR(100)
)


--JUNCTION TABLE FOR MANY TO MANY RELATIONSHIP

CREATE TABLE AuthorBook(
	AuthorId INT NOT NULL,
	BookId INT NOT NULL
)

CREATE TABLE AuthorBookPublisher(
	AuthorId INT NOT NULL,
	BookId INT NOT NULL,
	PublisherId INT NOT NULL
)


--COLUMN ADDED

ALTER TABLE Book
ADD CategoryId INT,PublisherId INT
 

 SELECT * FROM Book

 
ALTER TABLE Orders
ADD BookId INT, CategoryId INT



ALTER TABLE Author
ADD BookId INT


--FOREIGN KEY

ALTER TABLE Book
ADD CONSTRAINT fk_ctId FOREIGN KEY(CategoryId) REFERENCES Category(CategoryId) ,
CONSTRAINT fk_pbId FOREIGN KEY(PublisherId) REFERENCES Publisher(PublisherId) 


ALTER TABLE AuthorBook
ADD CONSTRAINT fk_AbId FOREIGN KEY(AuthorId) REFERENCES Author(AuthorId) ,
CONSTRAINT fk_BaId FOREIGN KEY(BookId) REFERENCES Book(BookId) 

USE BookStoreDB


ALTER TABLE Orders
ADD CONSTRAINT fk_BoId FOREIGN KEY(BookId) REFERENCES Book(BookId)


ALTER TABLE Author
ADD CONSTRAINT fk_AkId FOREIGN KEY(BookId) REFERENCES Book(BookId)  



Alter TABLE AuthorBookPublisher
ADD CONSTRAINT fk_AId FOREIGN KEY(AuthorId) REFERENCES Author(AuthorId),
 CONSTRAINT fk_BId FOREIGN KEY(BookId) REFERENCES Book(BookId), 
 CONSTRAINT fk_pId FOREIGN KEY(PublisherId) REFERENCES Publisher(PublisherId) 





--INSERTING DATA IN EACH TABLES


--Book Table


INSERT INTO Category(CategoryName,Description) 
VALUES('Technical','Technical Books')

INSERT INTO Category(CategoryName,Description) 
VALUES('NonTechnical','Non Technical Books')


SELECT *FROM Category

INSERT INTO Publisher(PublisherName,StateName,City,Phone) 
VALUES('MC GRAW HILLS','Maharashtra','Gondia',909090870)



INSERT INTO Publisher(PublisherName,StateName,City,Phone) 
VALUES('NIRALI GROUPS','Karnataka','Banglore',909090110)

SELECT *FROM Publisher


INSERT INTO Book(Title,Description,Price,ISBN,PublicationDate,Image,CategoryId,PublisherId) 
VALUES('LET US C','C Reference',200,9870,'3-09-85','c',1,1)



INSERT INTO Book(Title,Description,Price,ISBN,PublicationDate,Image,CategoryId,PublisherId) 
VALUES('The Secretes','Nyc book',300,9890,'3-09-85','d',2,2)



INSERT INTO Author(AuthorName,DateOfBirth,StateName,City,Phone,BookId) 
VALUES('Yashwant','13-JAN-94','Maharashtra','Nagpur',9890820109,18)

INSERT INTO Author(AuthorName,DateOfBirth,StateName,City,Phone,BookId) 
VALUES('Robin_Sharma','13-FEB-94','Maharashtra','Nagpur',9890820109,19)

INSERT INTO Orders(Date,Quantity,UnitPrice,ShippingAddress,BookId,CategoryId) 
VALUES('13-FEB-05',10,500,'PUNE',18,1)

INSERT INTO Orders(Date,Quantity,UnitPrice,ShippingAddress,BookId,CategoryId) 
VALUES('13-APR-05',12,600,'MUMBAI',19,2)



INSERT INTO AuthorBook(AuthorId,BookId) 
VALUES(7,18)

INSERT INTO AuthorBook(AuthorId,BookId) 
VALUES(8,19)

SELECT * FROM AuthorBook

INSERT INTO AuthorBookPublisher(AuthorId,BookId,PublisherId) 
VALUES(7,18,1)


INSERT INTO AuthorBookPublisher(AuthorId,BookId,PublisherId) 
VALUES(8,19,2)



--1st query
Select b.Title as 'Book Name',a.AuthorName as 'Author Name' from Book b,Author a where b.BookId IN(select ab.BookId from AuthorBookPublisher ab where AuthorId=(select AuthorId from Author where AuthorName='Yashwant')) AND AuthorId=(select AuthorId from Author where AuthorName='Yashwant')

--2nd query
Select b.Title as 'Book Name',a.AuthorName as 'Author Name',p.PublisherName as 'Publisher Name' from Book b,Author a,Publisher p where a.AuthorId=(select AuthorId from Author where AuthorName='Robin_Sharma') AND p.PublisherId=(select PublisherId from Publisher where PublisherName='Robin_Sharma')  AND CategoryId=(select CategoryId from Category where CategoryName='NonTechnical')

--3rd query
Select PublisherId as 'Publisher Id',COUNT(BookId) as 'Total no. of books published' from Book group by PublisherId

--4th query
Select b.Title as 'Book Name',o.Quantity 'Quantity' from  Book b,Orders o where b.BookId=o.BookId

select * from Book
select *from Category