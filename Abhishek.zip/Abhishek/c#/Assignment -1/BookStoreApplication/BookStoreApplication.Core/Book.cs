﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreApplication.Core
{
    public class Book
    {
      
         int bookId;
         string category;
         string title;
         string author;
         string publisher;
         string description;
         float price;
         string isbn;
         string publicationDate;

         

        public Book(int bookId,string category,string title,string author,string publisher,string description,float price,string isbn,string publicationDate)
        {
           this.BookId=bookId;
           this.Category=category;
           this.Title=title;
           this.Author=author;
           this.Publisher=publisher;
           this.Description=description;
           this.Price=price;
           this.ISBN=isbn;
           this.PublicationDate = publicationDate;
                
        }



        public int BookId { get; set; }
        public string Category { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public string Description { get; set; }
        public float Price { get; set; }
        public string ISBN { get; set; }
        public string PublicationDate { get; set; }
    }


}


 