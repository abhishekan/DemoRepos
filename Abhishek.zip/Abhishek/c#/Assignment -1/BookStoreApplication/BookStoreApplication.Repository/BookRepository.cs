﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApplication.Core;

namespace BookStoreApplication.Repository
{
    public class BookRepository
    {
        int bookId;
        string category;
        string title;
        string author;
        string publisher;
        string description;
        float price;
        string isbn;
        string publicationDate;

        List<Book> bookList = new List<Book>();
        public void AddBook()
        {
 
            Console.WriteLine();
            Console.WriteLine("Enter the book id:");
            //int id = int.Parse(Console.ReadLine());
            if (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");

            }

            Console.WriteLine("Enter the book Category:");
            string category = Console.ReadLine();

            Console.WriteLine("Enter the book Name:");
            string title = Console.ReadLine();

            Console.WriteLine("Enter the book Author:");
            string author = Console.ReadLine();

            Console.WriteLine("Enter the book Publication:");
            string publisher = Console.ReadLine();

            Console.WriteLine("Enter the book Description:");
            string description = Console.ReadLine();

            Console.WriteLine("Enter the book Price:");
            //float pric = float.Parse(Console.ReadLine());
            if (!float.TryParse(Console.ReadLine(), out price))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");

            }

            Console.WriteLine("Enter the book ISBN:");
            string isbn = Console.ReadLine();

            Console.WriteLine("Enter the publication date:");
            string publicationDate = Console.ReadLine();

            Book b1 = new Book(bookId, category, title, author, publisher, description, price, isbn, publicationDate);
            bookList.Add(b1);

            Console.WriteLine();
            Console.WriteLine("Book is Added");

        }
            public void displayBook()
            {
                    foreach (Book b in bookList)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Book id:{0}, Category :{1}, Book Name:{2}, Author:{3}, Publication:{4}, Description:{5}, Price:{6} ,ISBN:{7} , PDate:{8}", b.BookId, b.Category, b.Title,b.Author, b.Publisher, b.Description, b.Price, b.ISBN, b.PublicationDate);

                    }
            }


            public void findBookById()
            {
                Console.WriteLine();
                Console.Write("Enter the book id to be searched: ");
                int f=int.Parse(Console.ReadLine());
                Book b2=bookList.Find(findBook => findBook.BookId==f);
                Console.WriteLine("Book id:{0}, Category :{1}, Book Name:{2}, Publication:{3}, Description:{4}, Price:{5} ,ISBN:{6} , PDate:{7}", b2.BookId, b2.Category, b2.Title, b2.Publisher, b2.Description, b2.Price, b2.ISBN, b2.PublicationDate);
            }

            public void updateBookById()
            {
                try
                {
                    Console.WriteLine();
                    Console.Write("Enter the book id to be updated: ");
                    int f = int.Parse(Console.ReadLine());
                    Book b2 = bookList.Find(findBook => findBook.BookId == f);
                    Console.WriteLine("Press 1 to update Publisher\nPress 2 to update PublicationDate\nPress 3 to update Price\n");

                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: Console.WriteLine("Enter the publisher name:");
                            b2.Publisher = Console.ReadLine();
                            bookList.RemoveAt(f - 1);
                            bookList.Add(b2);
                            break;
                        case 2:
                            Console.WriteLine("Enter the PublicationDate:");
                            b2.PublicationDate = Console.ReadLine();
                            bookList.RemoveAt(f - 1);
                            bookList.Add(b2);
                            break;
                        case 3:
                            Console.WriteLine("Enter the Price:");
                            b2.Price = float.Parse(Console.ReadLine());
                            bookList.RemoveAt(f - 1);
                            bookList.Add(b2);
                            break;

                    }
                    Console.WriteLine("Book is updated. . . ");
                }

                catch (Exception ex)
                {
                    Console.WriteLine("Invalid id. . .", ex.Message);
                }
            }

            public void RemoveById()
            {
                Console.WriteLine();
                Console.WriteLine("Enter the book id to be Deleted:");
                int f = int.Parse(Console.ReadLine());
               // Book b2 = bookList.Find(findBook => findBook.BookId == f);

                bookList.RemoveAt(f-1);
                Console.WriteLine("Book is removed. . . ");
 
            }
        }
}


   