﻿
/*Use the “BookStoreApp” and create your static data store using Generic Collections. Create multiple Book objects and store using collection. Write methods to support all
the operations against the collection based on the below menu. The program should display a menu as following pattern to the user. According to user’s choice the program should perform a specific operation and display appropriate output.
============================
Main Menu
============================
1. Adding new books
2. Displaying all books
3. Displaying a book by BookId
4. Updating a book by BookId
5. Deleting a book by BookId
6. Exit
Enter Your Choice (any number from 1 to 6)*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApplication.Repository;

namespace BookStoreApplication.ConsoleUI
{
    class Program
    {
        
        static void Main(string[] args)
        {
            BookRepository res = new BookRepository();
            int i;
            do
            {
                Console.WriteLine("                       MAIN MENU ");
                Console.WriteLine("1. Adding new books\n2. Displaying all books\n3. Displaying a book by BookId\n4. Updating a book by BookId\n5. Deleting a book by BookId\n6. Exit\nEnter Your Choice (any number from 1 to 6)");
                if (!int.TryParse(Console.ReadLine(), out i))
                {
                    Console.WriteLine("Invalid Option.......");

                }


                switch (i)
                {
                    case 1: res.AddBook();
                        break;

                    case 2: res.displayBook();
                        break;

                    case 3: try
                            {
                                res.findBookById();
                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine("Invalid id. . .",  ex.Message);
                            }
                        break;

                    case 4: 
                                res.updateBookById();                

                        break;

                    case 5: try
                            {
                                res.RemoveById();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Invalid id. . .", ex.Message);
                            }
                        break;

                    case 6: Console.WriteLine("Exit. . .");
                        break;
                    //default:
                    //    Console.WriteLine("Invalid option. . . ");
                    //    break;


                }
            } while(true);

           
            Console.ReadLine();

        }
    }
}
