﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BinaryFileDemoApplication
{
    class BinaryFileDemo
    {
        static void Main(string[] args)
        {

            //writing the data into file in the binary format
	        using (FileStream fs = new FileStream(@"D:\Abhishek.bin", FileMode.OpenOrCreate))
            {                
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    writer.Write("Abhishek Anand");
                    Console.WriteLine("Writing is done in the file in the binary format....");
                    Console.ReadLine();
                }
            }


            //reading the data from the file into the console....
            using (FileStream fs = new FileStream(@"D:\Abhishek.bin", FileMode.OpenOrCreate))
            {
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    string name = reader.ReadString();
					Console.WriteLine("Name is :" + name);

                    Console.WriteLine("Reading from file....");
					Console.ReadLine();	
                }
            }
        }
    }
}
