﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadDemo
{
    class ThreadDemo
    {
        public static float balance = 1000;
        static Object obj = new Object();

        public static void doTransaction()
        {
            lock(obj)
            {
                Thread.Sleep(1000);
                balance -= 100;
                Console.WriteLine(Thread.CurrentThread.Name + ":  "+ balance);   
            }
        }

        static void Main(string[] args)
        {
            Thread []emp = new Thread[10];            

            for(int i=0;i<=9;i++)
            {
                Thread t = new Thread(doTransaction);
                emp[i] = t;
                emp[i].Name = "Emp " + i;                
            }

            emp[0].Start();
            emp[1].Start();
            emp[2].Start();
            emp[3].Start();
            emp[4].Start();
            emp[5].Start();
            emp[6].Start();
            emp[7].Start();
            emp[8].Start();
            emp[9].Start();
      
            Console.ReadLine();
        }
    }
}
