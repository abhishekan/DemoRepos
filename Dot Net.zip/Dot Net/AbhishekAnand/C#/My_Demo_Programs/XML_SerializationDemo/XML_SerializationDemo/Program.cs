﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XML_SerializationDemo
{
    [Serializable]
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
    }

     class MySerializer
    {
        //creating formatter to serialize object  using XML serializer

         XmlSerializer xm = new XmlSerializer(typeof(List<Employee>));

        public void SerializeEmployee()
        {
            //opening or creating a file to store serialized object
            List<Employee> empList = new List<Employee>()       
            {
                new Employee(){ EmployeeId = 1, Name = "Abhishek"},
                new Employee(){ EmployeeId = 2, Name = "Anand"}
            };

            using (TextWriter stream = new StreamWriter(@"D:\Demo\Abhishek.xml"))
            {
                //serializing employee list object
                try
                {
                    xm.Serialize(stream, empList);
                    Console.WriteLine("List of Employee serialized and stored in the hard disk in binary format. . .\n");
                }
                catch (System.Runtime.Serialization.SerializationException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void DeserializeEmployee()
        {
            //opening or creating a file to store serialized object
            List<Employee> empList2 = new List<Employee>();

            using (TextReader stream = new StreamReader(@"D:\Demo\Abhishek.xml"))
            {
                try
                {
                    //deserializing employee list object
                    empList2 = (List<Employee>)xm.Deserialize(stream);

                    foreach (Employee e in empList2)
                    {
                        Console.WriteLine("Employee Id : {0}", e.EmployeeId);
                        Console.WriteLine("Name : {0}", e.Name);
                        Console.ReadLine();
                    }
                }
                catch (System.Runtime.Serialization.SerializationException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }

    class XML_SerializationDemo
    {
        static void Main(string[] args)
        {
            MySerializer ms = new MySerializer();
            ms.SerializeEmployee();
            ms.DeserializeEmployee();
        }
    }
}

