﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Repository;
using BookStoreApp.Core;

namespace BookStoreApp.UI
{
    class bookManager
    {
        BookRepository br = new BookRepository();

        int bookId;
        float price;
        DateTime publicationDate;
        int CategoryId;
        int PublisherId;


        //Method for ADDING a Book.
        public void AddBook()
        {
            Console.Write("\nEnter the number of books want to add: ");
            int number;

            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            for (int i = 0; i < number; i++)
            {
                Book b = new Book();

                Console.Write("\nEnter the book id:          ");
                while (!int.TryParse(Console.ReadLine(), out bookId))
                {
                    Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                }                               
                b.BookId = bookId;               

                Console.Write("Enter the book Category:    ");
                b.Category = Console.ReadLine();

                Console.Write("Enter the book Name:        ");
                b.Title = Console.ReadLine();

                Console.Write("Enter the book Author:      ");
                b.Author = Console.ReadLine();

                Console.Write("Enter the book Publication: ");
                b.Publisher = Console.ReadLine();

                Console.Write("Enter the book Description: ");
                b.Description = Console.ReadLine();


                //goto label for price.    
            enter_price_again:
                Console.Write("Enter the book Price:       ");
                while (!float.TryParse(Console.ReadLine(), out price))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                    goto enter_price_again;
                }                
                
                try
                {
                    if (price <= 0)
                    {
                         throw new BookRepository();   //handled by Custom Exception.
                    }

                    else
                    {
                         b.Price = price;
                    }
                 }
                 catch (Exception ex)
                 {
                        Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                        goto enter_price_again;

                 }               

                Console.Write("Enter the book ISBN:        ");
                b.ISBN = Console.ReadLine();


                //goto label for publication date.
            enter_pDate_again:
                Console.Write("Enter the publication date: ");
                if (!DateTime.TryParse(Console.ReadLine(), out publicationDate))
                {
                    Console.WriteLine("\nInvalid Date Type. . .\n");
                    goto enter_pDate_again;
                }
                else
                {
                    b.PublicationDate = publicationDate;
                }

                Console.Write("Enter the Category id:      ");
                while (!int.TryParse(Console.ReadLine(), out CategoryId))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");                   
                }
                b.CategoryId = CategoryId;

                Console.Write("Enter the Publisher id:     ");
                while (!int.TryParse(Console.ReadLine(), out PublisherId))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                }
                b.PublisherId = PublisherId;

                //all the entities of a book_Object are added to List. 
                br.i_AddBook(b);
                Console.WriteLine("\nBook is Added. . . ");
            }
        }




        //Method for DISPLAYING ALL the Books
        public void displayBook()
        {
            try
            {
                IEnumerable<Book> bookList = br.i_displayBook();
                foreach (Book b in bookList)
                {
                    Console.WriteLine("\n. Book id:     {0}\n, Category:    {1}\n, Book Name:   {2}\n, Author:      {3}\n, Publication: {4}\n, Description: {5}\n, Price:       {6}\n, ISBN:        {7}\n, PDate:       {8}\n, Category id: {9}\n, PublisherId: {10}\n", b.BookId, b.Category, b.Title, b.Author, b.Publisher, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
                }
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("Book not available. . .");
            }

        }





        //Method for DISPLAYING the Books by id.
        public void findBookById()
        {
            Console.Write("\nEnter the book id to be searched: ");

            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            try
            {
                Book b = br.i_findBookById(bookId);

                Console.WriteLine("\n. Book id:     {0}\n, Category:    {1}\n, Book Name:   {2}\n, Author:      {3}\n, Publication: {4}\n, Description: {5}\n, Price:       {6}\n, ISBN:        {7}\n, PDate:       {8}\n, Category id: {9}\n, PublisherId: {10}\n", b.BookId, b.Category, b.Title, b.Author, b.Publisher, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("Book with Id={0} Not Available in Book Store", bookId);
            }
        }





        //Method for UPDATING the book by id.
        public void updateBookById()
        {
            Console.Write("\nEnter the book id to be updated: ");
            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            Book b = br.i_updateBookById(bookId);

            if (b == null)
            {
                Console.WriteLine("Book with Id={0} Not Available in Book Store to update", bookId);
            }

            else
            {
                Console.WriteLine("Press 1 to Update Publisher\nPress 2 to Update PublicationDate\nPress 3 to Update Price\n");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1: Console.Write("Enter the publisher name: ");
                        b.Publisher = Console.ReadLine();
                        break;


                    case 2:
                    enter_pDate_again_update:
                        Console.Write("Enter the PublicationDate: ");
                        if (!DateTime.TryParse(Console.ReadLine(), out publicationDate))
                        {
                            Console.WriteLine("\nInvalid Date Type. . .\n");
                            goto enter_pDate_again_update;
                        }
                        else
                        {
                            b.PublicationDate = publicationDate;
                        }
                        break;


                    case 3:
                    enter_price_again_update:
                        Console.Write("Enter the Price: ");
                        if (!float.TryParse(Console.ReadLine(), out price))
                        {
                            Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
                        }
                        else
                        {
                            try
                            {
                                if (price <= 0)
                                {
                                    throw new BookRepository();   //handled by Custom Exception.
                                }
                                else
                                {
                                    b.Price = price;
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                                goto enter_price_again_update;
                            }
                        }
                        break;


                    default: Console.WriteLine("Invalid option. . .\n");
                        break;
                }
                Console.WriteLine("Book is updated. . . ");
            }
        }




        //Method for DELETING the Book by id.
        public void RemoveById()
        {
            Console.Write("\nEnter the book id to be Deleted: ");
            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            Book b = br.i_RemoveById(bookId);

            if (b == null)
            {
                Console.WriteLine("Book is not available in store");
            }
            else
            {
                Console.WriteLine("Book with id={0} is deleted", bookId);
            }
        }
    }
}

