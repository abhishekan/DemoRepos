﻿
//BookStoreApp.Core

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreApp.Core
{
	//Book Class
    public class Book
    {    
		//Automatic Properties
        public int BookId { get; set; }
        public string Category { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public string Description { get; set; }
        public float Price { get; set; }
        public string ISBN { get; set; }
        public DateTime PublicationDate { get; set; }
        public int CategoryId { get; set; }
        public int PublisherId { get; set; }
    }
}


