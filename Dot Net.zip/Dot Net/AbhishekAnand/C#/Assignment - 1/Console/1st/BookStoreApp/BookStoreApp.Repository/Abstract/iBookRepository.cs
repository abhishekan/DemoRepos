﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreApp.Repository
{
    public interface iBookRepository
    {
        void AddBook();
        void displayBook();
        void findBookById();
        void updateBookById();
        void RemoveById();
    }
}
