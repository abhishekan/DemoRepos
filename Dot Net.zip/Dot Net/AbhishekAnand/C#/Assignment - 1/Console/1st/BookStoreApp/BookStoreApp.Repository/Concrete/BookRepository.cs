﻿
//BookStoreApp.Repository

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Core;

namespace BookStoreApp.Repository
{
	//BookRepository Class
    public class BookRepository : ApplicationException, iBookRepository
    {
        int bookId;  
        float price;
        DateTime publicationDate;

		//List
        List<Book> bookList = new List<Book>();


		//Method for ADDING a Book.
        public void AddBook()
        {
            Console.Write("\nEnter the number of books want to add: ");
            int number;

            if (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }
            else 
            {
                for (int i = 0; i < number; i++)
                {
                    Book b = new Book();

                    Console.Write("\nEnter the book id:          ");
                    if (!int.TryParse(Console.ReadLine(), out bookId))
                    {
                        Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                    }
                    else
                    {
                        b.BookId = bookId;
                    }

                    Console.Write("Enter the book Category:    ");
                    b.Category = Console.ReadLine();

                    Console.Write("Enter the book Name:        ");
                    b.Title = Console.ReadLine();

                    Console.Write("Enter the book Author:      ");
                    b.Author = Console.ReadLine();

                    Console.Write("Enter the book Publication: ");
                    b.Publisher = Console.ReadLine();

                    Console.Write("Enter the book Description: ");
                    b.Description = Console.ReadLine();

                //goto label for price.    
                enter_price_again:
                    Console.Write("Enter the book Price:       ");
                    if (!float.TryParse(Console.ReadLine(), out price))
                    {
                        Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                        goto enter_price_again;
                    }
                    else
                    {
                        try
                        {
                            if (price <= 0)
                            {
                                throw new BookRepository();   //handled by Custom Exception.
                            }

                            else
                            {
                                b.Price = price;
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                            goto enter_price_again;
                            
                        }
                    }

                
                    Console.Write("Enter the book ISBN:        ");
                    b.ISBN = Console.ReadLine();

                //goto label for publication date.
                enter_pDate_again:
                    Console.Write("Enter the publication date: ");
                    if (!DateTime.TryParse(Console.ReadLine(), out publicationDate))
                    {
                        Console.WriteLine("\nInvalid Date Type. . .\n");
                        goto enter_pDate_again;
                    }
                    else
                    {
                        b.PublicationDate = publicationDate;
                    }

                    //all the entities of a book_Object are added to List. 
                    bookList.Add(b);        

                    Console.WriteLine("\nBook is Added. . . ");

                }
            }
        }





		//Method for DISPLAYING ALL the Books
        public void displayBook()
        {
            //checking whether the List is empty or not.
            if (bookList.Count == 0)
            {
                Console.WriteLine("No books to Display. . .");
            }
            else
            {
                foreach (Book b in bookList)
                {                   
                    Console.WriteLine("\n. Book id:     {0}\n, Category:    {1}\n, Book Name:   {2}\n, Author:      {3}\n, Publication: {4}\n, Description: {5}\n, Price:       {6}\n, ISBN:        {7}\n, PDate:       {8}\n", b.BookId, b.Category, b.Title, b.Author, b.Publisher, b.Description, b.Price, b.ISBN, b.PublicationDate);
                }
            }
        }





		//Method for DISPLAYING the Books by id.
        public void findBookById()
        {
            //checking whether the List is empty or not.
            if (bookList.Count == 0)
            {
                Console.WriteLine("No books to Display. . .");
            }
            else
            {
                Console.Write("\nEnter the book id to be searched: ");
                int id;
                if (!int.TryParse(Console.ReadLine(), out id))
                {
                    Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                }
                else
                {
                    Book b2 = bookList.Find(findBook => findBook.BookId == id);
                    Console.WriteLine(". Book id:     {0}\n, Category:    {1}\n, Book Name:   {2}\n, Publication: {3}\n, Description: {4}\n, Price:       {5}\n, ISBN:        {6}\n, PDate:       {7}\n", b2.BookId, b2.Category, b2.Title, b2.Publisher, b2.Description, b2.Price, b2.ISBN, b2.PublicationDate);
                }
            }
        }





		//Method for UPDATING the book by id.
        public void updateBookById()
        {
            //checking whether the List is empty or not.
            if (bookList.Count == 0)
            {
                Console.WriteLine("No books to Update. . .");
            }
            else
            {          
                    Console.Write("\nEnter the book id to be updated: ");
                    int id;
                    if (!int.TryParse(Console.ReadLine(), out id))
                    {
                        Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                    }
                    else 
                    {
                        Book b2 = bookList.Find(findBook => findBook.BookId == id);
						if(b2 == null)
						{
							Console.WriteLine("book not found. . .");
						}
						else
                        {
                            Console.WriteLine("Press 1 to Update Publisher\nPress 2 to Update PublicationDate\nPress 3 to Update Price\n");

                            int choice = int.Parse(Console.ReadLine());

                            switch (choice)
                            {
                                case 1: Console.Write("Enter the publisher name: ");
                                        b2.Publisher = Console.ReadLine();
                                        break;


                                case 2:
                                    enter_pDate_again_update:
                                        Console.Write("Enter the PublicationDate: ");
                                        if (!DateTime.TryParse(Console.ReadLine(), out publicationDate))
                                        {
                                            Console.WriteLine("\nInvalid Date Type. . .\n");
                                            goto enter_pDate_again_update;
                                        }
                                        else
                                        {
                                            b2.PublicationDate = publicationDate;
                                        }
                                        break;


                                case 3:
                                    enter_price_again_update:
                                        Console.Write("Enter the Price: ");
                                        if (!float.TryParse(Console.ReadLine(), out price))
                                        {
                                            Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
                                        }   
                                        else
                                        {
                                            try
                                            {
                                                if (price <= 0)
                                                {
                                                    throw new BookRepository();   //handled by Custom Exception.
                                                }
                                                else
                                                {
                                                    b2.Price = price;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                                                goto enter_price_again_update;
                                            }
                                        }
                                        break;


                                default: Console.WriteLine("Invalid option. . .\n");
                                        break;
                            }
                            Console.WriteLine("Book is updated. . . ");
						}                       
                    }     
            }
        }





		//Method for DELETING the Book by id.
        public void RemoveById()
        {
            //checking whether the List is empty or not.
            if (bookList.Count == 0)
            {
                Console.WriteLine("No books to Delete. . .");
            }
            else
            {
                Console.Write("\nEnter the book id to be Deleted: ");
                int id;
                if (!int.TryParse(Console.ReadLine(), out id))
                {
                    Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                }
                else
                {
                    Book b2 = bookList.Find(findBook => findBook.BookId == id);
                    bookList.RemoveAt(id - 1);
                    Console.WriteLine("Book is removed. . . \n");
                }
            }
        }
    }
}


