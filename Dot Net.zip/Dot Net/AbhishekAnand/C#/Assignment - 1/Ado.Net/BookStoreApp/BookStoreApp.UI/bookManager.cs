﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStoreApp.Repository;
using BookStoreApp.Core;

namespace BookStoreApp.UI
{
    class bookManager
    {
        BookRepository br = new BookRepository();

        int bookId;
        int price;
        int CategoryId;
        int PublisherId;
        string authorName;
        string publisherName;
        string categoryName;


        //Method for ADDING a Book.
        public void AddBook()
        {
            Console.Write("\nEnter the number of books want to add: ");
            int number;

            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            for (int i = 0; i < number; i++)
            {
                Book b = new Book();

                //Console.Write("\nEnter the book id:          ");
                //while (!int.TryParse(Console.ReadLine(), out bookId))
                //{
                //    Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
                //}                               
                //b.BookId = bookId;               

                Console.Write("Enter the book Name:        ");
                b.Title = Console.ReadLine();

                Console.Write("Enter the book Description: ");
                b.Description = Console.ReadLine();


                //goto label for price.    
            enter_price_again:
                Console.Write("Enter the book Price:       ");
                while (!int.TryParse(Console.ReadLine(), out price))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                    goto enter_price_again;
                }

                try
                {
                    if (price <= 0)
                    {
                        throw new BookRepository();   //handled by Custom Exception.
                    }

                    else
                    {
                        b.Price = price;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                    goto enter_price_again;

                }

                Console.Write("Enter the book ISBN:        ");
                b.ISBN = Console.ReadLine();


                Console.Write("Enter the publication date: ");
                b.PublicationDate = Console.ReadLine();


                Console.Write("Enter the Category id:      ");
                while (!int.TryParse(Console.ReadLine(), out CategoryId))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                }
                b.CategoryId = CategoryId;

                Console.Write("Enter the Publisher id:     ");
                while (!int.TryParse(Console.ReadLine(), out PublisherId))
                {
                    Console.WriteLine("\nInvalid entry, expecting any numeric value. Please try again.\n");
                }
                b.PublisherId = PublisherId;

                //all the entities of a book_Object are added to List. 
                br.i_AddBook(b);
                Console.WriteLine("\nBook is Added. . . ");
            }
        }




        //Method for DISPLAYING ALL the Books
        public void displayBook()
        {
            try
            {
                IEnumerable<Book> bookList = br.i_displayBook();
                foreach (Book b in bookList)
                {
                    Console.WriteLine("\n. Book id:     {0}\n, Book Name:   {1}\n, Description: {2}\n, Price:       {3}\n, ISBN:        {4}\n, PDate:       {5}\n, Category id: {6}\n, PublisherId: {7}\n", b.BookId, b.Title, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
                }
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("Book not available. . .");
            }
        }





        //Method for DISPLAYING the Books by id.
        public void findBookById()
        {
            Console.Write("\nEnter the book id to be searched: ");

            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            try
            {
                Book b = br.i_findBookById(bookId);
                Console.WriteLine("\n. Book id:     {0}\n, Book Name:   {1}\n, Description: {2}\n, Price:       {3}\n, ISBN:        {4}\n, PDate:       {5}\n, Category id: {6}\n, PublisherId: {7}\n", b.BookId, b.Title, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("Book with Id={0} Not Available in Book Store", bookId);
            }
        }





        //Method for UPDATING the book by id.
        public void updateBookById()
        {
            Console.Write("\nEnter the book id to be updated: ");
            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            Book b = br.i_findBookById(bookId);

            if (b == null)
            {
                Console.WriteLine("Book with Id={0} Not Available in Book Store to update", bookId);
            }

            else
            {
                Console.WriteLine("Press 1 to Update PublicationDate\nPress 2 to Update Price\n");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {

                    case 1: Console.Write("Enter the PublicationDate: ");
                        b.PublicationDate = Console.ReadLine(); ;
                        break;

                    case 2:
                    enter_price_again_update:
                        Console.Write("Enter the Price: ");
                        if (!int.TryParse(Console.ReadLine(), out price))
                        {
                            Console.WriteLine("Invalid entry, expecting any numeric value. Please try again.");
                        }
                        else
                        {
                            try
                            {
                                if (price <= 0)
                                {
                                    throw new BookRepository();   //handled by Custom Exception.
                                }
                                else
                                {
                                    b.Price = price;
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("\nPrice can't be less than or equal to zero. . .\n");
                                goto enter_price_again_update;
                            }
                        }
                        break;


                    default:
                        Console.WriteLine("Invalid option. . .\n");
                        break;
                }
                br.i_updateBookById(b);
                Console.WriteLine("Book is updated. . . ");
            }
        }




        //Method for DELETING the Book by id.
        public void RemoveById()
        {
            Console.Write("\nEnter the book id to be Deleted: ");
            while (!int.TryParse(Console.ReadLine(), out bookId))
            {
                Console.WriteLine("Invalid entry, expecting any numeric value. Please try again. . .");
            }

            int count = br.i_RemoveById(bookId);

            if (count == 0)
            {
                Console.WriteLine("Book is not available in store");
            }
            else
            {

                Console.WriteLine("Book with id={0} is deleted", bookId);
            }
        }



        //Get All the books written by specific Author
        public void All_BooksBy_Specific_Author()
        {
            Book b1 = new Book();

            Console.Write("\nEnter the Author name: ");
            authorName = Console.ReadLine();
            b1.authorName = authorName;

            try
            {
                Book b = br.i_All_BooksBy_Specific_Author(b1);
                Console.WriteLine("\n. Book id:     {0}\n, Book Name:   {1}\n, Description: {2}\n, Price:       {3}\n, ISBN:        {4}\n, PDate:       {5}\n, Category id: {6}\n, PublisherId: {7}\n", b.BookId, b.Title, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
            }
            catch(Exception ex)
            {
                Console.WriteLine("\nBook not found\n" + ex.Message);
            }
        }



        //Get all the books written by specific author and published by specific publisher belonging to “Technical” book Category
        public void All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory()
        {
            Book b1 = new Book();

            Console.Write("\nEnter the Author Name:    ");
            authorName = Console.ReadLine();
            b1.authorName = authorName;

            Console.Write("Enter the Publisher Name: ");
            publisherName = Console.ReadLine();
            b1.publisherName = publisherName;

            Console.Write("Enter the Category Name:  ");
            categoryName = Console.ReadLine();
            b1.categoryName = categoryName;

            try
            {
                Book b = br.i_All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory(b1);
                Console.WriteLine("\n. Book id:     {0}\n, Book Name:   {1}\n, Description: {2}\n, Price:       {3}\n, ISBN:        {4}\n, PDate:       {5}\n, Category id: {6}\n, PublisherId: {7}\n", b.BookId, b.Title, b.Description, b.Price, b.ISBN, b.PublicationDate, b.CategoryId, b.PublisherId);
            }
            catch(Exception ex)
            {
                Console.WriteLine("\nBook not found...\n" + ex.Message);
            }

        }



        //Get total Books published by each Publisher
        public void Get_Books_by_eachPublisher()
        {
            try
            {
                Book b = br.i_Get_Books_by_eachPublisher();
                Console.WriteLine("\n. PublisherId: {0}\n, Total Books: {1}", b.PublisherId, b.totalBooks);
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nBook not found...\n" + ex.Message);
            }
        }
    }
}

