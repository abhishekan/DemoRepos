﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SerializationDemo
{
    [Serializable]
    class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
    }

    class MySerializer
    {
        //creating formatter to serialize object  using Binary serializer
        BinaryFormatter bf = new BinaryFormatter();
        TextWriter text = new StreamWriter();

        public void SerializeEmployee()
        {
            //opening or creating a file to store serialized object

            List<Employee> empList = new List<Employee>()
            {
                new Employee(){ EmployeeId = 1, Name = "nourin"},
                new Employee(){ EmployeeId = 2, Name = "Sachin"}
            };

            using (Stream stream = File.Open(@"C:\Demo\text.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                //serializing employee list object
                try
                {
                    bf.Serialize(stream, empList);
                    Console.WriteLine("List of Employee serialized and stored in the hard disk in binary format.");
                }
                catch (System.Runtime.Serialization.SerializationException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void DeserializeEmployee()
        {
            //opening or creating a file to store serialized object
            
            List<Employee> empList2 = new List<Employee>();
            using (Stream stream = File.Open(@"C:\Demo\text.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                try
                {
                    //deserializing employee list object
                    empList2 = (List<Employee>)bf.Deserialize(stream);

                    foreach (Employee e in empList2)
                    {
                        Console.WriteLine("Employee Id : {0}", e.EmployeeId);
                        Console.WriteLine("Name : {0}", e.Name);
                    }
                }
                catch (System.Runtime.Serialization.SerializationException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MySerializer ms = new MySerializer();
            ms.SerializeEmployee();
            ms.DeserializeEmployee();
        }
    }
}
