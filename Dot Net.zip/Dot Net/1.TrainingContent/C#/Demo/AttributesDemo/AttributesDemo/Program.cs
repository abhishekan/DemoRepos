﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    class EmployeeManager
    {
        [ObsoleteAttribute("Saving data to XML will be deprecated in the next release, instead use SaveDataToDB", false)]
        public static void SaveDataToXML()
        {
            Console.WriteLine("Saving data to XML file");
        }

        public static void SaveDataToDB()
        {
            Console.WriteLine("Saving data to database");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //EmployeeManager.SaveDataToXML();
            //EmployeeManager.SaveDataToDB();

            //Retrieving information from custom attributes
            Console.WriteLine("Authors Information of Employee type");
            Attribute[] att = Attribute.GetCustomAttributes(typeof(Employee));
            //Display information about custom attributes
            foreach (Attribute a in att)
            {
                LogAuthorAttribute auth = (LogAuthorAttribute)a;
                Console.WriteLine("Author Name : {0} , Version : {1}", auth.GetName(), auth.version);
            }
        }
    }
}
