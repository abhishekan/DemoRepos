﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;


namespace StringCollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            StringCollection cityList = new StringCollection();
            //cityList.Add("b");
            //cityList.Add("a");

            //foreach (string s in cityList)
            //{
            //    Console.WriteLine(s);
            //}
            
            StringDictionary sdList = new StringDictionary();
            

            //sorted by key-number
            //sdList.Add("3", "20");
            //sdList.Add("2", "15");

            //sorting by key-character
            sdList.Add("c", "30");
            sdList.Add("b", "35");


            foreach (System.Collections.DictionaryEntry s in sdList)
            {
                Console.Write(s.Key);
                Console.Write("\t" + s.Value);
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
