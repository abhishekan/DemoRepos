﻿
namespace SampleApp2.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductManager pm = new ProductManager();
            pm.GetProducts();
        }
    }
}
