﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ConnectedDemo
{
    class DAL
    {
        private static string conStr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
        private static SqlConnection con;

        public static bool CheckConnection()
        {
            try
            {
                con = new SqlConnection(conStr);
                con.Open();
                Console.WriteLine("Connected successfully");
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        public static bool CloseConnection()
        {
            try
            {
                if(con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                    Console.WriteLine("Connection closed successfully");
                }
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            return false;
        }

        public static void GetEmployees(int? id)
        {
            //opening connection first
            bool status = DAL.CheckConnection();
            Console.WriteLine("Connection Status : {0}", status);

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            //cmd.CommandText = "Select * from Employee";
            if(id == null)
            {
                cmd.CommandText = "prcGetEmployees";
            }
            else
            {
                cmd.CommandText = "prcGetEmployeeById";
                //creating parameters and pass to sp
                cmd.Parameters.Add(new SqlParameter("@id", SqlDbType.Int, 0, "EmployeeId")).Value = id;
            }
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataReader reader = null;
            try
            {
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine("Employee Id : {0}", reader["EmployeeId"]);
                    Console.WriteLine("Name : {0}", reader["Name"]);
                    Console.WriteLine("City : {0}", reader["City"]);
                    Console.WriteLine("Department Id : {0}", reader["DepartmentId"]);
                    Console.WriteLine("================================");
                }
            }
            catch(SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                DAL.CloseConnection();
            }
        }
    }
}
