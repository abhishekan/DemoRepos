﻿using System;

namespace FirstProgram
{
    /// <summary>
    /// This class contains entry point of this program
    /// </summary>
    class Program
    {
        /// <summary>
        /// This is the entry point of the program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //singel line comment
            /*line1
            line2
            line3*/

            Console.WriteLine("Hello World");
            Console.WriteLine("Hello {0}, you are from {1}", args.GetValue(0), args.GetValue(1));
        }
    }
}
