﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuBasedSimpleCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            int operation, num1, num2;
            char choice;
            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("=====================");
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Subtract");
                Console.WriteLine("3.Divide");
                Console.WriteLine("4.Multiply");
                Console.WriteLine("==================");

                Console.WriteLine("Select Operation(1/2/3/4)");
                operation = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter a number");
                num1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter another number");
                num2 = int.Parse(Console.ReadLine());

                switch (operation)
                {
                    case 1: Console.WriteLine("Sum of {0} and {1} is {2}", num1, num2, num1 + num2);
                        break;
                    case 2: Console.WriteLine("Difference of {0} and {1} is {2}", num1, num2, num1 - num2);
                        break;
                    case 3: Console.WriteLine("Division of {0} and {1} is {2}", num1, num2, num1 / num2);
                        break;
                    case 4: Console.WriteLine("Product of {0} and {1} is {2}", num1, num2, num1 * num2);
                        break;
                }

                Console.WriteLine("Do you want to continue?(y/n)");
                choice = char.Parse(Console.ReadLine());
            } while (choice == 'y' || choice == 'Y');
        }
    }
}
