﻿using MyProductStore.Repository.Concrete;
using System;

namespace MyProductStore.ConsoleUI
{
    class CustomerManager
    {
        CustomerRepository repo = new CustomerRepository();

        public void ShowAllCustomers()
        {
            var customers = repo.GetCustomers();

            foreach(var customer in customers)
            {
                Console.WriteLine("Customer Id : {0}, Name : {1}, City : {2}", customer.CustomerId, customer.Name, customer.City);
            }
        }
    }
}
