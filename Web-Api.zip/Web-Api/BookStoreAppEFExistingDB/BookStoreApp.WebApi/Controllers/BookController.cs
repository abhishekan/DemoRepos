﻿
using System.Collections.Generic;
using System.Web.Http;
using System.Net;
using BookStoreAppMVC.Models;
using BookStoreApp.Repository;
using BookStoreApp.Repository.EntityDataModel;

//Book controller
namespace BookStoreApp.WEBAPI.Controllers
{
    public class BookController : ApiController
    {
        BookRepository repo = new BookRepository();

        public IEnumerable<BookView> Get()
        {
            IEnumerable<BOOK> bookList = repo.i_displayBook();
            List<BookView> List = new List<BookView>();

            foreach (var i in bookList)
            {
                BookView bookViewModel = new BookView();

                bookViewModel.BookId = i.BookId;
                bookViewModel.Title = i.Title;
                bookViewModel.Description = i.Description;
                bookViewModel.Price = i.Price;
                bookViewModel.ISBN = i.ISBN;
                bookViewModel.PublicationDate = i.PublicationDate;
                bookViewModel.B_Cid = i.B_Cid;
                bookViewModel.B_Pid = i.B_Pid;

                List.Add(bookViewModel);
            }
            return List;
        }

        public IHttpActionResult Get(int id)
        {
            BOOK book = repo.i_findBookById(id);

            BookView bookViewModel = new BookView();

            bookViewModel.BookId = book.BookId;
            bookViewModel.Title = book.Title;
            bookViewModel.Description = book.Description;
            bookViewModel.Price = book.Price;
            bookViewModel.ISBN = book.ISBN;
            bookViewModel.PublicationDate = book.PublicationDate;
            bookViewModel.B_Cid = book.B_Cid;
            bookViewModel.B_Pid = book.B_Pid;

            return Ok(bookViewModel);
        }


        public IHttpActionResult Post(BOOK book)
        {
            repo.i_AddBook(book);         
            return Created(Request.RequestUri + "/" + book.BookId, book);
        }

        public void Put(BOOK book)
        {
            repo.i_updateBookById(book);
        }

        public void Delete(int id)
        {
            repo.i_RemoveById(id);
        }

    }
}