﻿using BookStoreApp.Repository;
using BookStoreApp.Repository.EntityDataModel;
using BookStoreAppMVC.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace BookStoreAppMVC.Controllers
{
    public class BookController : Controller
    {
        //Creating the instance of Book Repository, to call the methods of repository.
        BookRepository repo = new BookRepository();


        //Method for DISPLAYING ALL the Books
        [HttpGet]
        public ActionResult GetBooks()
        {
            IEnumerable<BOOK> bookList = repo.i_displayBook();
            List<BookView> List = new List<BookView>();

            foreach (var i in bookList)
            {
                BookView bookViewModel = new BookView();

                bookViewModel.BookId = i.BookId;
                bookViewModel.Title = i.Title;
                bookViewModel.Description = i.Description;
                bookViewModel.Price = i.Price;
                bookViewModel.ISBN = i.ISBN;
                bookViewModel.PublicationDate = i.PublicationDate;
                bookViewModel.B_Cid = i.B_Cid;
                bookViewModel.B_Pid = i.B_Pid;

                List.Add(bookViewModel);
            }
            return View(List);
        }


        //Method for DISPLAYING the Books by id.
        [AllowAnonymous]
        [HttpGet]
        public ActionResult GetBookById(int id)
        {
            BOOK book = repo.i_findBookById(id);

            BookView bookViewModel = new BookView();

            bookViewModel.BookId = book.BookId;
            bookViewModel.Title = book.Title;
            bookViewModel.Description = book.Description;
            bookViewModel.Price = book.Price;
            bookViewModel.ISBN = book.ISBN;
            bookViewModel.PublicationDate = book.PublicationDate;
            bookViewModel.B_Cid = book.B_Cid;
            bookViewModel.B_Pid = book.B_Pid;

            return View(bookViewModel);
        }


        //Method for ADDING a Book.
        [Authorize(Roles = "admin")]
        [HttpGet]
        public ViewResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddBook(BookView bookViewModel)
        {
            if (ModelState.IsValid)
            {
                BOOK book = new BOOK();

                book.BookId = bookViewModel.BookId;
                book.Title = bookViewModel.Title;
                book.Description = bookViewModel.Description;
                book.Price = bookViewModel.Price;
                book.ISBN = bookViewModel.ISBN;
                book.PublicationDate = bookViewModel.PublicationDate;
                book.B_Cid = bookViewModel.B_Cid;
                book.B_Pid = bookViewModel.B_Pid;

                repo.i_AddBook(book);

                return RedirectToAction("GetBooks");
            }
            return View(); 
        }


        //Method for UPDATING the book by id.
        [Authorize(Roles = "admin")]
        [HttpGet]
        public ActionResult UpdateBook(int id)
        {
            BOOK book = repo.i_findBookById(id);

            BookView bookViewModel = new BookView();

            bookViewModel.BookId = book.BookId;
            bookViewModel.Title = book.Title;
            bookViewModel.Description = book.Description;
            bookViewModel.Price = book.Price;
            bookViewModel.ISBN = book.ISBN;
            bookViewModel.PublicationDate = book.PublicationDate;
            bookViewModel.B_Cid = (int)book.B_Cid;
            bookViewModel.B_Pid = (int)book.B_Pid;

            return View(bookViewModel);
        }

        [HttpPost]
        public ActionResult UpdateBook(BookView bookViewModel)
        {
            if (ModelState.IsValid)
            {
                BOOK book = new BOOK();

                book.BookId = bookViewModel.BookId;
                book.Title = bookViewModel.Title;
                book.Description = bookViewModel.Description;
                book.Price = bookViewModel.Price;
                book.ISBN = bookViewModel.ISBN;
                book.PublicationDate = bookViewModel.PublicationDate;
                book.B_Cid = bookViewModel.B_Cid;
                book.B_Pid = bookViewModel.B_Pid;

                repo.i_updateBookById(book);

                return RedirectToAction("GetBooks");
            }
            return View(); 
        }


        //Method for DELETING the Book by id.
        [Authorize(Roles = "admin")]
        [HttpGet]
        public ActionResult DeleteBook(int id)
        {
            BOOK book = repo.i_findBookById(id);

            BookView bookViewModel = new BookView();

            bookViewModel.BookId = book.BookId;
            bookViewModel.Title = book.Title;
            bookViewModel.Description = book.Description;
            bookViewModel.Price = book.Price;
            bookViewModel.ISBN = book.ISBN;
            bookViewModel.PublicationDate = book.PublicationDate;
            bookViewModel.B_Cid = book.B_Cid;
            bookViewModel.B_Pid = book.B_Pid;

            return View(bookViewModel);
        }

        [ActionName("DeleteBook")]
        [HttpPost]
        public ActionResult FinalDelete(int id)
        {
            repo.i_RemoveById(id);
            return RedirectToAction("GetBooks");
        }


        //Method for SEARCHING the Books by Title.
        [AllowAnonymous]
        [HttpGet]
        public ActionResult SearchBook(string name)
        {
            if (name != null)
            {
                IEnumerable<BOOK> bookList2 = null;
                bookList2 = repo.i_searchBookByTitle(name);
                
                List<BookView> List2 = new List<BookView>();              

                foreach (var i in bookList2)
                {
                    BookView bookViewModel2 = new BookView();
               
                    bookViewModel2.BookId = i.BookId;
                    bookViewModel2.Title = i.Title;
                    bookViewModel2.Description = i.Description;
                    bookViewModel2.Price = i.Price;
                    bookViewModel2.ISBN = i.ISBN;
                    bookViewModel2.PublicationDate = i.PublicationDate;
                    bookViewModel2.B_Cid = i.B_Cid;
                    bookViewModel2.B_Pid = i.B_Pid;

                    List2.Add(bookViewModel2);
                }
                return View(List2);
            }
            else
            {
                return HttpNotFound();
            }
        }
    }
}