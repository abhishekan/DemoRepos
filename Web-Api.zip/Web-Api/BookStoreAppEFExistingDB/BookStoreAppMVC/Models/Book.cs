﻿
using System.ComponentModel.DataAnnotations;
namespace BookStoreAppMVC.Models
{
    public class Book
    {
        public int BookId { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public int Price { get; set; }

        [Required]
        public string ISBN { get; set; }

        [Required]
        public string PublicationDate { get; set; }

        public int CategoryId { get; set; }

        public int PublisherId { get; set; }
    }
}