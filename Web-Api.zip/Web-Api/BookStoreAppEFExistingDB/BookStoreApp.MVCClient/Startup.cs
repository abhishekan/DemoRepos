﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BookStoreApp.MVCClient.Startup))]
namespace BookStoreApp.MVCClient
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
