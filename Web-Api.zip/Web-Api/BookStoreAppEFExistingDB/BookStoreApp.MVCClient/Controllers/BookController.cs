﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using BookStoreAppMVC.Models;

namespace BookStoreApp.MVCClient.Controllers
{
    public class BookController : Controller
    {
        HttpClient client;
        string url = "http://localhost:49847/api/Book";
        public BookController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }
        public async Task<ActionResult> GetBooks()
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var Books = JsonConvert.DeserializeObject<List<BookView>>(responseData);
                return View(Books);
            }
            return View("Error");
        }

        public async Task<ActionResult> GetBookById(int? id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var Books = JsonConvert.DeserializeObject<BookView>(responseData);
                return View(Books);
            }
            return View("Error");
        }

        [HttpGet]
        public ActionResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> AddBook(BookView vbook)
        {
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, vbook);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("GetBooks");
            }
            return RedirectToAction("Error");
        }


        [HttpGet]
        public async Task<ActionResult> UpdateBook(int? id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var model = JsonConvert.DeserializeObject<BookView>(responseData);

                return View(model);
            }
            return View("Error");
        }


        [HttpPost]
        public async Task<ActionResult> UpdateBook(BookView model)
        {
            HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url, model);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("GetBooks");
            }
            return View("Error");
        }

        [HttpGet]
        public async Task<ActionResult> DeleteBook(int? id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var model = JsonConvert.DeserializeObject<BookView>(responseData);

                return View(model);
            }
            return View("Error");
        }


        [ActionName("DeleteBook")]
        [HttpPost]
        public async Task<ActionResult> FinalDelete(int? id)
        {
            HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("GetBooks");
            }

            return View("Error");
        }
    }
}