﻿
using System;
using System.ComponentModel.DataAnnotations;
namespace BookStoreAppMVC.Models
{
    public class BookView
    {
        [Required]
        public int BookId { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z0-9 ]+$", ErrorMessage = "Only characters are allowed.")]
        public string Title { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z0-9 ]+$", ErrorMessage = "Only characters are allowed.")]
        public string Description { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "Only numbers are allowed.")]
        public Nullable<int> Price { get; set; }

        [Required]
        public string ISBN { get; set; }

        [Required (ErrorMessage = "The Publication Date field is required. (dd-mm-yyyy)")]
        public string PublicationDate { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "Only numbers are allowed.")]
        public Nullable<int> B_Cid { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "Only numbers are allowed.")]
        public Nullable<int> B_Pid { get; set; }
    }
}