﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class SubRouteRepository : ISubRouteRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities subRouteContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new sub route to Database.
        /// </summary>
        /// <param name="subRouteAddToDb">This sub route Object which is passed By client will be inserted into Database.</param>  
        public void AddNewSubRoute(SubRoute subRouteAddToDb)
        {
            //Adding sub route object to database.And Calling savechanges to reflect changes to database.
            subRouteContext.SubRoutes.Add(subRouteAddToDb);
            subRouteContext.SaveChanges();
        }

        /// <summary>
        /// This method is used to get all subroutes present in database.
        /// </summary>
        /// <returns>Returns List of subroutes present in Database</returns>
        public IEnumerable<SubRoute> GetAllSubRoutes()
        {
            //Querying database to get list of sub route objects
            return subRouteContext.SubRoutes.ToList();
        }

        /// <summary>
        ///  This method is used to get  subroute present in database according to the parameters passed by user.
        /// </summary>
        /// <param name="routeMasterId">This is route Id passed by user</param>
        /// <param name="source">This is the name of staion from which user wishes to travel.</param>
        /// <param name="destination">This is the name of destination to which user wishes to travel.</param>
        /// <returns></returns>
        public SubRoute GetSubRouteByRouteMasterSourceDestination(int routeMasterId = 0, String source = null, String destination = null)
        {
            if (routeMasterId != null)
            {

                //Getting sub route using routemaser id, source and destination.
                SubRoute subRouteFound = subRouteContext.SubRoutes
                    .Where(x => x.Source == source)
                    .Where(x => x.Destination == destination)
                    .Where(x => x.RouteMasterId == routeMasterId)
                    .FirstOrDefault();
                if (subRouteFound != null)
                {
                    return subRouteFound;
                }
            } return null;
        }


        /// <summary>
        /// This method id used to get subroute using subroute id.
        /// </summary>
        /// <param name="subRouteIdToSearch">This is subroute id to be search in table.</param>
        /// <returns></returns>
        public SubRoute GetSubRouteBySubRouteId(int? subRouteIdToSearch)
        {
            //Getting sub route using subroute id.
            SubRoute subRouteFound = subRouteContext.SubRoutes.Find(subRouteIdToSearch);
            if (subRouteFound != null)
            {
                return subRouteFound;
            }
            return null;
        }
          
            
      

       /// <summary>
       ///  This method is used to Update sub route present in database.
       /// </summary>
       /// <param name="subRouteToAdd">This is the sub route object passed from client whose information needs to be updated in database.</param>
        public void UpdateSubRoute(SubRoute subRouteToAdd)
        {
            //Querying database to get the subroute by using subroute object passed by user.
            if (subRouteToAdd != null)
            {
                //After getting database object whose sub route  Id is same as Passed objects sub route Id, changing the 
                //subroute distance in database object.
                //And Calling savechanges to reflect changes to database.
                SubRoute subRouteFromDb = subRouteContext.SubRoutes.Find(subRouteToAdd.SubRouteId);
                if (subRouteFromDb != null)
                {
                    subRouteFromDb.StopNo = subRouteToAdd.StopNo;
                    subRouteContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method is used to delete subroute present in database according to the subroute Id passed by user.
        /// </summary>
        /// <param name="subRouteIdToDelete">This is subroute Id passed by the user to delete particular category.</param>
        public void DeleteSubRouteBysubRouteId(int? subRouteIdToDelete)
        {
            //First getting the subroute Object using the id passed by user.
            //Then removing the subroute object which we got, using remove() method.
            //And Calling savechanges to reflect changes to database.
            if (subRouteIdToDelete != null)
            {
                SubRoute subRouteToDeleteFromDb = subRouteContext.SubRoutes.Find(subRouteIdToDelete);
                subRouteContext.SubRoutes.Remove(subRouteToDeleteFromDb);
                subRouteContext.SaveChanges();
            }
        }

    }
}
