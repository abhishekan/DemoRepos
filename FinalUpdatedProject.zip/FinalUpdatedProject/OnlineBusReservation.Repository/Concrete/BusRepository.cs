﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class BusRepository : IBusRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities busContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new Bus to Database.
        /// </summary>
        /// <param name="busToAddToDb">This Bus Object which is passed By client will be inserted into Database.</param>
        public void AddNewBus(Bus busToAddToDb)
        {
            
            //Adding bus object to database.And Calling savechanges to reflect changes to database.
          
                busContext.Buses.Add(busToAddToDb);
                busContext.SaveChanges();
          
        }


        /// <summary>
        /// This method is used to get all Buses present in database.
        /// </summary>
        /// <returns>Returns List of Buses present in Database</returns>
        public IEnumerable<Bus> GetAllBuses()
        {
            //Querying database to get list of bus objects
            return busContext.Buses.ToList();
        }


        /// <summary>
        /// This method is used to get  Bus present in database according to the Bus Id passed by user.
        /// </summary>
        /// <param name="busIdToSearch">This is bus Id passed by the user to get information about particular Bus.</param>
        /// <returns>Returns the Bus object found in database.</returns>
        public Bus GetBusByBusId(int? busIdToSearch)
        {
            //Querying database to get the bus whose bus Id is passed to the method.
            if (busIdToSearch != null)
            {
                Bus busFound = busContext.Buses.Find(busIdToSearch);
                if (busFound != null)
                {
                    return busFound;
                }
            }
            return null;
        }


        /// <summary>
        ///  This method is used to Update Bus present in database.
        /// </summary>
        /// <param name="busFromApi">This is the Bus object passed from client whose information needs to be updated in database.</param>
        public void UpdateBus(Bus busFromApi)
        {
            //Querying database to get the bus by using bus object passed by user.
            if(busFromApi!=null)
            {
                Bus busFromDb = busContext.Buses.Find(busFromApi.BusId);

                //After getting database object whose Bus Id is same as Passed objects bus Id, changing the 
                //availableseats in database object by 1.
                //And Calling savechanges to reflect changes to database.
                if(busFromDb!=null)
                {
                    busFromDb.AvailableSeats = busContext.Buses.Find(busFromApi.BusId).AvailableSeats - 1;
                    busContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method will update bus by admin.
        /// </summary>
        /// <param name="busFromApi">This is modified object by admin</param>
        public void UpdateBusByAdmin(Bus busFromApi)
        {
            //Querying database to get the bus by using bus object passed by user.
            if (busFromApi != null)
            {
                Bus busFromDb = busContext.Buses.Find(busFromApi.BusId);

                //After getting database object whose Bus Id is same as Passed objects bus Id, changing the 
                //availableseats in database object by 1.
                //And Calling savechanges to reflect changes to database.
                if (busFromDb != null)
                {
                    busFromDb.RouteMasterId = busFromApi.RouteMasterId;
                    busFromDb.ArrivalTime = busFromApi.ArrivalTime;
                    busFromDb.DepartureTime = busFromApi.DepartureTime;
                    busContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method is used to delete  Bus present in database according to the Bus Id passed by user.
        /// </summary>
        /// <param name="busIdToDelete">This is bus Id passed by the user to delete particular Bus.</param>
        public void DeleteBusByBusId(int? busIdToDelete)
        {
            //First getting the Bus Object using the id passed by user.
            //Then removing the bus object which we got using remove() methos.
            //And Calling savechanges to reflect changes to database.
            if (busIdToDelete != null)
            {
                Bus busToDeleteFromDb = busContext.Buses.Find(busIdToDelete);
                busContext.Buses.Remove(busToDeleteFromDb);
                busContext.SaveChanges();
            }
        }

        /// <summary>
        /// This method is called to check for return journey.
        /// It will check that the bus which is selected by user present on the date selected
        /// by user as return date.
        /// </summary>
        /// <param name="id">This is the Id of One way trip bus.</param>
        /// <param name="dateOfJourney">This is journey date selected by user as return date.</param>
        /// <returns>Returns the bus object if bus is available on return date selected by user.</returns>
        public Bus SearchReturnBusToGetBusId(int id, DateTime dateOfJourney)
        {
            //From id passed we will try to get bus object whose id is same.
            var busFound = busContext.Buses.Find(id);

            //Here extracting day of week part from return date.
            string dayOfWeek = dateOfJourney.ToString("ddd");

            //Searching for the bus whose bus name is same as bus we found using id.
            //And checking if that bus is available on that day of that particular week.
            var bustoreturn=(busContext.Buses.Where(bus=>bus.BusName==busFound.BusName)
                           .Where(bus => bus.BusAvailableDay.Contains(dayOfWeek))).FirstOrDefault();
            return bustoreturn;
        
        }

        /// <summary>
        /// This is method that is used  to return the list of bus object according to the
        /// search parameters entered by user.
        /// </summary>
        /// <param name="source">This is the name of staion from which user wishes to travel.</param>
        /// <param name="destination">This is the name of destination to which user wishes to travel.</param>
        /// <param name="category">This is category selected by user.</param>
        /// <param name="timeSlot">This is TimeSlot selected bys user Eg- between 6:00-12:00</param>
        /// <param name="journetDate">This is Journey date</param>
        /// <param name="returnDateToSearch">This is date on which user wishes to return.</param>
        /// <returns>Returns the bus object if bus is available on return date selected by user.</returns>
        public IEnumerable<Bus> SearchBusByUserChoice(string source, string destination, string category, string timeSlot, DateTime journetDate, DateTime? returnDateToSearch)
        {
            //First assigning the timeslot from and to time using the parameter passed by user.
            DateTime arrive;
            DateTime depart;
            if (timeSlot == "06:00Hr-12:00Hr")
            {
                arrive = new DateTime(2016, 05, 11, 6, 00, 00);
                depart = new DateTime(2016, 05, 11, 12, 00, 00);
            }
            else if (timeSlot == "12:00Hr-18:00Hr")
            {
                arrive = new DateTime(2016, 05, 11, 12, 00, 00);
                depart = new DateTime(2016, 05, 11, 18, 00, 00);
            }
            else if (timeSlot == "18:00Hr-24:00Hr")
            {
                arrive = new DateTime(2016, 05, 11, 18, 00, 00);
                depart = new DateTime(2016, 05, 11, 23, 59, 59);
            }
            else
            {
                arrive = new DateTime(2016, 05, 11, 6, 00, 00);
                depart = new DateTime(2016, 05, 11, 23, 59, 59);
            }


            //Extracting day of week part of journey date.
            string dayOfweek = journetDate.ToString("ddd");

            //Toreturn filtered list of bus according to their return date
            List<Bus> busToReturn = new List<Bus>();

            //According to category selected by user we will search the bus.If user has selected no cartegory he will get all
            //categoies buses.
            if (category == "Ac" || category == "Non-Ac" || category == "Sleeper" || category == "Semi-Sleeper")
            {
                //Getting the subroute object using source and destination passed and selected by user.
                SubRoute subRoute = busContext.SubRoutes.Where(s => s.Source == source)
                                   .Where(s => s.Destination == destination).FirstOrDefault();

                
                //Using that sub route object getting all buses whose routemaster id and category same as passed by user.
                var busToFind = busContext.Buses.Where(bus => bus.RouteMasterId == subRoute.RouteMasterId)
                               .Where(bus => bus.Category.CategoryName == category);

                //From the above list of buses extracting only those buses which are betwwen the timeslot selected by user.
                var busesAfterCheckingDepartureTime = busToFind.Where(bus => bus.DepartureTime >= arrive.TimeOfDay);

                //checking whether bus is present on the date selected by user.
                var busesAfterCheckingAvailabilityOnJourneyDate = busesAfterCheckingDepartureTime.Where(bus => bus.DepartureTime <= depart.TimeOfDay)
                                                                .Where(bus => bus.BusAvailableDay.Contains(dayOfweek));

                //For the Round trip journey checking availability of bus on the return date.
                if (returnDateToSearch != null)
                {
                    //checking whether bus is present on the Return date selected by user.
                    foreach (var busIterator in busesAfterCheckingAvailabilityOnJourneyDate)
                    {
                        DateTime dateToCheck = (DateTime)returnDateToSearch;
                        string dayOfWeekForReturn = dateToCheck.ToString("ddd");

                        var busCheckForReturn = busContext.Buses.Where(bus => bus.BusName == busIterator.BusName)
                                               .Where(bus => bus.BusAvailableDay.Contains(dayOfWeekForReturn))
                                               ;
                        var busCheck = busCheckForReturn.Where(bus => bus.BusId != busIterator.BusId).ToList();

                        if (busCheck.Count() != 0)
                        {
                            busToReturn.Add(busIterator);
                        }
                    }
                    return busToReturn;
                }
                return busesAfterCheckingAvailabilityOnJourneyDate;
               
            }
            else 
            {
                //Getting the subroute object using source and destination passed and selected by user.
                SubRoute subRoute = busContext.SubRoutes.Where(s => s.Source == source).Where(s => s.Destination == destination).FirstOrDefault();

                //Using that sub route object getting all buses whose routemaster id same as passed by user.
                var busToFind = busContext.Buses.Where(bus => bus.RouteMasterId == subRoute.RouteMasterId);

                //From the above list of buses extracting only those buses which are betwwen the timeslot selected by user.
                var busesAfterCheckingDepartureTime = busToFind.Where(bus => bus.DepartureTime >= arrive.TimeOfDay);

                //checking whether bus is present on the date selected by user.
                List<Bus> busesAfterCheckingAvailabilityOnJourneyDate = busesAfterCheckingDepartureTime.Where(bus => bus.ArrivalTime <= depart.TimeOfDay)
                    .Where(bus => bus.BusAvailableDay.Contains(dayOfweek)).ToList();

                

                //For the Round trip journey checking availability of bus on the return date.
                if (returnDateToSearch != null)
                {

                    DateTime dateToCheck = (DateTime)returnDateToSearch;
                    string dayOfWeekForReturn = dateToCheck.ToString("ddd");
                   
                    //checking whether bus is present on the Return date selected by user.
                    foreach (var busIterator in busesAfterCheckingAvailabilityOnJourneyDate)
                    {
                        var busCheckForReturn = busContext.Buses.Where(bus => bus.BusName == busIterator.BusName)
                                               .Where(bus => bus.BusAvailableDay.Contains(dayOfWeekForReturn))
                                               ;
                        var busCheck = busCheckForReturn.Where(bus => bus.BusId != busIterator.BusId).ToList();
                        
                        if (busCheck.Count()!=0 )
                        {
                            busToReturn.Add(busIterator);
                        }        
                    }
                    return busToReturn;
                }
                return busesAfterCheckingAvailabilityOnJourneyDate;
               
            }
        }
    }
}
 