﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class RouteMasterRepository : IRouteRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities routeContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new route to Database.
        /// </summary>
        /// <param name="routeAddToDb">This route Object which is passed By client will be inserted into Database.</param>  
        public void AddNewRoute(RouteMaster routeAddToDb)
        {
            //Adding route object to database.And Calling savechanges to reflect changes to database.
            routeContext.RouteMasters.Add(routeAddToDb);
            routeContext.SaveChanges();
        }

        /// <summary>
        /// This method is used to get all routes present in database.
        /// </summary>
        /// <returns>Returns List of routes present in Database</returns>
        public IEnumerable<RouteMaster> GetAllRoutes()
        {
            //Querying database to get list of route objects
            return routeContext.RouteMasters.ToList();
        }

        /// <summary>
        /// This method is used to get  route present in database according to the route Id passed by user.
        /// </summary>
        /// <param name="routeIdToSearch">This is route Id passed by the user to get information about particular route.</param>
        /// <returns>Returns the route object found in database.</returns>
        public RouteMaster GetRouteByRouteId(int? routeIdToSearch)
        {
            //Querying database to get the route whose  Id is passed to the method.
            if (routeIdToSearch != null)
            {
                RouteMaster routeFound = routeContext.RouteMasters.Find(routeIdToSearch);
                if (routeFound != null)
                {
                    return routeFound;
                }
            }
            return null;
        }

        //public void UpdateB(RouteMaster routeFromApi)
        //{
        //    if (busFromApi != null)
        //    {
        //        Bus busFromDb = routeContext.Buses.Find(busFromApi.BusId);
        //        if (busFromDb != null)
        //        {
        //            busFromDb.ArrivalTime = busFromApi.ArrivalTime;
        //            busFromDb.DepartureTime = busFromApi.DepartureTime;
        //            busFromDb.RouteMasterId = busFromApi.RouteMasterId;
        //            routeContext.SaveChanges();
        //        }
        //    }
        //}

        /// <summary>
        /// This method is used to delete route present in database according to the route Id passed by user.
        /// </summary>
        /// <param name="routeIdToDelete">This is route Id passed by the user to delete particular route.</param>
        public void DeleteRouteByRouteId(int? routeIdToDelete)
        {
            //First getting the route Object using the id passed by user.
            //Then removing the route object which we got, using remove() method.
            //And Calling savechanges to reflect changes to database.
            if (routeIdToDelete != null)
            {
                RouteMaster routeToDeleteFromDb = routeContext.RouteMasters.Find(routeIdToDelete);
                routeContext.RouteMasters.Remove(routeToDeleteFromDb);
                routeContext.SaveChanges();
            }
        }

    }
}
