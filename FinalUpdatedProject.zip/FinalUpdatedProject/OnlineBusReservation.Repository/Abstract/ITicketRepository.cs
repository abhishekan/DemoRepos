﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface ITicketRepository
    {
        void AddNewTicket(Ticket ticketAddToDb);
        IEnumerable<Ticket> GetAllTickets();
        IEnumerable<Ticket> GetTicketByUserName(string userName);
        void UpdateTicket(Ticket ticketFromApi);
        void DeleteTicketByTicketId(int? ticketIdToDelete);
        IEnumerable<Ticket> SearchTicketByTicketNo(string name);
        Ticket GetTicketByTicketNo(string ticketNo, string source);
        Ticket GetTicketByTicket(int ticketId);
    }
}
