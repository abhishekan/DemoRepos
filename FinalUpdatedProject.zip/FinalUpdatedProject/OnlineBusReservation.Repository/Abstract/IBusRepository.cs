﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface IBusRepository
    {
        void AddNewBus(Bus busAddToDb);
        IEnumerable<Bus> GetAllBuses();
        Bus GetBusByBusId(int? busIdToSearch);
        void UpdateBus(Bus busFromApi);
        void DeleteBusByBusId(int? busIdToDelete);
        Bus SearchReturnBusToGetBusId(int id, DateTime dateOfJourney);
        IEnumerable<Bus> SearchBusByUserChoice(string source, string destination, string category, string timeSlot, DateTime journetDate, DateTime? returnDateToSearch);
        void UpdateBusByAdmin(Bus busFromApi);
    }
}
