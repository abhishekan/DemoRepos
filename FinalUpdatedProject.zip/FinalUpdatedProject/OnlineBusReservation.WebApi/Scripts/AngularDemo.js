﻿var busApp = angular.module('OnlineBusReservation', []);

busApp.controller('busController', function ($scope, $http, busService) {
    $scope.busList = null;
    busService.GetAllBuses().then(function (busesFound) {
        $scope.busList = busesFound.data;
    }, function () {
        alert("No Buses found");
    });
});

$scope.Bus = {
    BusId:'',
    BusName:''
};

busApp.factory('busService', function ($http) {
    var buses = {};
    buses.GetAllBuses = function () {
        return $http.get("http://localhost:50775/api/bus");
    }
    return buses;
});
