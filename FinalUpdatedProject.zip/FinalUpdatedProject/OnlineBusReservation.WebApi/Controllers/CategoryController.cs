﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class CategoryController : ApiController
    {
        ICategoryRepository categoryRepository = new CategoryRepository();

        public IHttpActionResult Get()
        {
            IEnumerable<Category> categoryListToReturn = categoryRepository.GetAllCategories();
            if (categoryListToReturn == null)
            {
                return NotFound();
            }
            return Ok(categoryListToReturn);
        }

        [HttpGet]
        public IHttpActionResult Get(int? id)
        {
            if (id != null)
            {
                Category categoryFound = categoryRepository.GetCategoryByCategoryId(id);
                if (categoryFound != null)
                {
                    return Ok(categoryFound);
                }
            }
            return NotFound();
        }


        public IHttpActionResult PostCategory([FromBody]Category categoryToAddToDb)
        {
            categoryRepository.AddNewCategory(categoryToAddToDb);
            return Created(Request.RequestUri + "/" + categoryToAddToDb.CategoryId, categoryToAddToDb);
        }

        public IHttpActionResult PutCategory([FromBody]Category categoryToUpdate)
        {
            if (categoryToUpdate != null)
            {
                categoryRepository.UpdateCategory(categoryToUpdate);
                return Ok();
            }
            return NotFound();
        }

        public IHttpActionResult DeleteCategory(int? id)
        {
            if (id != 0)
            {
                categoryRepository.DeleteCategoryByCategoryId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
