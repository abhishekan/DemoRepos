﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace OnlineBusReservation.WebApi.Controllers
{
    [EnableCors(origins: "http://localhost:62359", headers: "*", methods: "*")]
    public class SubRouteController : ApiController
    {
        /// <summary>
        /// Creating instance of routeRepository
        /// </summary>
        ISubRouteRepository routeRepository = new SubRouteRepository();

        /// <summary>
        /// Webapi Get method to get all the subroutes from Db 
        /// </summary>
        /// <returns></returns>
        public IHttpActionResult Get()
        {
            IEnumerable<SubRoute> subRouteListToReturn = routeRepository.GetAllSubRoutes();

            if (subRouteListToReturn == null)
            {
                return NotFound();
            }
            return Ok(subRouteListToReturn);
        }





        /// <summary>
        /// Get method to get datails about perticular subroute by it's id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public IHttpActionResult Get(int Id)
        {
            SubRoute subRouteFound = routeRepository.GetSubRouteBySubRouteId(Id);

            if (subRouteFound == null)
            {
                return NotFound();
            }
            return Ok(subRouteFound);
        }

        public IHttpActionResult Get(int routeMasterId, String source, String destination)
        {
            SubRoute subRouteFound = routeRepository.GetSubRouteByRouteMasterSourceDestination(routeMasterId, source, destination);

            if (subRouteFound == null)
            {
                return NotFound();
            }
            return Ok(subRouteFound);
        }
        /// <summary>
        ///  Webapi Post method to Add  the subroutes into Db 
        /// 
        /// </summary>
        /// <param name="subRouteToAdd"></param>
        /// <returns></returns>
        public IHttpActionResult Post([FromBody]SubRoute subRouteToAdd)
        {
            routeRepository.AddNewSubRoute(subRouteToAdd);
            return Ok();

        }

        /// <summary>
        /// webApi PutMethod to update the Subroute
        /// </summary>
        /// <param name="subRouteToAdd"></param>
        /// <returns></returns>
        public IHttpActionResult Put([FromBody]SubRoute subRouteToAdd)
        {
            routeRepository.UpdateSubRoute(subRouteToAdd);
            return Ok();

        }



        /// <summary>
        /// WebApi Delete method to delete the perticular SubRoute
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult Delete(int? id)
        {
            routeRepository.DeleteSubRouteBysubRouteId(id);
            return Ok();

        }
    
    }
}
