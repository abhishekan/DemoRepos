﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class TicketController : ApiController
    {
        ITicketRepository ticketRepository = new TicketRepository();

        //Get Method for DISPLAYING ALL the Tickets.
        public IHttpActionResult Get()
        {
            IEnumerable<Ticket> ticketListToReturn = ticketRepository.GetAllTickets();
            if (ticketListToReturn == null)
            {
                return NotFound();
            }
            return Ok(ticketListToReturn);
        }

        //Get Method for DISPLAYING the Ticket by id.
        [HttpGet]
        public IHttpActionResult Get(string id)
        {
            IEnumerable<Ticket> ticketFound = ticketRepository.GetTicketByUserName(id);
            if (ticketFound == null)
            {
                return NotFound();
            }
            return Ok(ticketFound);
        }

        public IHttpActionResult Get(int ticketId)
        {
            Ticket ticketFound = ticketRepository.GetTicketByTicket(ticketId);
            if (ticketFound == null)
            {
                return NotFound();
            }
            return Ok(ticketFound);
        }


        //[HttpGet]
        //public IHttpActionResult Get(int ticketId)
        //{
        //    Ticket ticketFound = ticketRepository.GetTicketByTicketId(ticketId);
        //    if (ticketFound == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(ticketFound);
        //}

        public IHttpActionResult Get(string ticketNo, string source)
        {
            Ticket ticketIdFound = ticketRepository.GetTicketByTicketNo(ticketNo, source);
            if (ticketIdFound == null)
            {
                return NotFound();
            }
            return Ok(ticketIdFound);
        }

        //Post Method for ADDING a Ticket.
        public IHttpActionResult PostTicket([FromBody]Ticket ticketToAddToDb)
        {
            ticketRepository.AddNewTicket(ticketToAddToDb);
            return Created(Request.RequestUri + "/" + ticketToAddToDb.TicketId, ticketToAddToDb);
        }

        //Put Method for UPDATING the Ticket by id.
        public IHttpActionResult PutTicket([FromBody]Ticket ticketToUpdate)
        {
            if (ticketToUpdate != null)
            {
                ticketRepository.UpdateTicket(ticketToUpdate);
                return Ok();
            }
            return NotFound();
        }

        //Delete Method for DELETING the Ticket by id.
        public IHttpActionResult DeleteTicket(int? id)
        {
            if (id != 0)
            {
                ticketRepository.DeleteTicketByTicketId(id);
                return Ok();
            }
            return NotFound();
        }

        //Get Method for SEARCHING the Ticket by Ticket Number.
        //public IHttpActionResult Get(string name)
        //{
        //    IEnumerable<Ticket> ticketListToReturn = ticketRepository.SearchTicketByTicketNo(name);
        //    return Ok(ticketListToReturn);
        //}
    }
}
