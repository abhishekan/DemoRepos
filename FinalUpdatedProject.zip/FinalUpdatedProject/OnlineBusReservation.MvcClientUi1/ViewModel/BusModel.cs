﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineBusReservation.MvcClientUi1.ViewModel
{
    public class BusModel
    {
        public List<BusModel> passengerToSave =new List<BusModel>();
        public string dateShow { get; set; }
        public string returnDateShow { get; set; }
        public int BusId { get; set; }
        public string busAvailableDay { get; set; }

        [Required]
        [RegularExpression("^[0-9: ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string TimeSlot{ get; set; }
        public  int[] seatNoToShow = new int[5];
        public int[] seatNoToShowForRoundTrip = new int[5];
        public bool[] seatForVisualization = new bool[30];

        [Required]
        [RegularExpression("^[a-zA-Z0-9() ]+$", ErrorMessage = "*Only characters are allowed.")]     
        public string BusName { get; set; }

        [Required]
        [RegularExpression(@"^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$", ErrorMessage = "Invalid Time.")]
        public System.TimeSpan DepartureTime { get; set; }

        [Required]
        [RegularExpression(@"^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$", ErrorMessage = "Invalid Time.")]
        public System.TimeSpan ArrivalTime { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        [Range(1,30)]
        public int TotalSeats { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        public int AvailableSeats { get; set; }
        public int CategoryId { get; set; }
        public int RouteMasterId { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string CategoryName { get; set; }

        public int SubRouteId { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string Source { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string Destination { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        public int Distance { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        [Range(1,50)]
        public int StopNo { get; set; }


        public int TicketId { get; set; }
        public string TicketNo { get; set; }

        [Required]
        [RegularExpression("^[0-9:/ ]+$", ErrorMessage = "*Only numbers are allowed.")]
        public System.DateTime JourneyDate { get; set; }

        [Required]
        [RegularExpression("^[0-9:/ ]+$", ErrorMessage = "*Only numbers are allowed.")]
        public System.DateTime? ReturnDate { get; set; }

        public string JourneyDateTodisplay { get; set; }
        public string ReturnDateTodisplay { get; set; }
        public decimal Fare { get; set; }
        public System.DateTime BookingDate { get; set; }
        public string BookingStatus { get; set; }
        public int SeatArrangementId { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public int PassengerId { get; set; }

        [Required]
        public string radioSelect;

        [Required]
        public string RouteName { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        [Range(1, 5)]
        public int NumberOfTickets{get;set;}

        [Required]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string PassengerName { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        [Range(0, 120)]
        public int PassengerAge { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "*Only characters are allowed.")]
        public string Gender { get; set; }

        [Required]
        [RegularExpression("^[0-9 ]+$", ErrorMessage = "*Only numbers are allowed.")]
        public int SeatNumber { get; set; } 
    }
}