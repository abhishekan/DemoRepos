﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using OnlineBusReservation.WebApi.ViewModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{   
    [Authorize]
    public class BusController : Controller
    {
        HttpClient client;

        string url = "http://localhost:50775/api/bus";
        string urlForRoute = "http://localhost:50775/api/RouteMaster";
        string urlForCategoryName = "http://localhost:50775/api/Category";

        public BusController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This is home page that will be rendered to user upon first visit.
        /// </summary>
        /// <returns>Return view with search options.</returns>
        [Authorize(Roles="admin")]
        public async Task<ActionResult> Index()
        {
            //Calling web api 
            try
            {

                HttpResponseMessage responseMessage = await client.GetAsync(url);

                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var busListFromDb = JsonConvert.DeserializeObject<List<Bus>>(responseData);

                    List<BusModel> busModel = new List<BusModel>();

                    foreach (var itr in busListFromDb)
                    {
                        BusModel busToPassToView = new BusModel();
                        busToPassToView.BusId = itr.BusId;
                        busToPassToView.BusName = itr.BusName;
                        busToPassToView.ArrivalTime = itr.ArrivalTime;
                        busToPassToView.DepartureTime = itr.DepartureTime;
                        busToPassToView.CategoryId = itr.CategoryId;
                        busToPassToView.TotalSeats = itr.TotalSeats;
                        busToPassToView.RouteMasterId = itr.RouteMasterId;
                        busToPassToView.AvailableSeats = itr.AvailableSeats;

                        HttpResponseMessage responseMessageForCategory = await client.GetAsync(urlForCategoryName + "/" + itr.CategoryId);
                        if (responseMessageForCategory.IsSuccessStatusCode)
                        {
                            var responseDataForcategory = responseMessageForCategory.Content.ReadAsStringAsync().Result;

                            var categoryToDisplay = JsonConvert.DeserializeObject<Category>(responseDataForcategory);
                            busToPassToView.CategoryName = categoryToDisplay.CategoryName;

                            HttpResponseMessage responseMessageForRouteName = await client.GetAsync(urlForRoute + "/" + itr.CategoryId);
                            if (responseMessageForRouteName.IsSuccessStatusCode)
                            {
                                var responseDataForRouteName = responseMessageForRouteName.Content.ReadAsStringAsync().Result;

                                var routeToDisplay = JsonConvert.DeserializeObject<RouteMaster>(responseDataForRouteName);
                                busToPassToView.RouteName = routeToDisplay.RouteName;
                                busModel.Add(busToPassToView);
                            }
                        }
                    }
                    return View(busModel);
                }

                return View("Error");
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method used to details of the bus according to bus id entered by user.
        /// </summary>
        /// <param name="idOfBus">This is bus Id whose information needs to be displayed.</param>
        /// <returns>View showing details of bus.</returns>
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Details(int? idOfBus)
        {
            try
            {

                if (idOfBus != null)
                {
                    //Calling 
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + idOfBus);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var busToDisplayDetails = JsonConvert.DeserializeObject<Bus>(responseData);

                        if (busToDisplayDetails != null)
                        {
                            BusModel busToPassToView = new BusModel();
                            busToPassToView.BusId = busToDisplayDetails.BusId;
                            busToPassToView.BusName = busToDisplayDetails.BusName;
                            busToPassToView.ArrivalTime = busToDisplayDetails.ArrivalTime;
                            busToPassToView.DepartureTime = busToDisplayDetails.DepartureTime;
                            busToPassToView.CategoryId = busToDisplayDetails.CategoryId;
                            busToPassToView.TotalSeats = busToDisplayDetails.TotalSeats;
                            busToPassToView.RouteMasterId = busToDisplayDetails.RouteMasterId;

                            return View(busToPassToView);
                        }
                    }

                }
                return View("Error");
            }
            catch (Exception e)
            {
             return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method is used to pass the empty Busmodel object to view which will be filled by user
        /// and used to save into database.
        /// </summary>
        /// <returns>Returns view that shows all the fields of busmodel</returns>
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Create()
        {
            try
            {
                List<SelectListItem> items = new List<SelectListItem>();
                List<SelectListItem> routeItems = new List<SelectListItem>();

                ViewBag.choice = "";

                //to get values from category drop down list
                items.Add(new SelectListItem { Text = "AC", Value = "AC" });

                items.Add(new SelectListItem { Text = "Non-Ac", Value = "Non-Ac" });

                items.Add(new SelectListItem { Text = "Sleeper", Value = "Sleeper" });

                items.Add(new SelectListItem { Text = "Semi-Sleeper", Value = "Semi-Sleeper" });
                ViewBag.categoryDropDownList = items;

                HttpResponseMessage responseMessage = await client.GetAsync(urlForRoute);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    //Deserializing the bus object which we got from web api.
                    IEnumerable<RouteMaster> routes = JsonConvert.DeserializeObject<List<RouteMaster>>(responseData);

                    foreach (var itr in routes)
                    {
                        routeItems.Add(new SelectListItem { Text = itr.RouteName, Value = itr.RouteMasterId.ToString() });
                    }
                    ViewBag.routeDropDownList = routeItems;
                }

                return View(new BusModel());
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This is post method that will save object received from view in database throgh web api.
        /// </summary>
        /// <param name="BusToAdd">This is busmodel object submitted by user to save.</param>
        /// <returns>View with saved object</returns>
        [HttpPost]
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Create(BusModel BusToAdd, FormCollection form, string[] days)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //to add category id to bus model object
                    if (form["categoryDropDownList"].ToString() == "AC")
                    {
                        BusToAdd.CategoryId = 1;
                    }
                    else if (form["categoryDropDownList"].ToString() == "Non-Ac")
                    {
                        BusToAdd.CategoryId = 2;
                    }
                    else if (form["categoryDropDownList"].ToString() == "Sleeper")
                    {
                        BusToAdd.CategoryId = 3;
                    }
                    else
                    {
                        BusToAdd.CategoryId = 4;
                    }


                    //to add RouteMaster Id to bus object
                    BusToAdd.RouteMasterId = Convert.ToInt32(form["routeDropDownList"].ToString());


                    //to add BusAvaialableDays to bus model object
                    string busAvailablibility = "";
                    for (int i = 1; i <= days.Length; i++)
                    {
                        busAvailablibility += days[i - 1];
                    }

                    BusToAdd.busAvailableDay = busAvailablibility;


                    HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, BusToAdd);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }                  
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
                 return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method is used to fetch the details of bus object whose id is selected by user.  
        /// </summary>
        /// <param name="id">This is bus id of which information we need to fetch.</param>
        /// <returns>View showing details of bus object.</returns>
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Edit(int? id)
        {
            try
            {
                List<SelectListItem> routeItems = new List<SelectListItem>();
                ViewBag.choice = "";

                //Calling web api to get the bus object for user to update.
                if (id != null)
                {
                    HttpResponseMessage responseMessageForRoutes = await client.GetAsync(urlForRoute);
                    if (responseMessageForRoutes.IsSuccessStatusCode)
                    {
                        var responseData = responseMessageForRoutes.Content.ReadAsStringAsync().Result;

                        //Deserializing the bus object which we got from web api.
                        IEnumerable<RouteMaster> routes = JsonConvert.DeserializeObject<List<RouteMaster>>(responseData);

                        foreach (var itr in routes)
                        {
                            routeItems.Add(new SelectListItem { Text = itr.RouteName, Value = itr.RouteMasterId.ToString() });
                        }
                        ViewBag.routeDropDownList = routeItems;
                    }


                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        //Deserializing the bus object which we got from web api.
                        Bus busToUpdate = JsonConvert.DeserializeObject<Bus>(responseData);

                        //Assigning the value of bus object to viewmodel object and passing it to view.
                        if (busToUpdate != null)
                        {
                            BusModel busToPassToView = new BusModel();
                            busToPassToView.BusId = busToUpdate.BusId;
                            busToPassToView.BusName = busToUpdate.BusName;
                            busToPassToView.ArrivalTime = busToUpdate.ArrivalTime;
                            busToPassToView.DepartureTime = busToUpdate.DepartureTime;
                            busToPassToView.CategoryId = busToUpdate.CategoryId;
                            busToPassToView.TotalSeats = busToUpdate.TotalSeats;
                            busToPassToView.RouteMasterId = busToUpdate.RouteMasterId;

                            return View(busToPassToView);
                        }
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will update the information altered by user.
        /// </summary>
        /// <param name="busFromUser">This is modified bus object which we got from view.</param>
        /// <returns>Returns to index if operation is successful otherwise rendering error page.</returns>
        [Authorize(Roles = "admin")]
        [HttpPost]
        public async Task<ActionResult> Edit([Bind(Include = "BusId,ArrivalTime,DepartureTime,routeDropDownList")]BusModel busFromUser, FormCollection form)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    if (busFromUser != null)
                    {
                        //Calling web api to get the database bus object using the bus id of object submitted by user through view.
                        HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + busFromUser.BusId);
                        if (responseMessage.IsSuccessStatusCode)
                        {
                            var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                            var busToUpdateDetails = JsonConvert.DeserializeObject<Bus>(responseData);

                            ///Assigning the values of database bus object with the users updated bus object.
                            busToUpdateDetails.ArrivalTime = busFromUser.ArrivalTime;
                            busToUpdateDetails.DepartureTime = busFromUser.DepartureTime;
                            busToUpdateDetails.RouteMasterId = Convert.ToInt32(form["routeDropDownList"].ToString());

                            //Calling web api to make changes in the object of bus by passing modified bus object.
                            HttpResponseMessage responseMessage1 = await client.PutAsJsonAsync(url, busToUpdateDetails);
                            if (responseMessage1.IsSuccessStatusCode)
                            {
                                return RedirectToAction("Index");
                            }
                        }
                    }                  
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will allow the user to view the bus object before deleting it.
        /// </summary>
        /// <param name="busId">This is the bus id of bus which needs to be deleted.</param>
        /// <returns>Returns Details of bus object tobe deleted if operation is successfull otherwise error page.</returns>
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Delete(int? busId)
        {
            try
            {
                if (busId != null)
                {
                    //Calling the web api to get the bus object to show it to user.
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + busId);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        Bus busToDelete = JsonConvert.DeserializeObject<Bus>(responseData);

                        if (busToDelete != null)
                        {
                            BusModel busToPassToView = new BusModel();
                            busToPassToView.BusId = busToDelete.BusId;
                            busToPassToView.BusName = busToDelete.BusName;
                            busToPassToView.ArrivalTime = busToDelete.ArrivalTime;
                            busToPassToView.DepartureTime = busToDelete.DepartureTime;
                            busToPassToView.CategoryId = busToDelete.CategoryId;
                            busToPassToView.TotalSeats = busToDelete.TotalSeats;
                            busToPassToView.RouteMasterId = busToDelete.RouteMasterId;

                            return View(busToPassToView);
                        }
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This is post method which will actually delete bus object from database.
        /// </summary>
        /// <param name="BusId">This is the bus id of bus which needs to be deleted.</param>
        /// <returns>Returns index if operation is successfull otherwise error page.</returns>
        [HttpPost]
        [ActionName("Delete")]
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> DeleteBook(int? BusId)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling web api to delete the bus object by passing bus id.
                    if (BusId != null)
                    {
                        HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + BusId);
                        if (responseMessage.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                    } 
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        
        /// <summary>
        /// This is search method that will show the search field to user by passing proper viewmodel to view.
        /// </summary>
        /// <returns>Returns seach page with different search fields if operation is successful </returns>
        [AllowAnonymous]
        [ActionName(name:"Search")]
        public ActionResult Search()
        {
            try
            {
                //Adding different categories into items to show category dropdown.
                List<SelectListItem> items = new List<SelectListItem>();

                //ViewBag.choice = "";
                items.Add(new SelectListItem
                {
                    Text = "All",
                    Value = "All",
                    Selected = true
                });

                items.Add(new SelectListItem { Text = "AC", Value = "Ac" });

                items.Add(new SelectListItem { Text = "Non-Ac", Value = "Non-Ac" });

                items.Add(new SelectListItem { Text = "Sleeper", Value = "Sleeper" });

                items.Add(new SelectListItem { Text = "Semi-Sleeper", Value = "Semi-Sleeper" });
                ViewBag.categoryDropDownList = items;

                //Adding different Timeslots into items to show timeslot dropdown.
                List<SelectListItem> itemsForTimeSlot = new List<SelectListItem>();

                itemsForTimeSlot.Add(new SelectListItem
                {
                    Text = "All",
                    Value = "All",
                    Selected = true
                });

                itemsForTimeSlot.Add(new SelectListItem { Text = "06:00Hr-12:00Hr", Value = "06:00Hr-12:00Hr" });

                itemsForTimeSlot.Add(new SelectListItem { Text = "12:00Hr-18:00Hr", Value = "12:00Hr-18:00Hr" });

                itemsForTimeSlot.Add(new SelectListItem { Text = "18:00Hr-24:00Hr", Value = "18:00Hr-24:00Hr" });

                ViewBag.timeSlotDropDownList = itemsForTimeSlot;


                return View("SearchSelect");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }


        /// <summary>
        /// This is post method that will take parameters from view and render the list of buses according to those search values.
        /// </summary>
        /// <param name="source">This is the name of source from which passenger wishes to travels.</param>
        /// <param name="destination">This is the name of destination from which passenger wishes to travels.</param>
        /// <param name="form">This will take all values present on views.</param>
        /// <returns>Returns view having list of buses otherwise rendering error page.</returns>
        [HttpPost]
        [ActionName("Search")]
        [AllowAnonymous]
        public async Task<ActionResult> SearchBus(string source, string destination, FormCollection form)
        {
            try
            {
                //Getting values of category, timeslot, radiobuttonselected by user.
                string category = form["categoryDropDownList"].ToString();
                string timeSlot = form["timeSlotDropDownList"].ToString();

                string radioSelect = form["RadioButton"].ToString();

                DateTime ReturnDate = DateTime.MinValue;
                DateTime? returnDateToSearch = null;

                //Assigning values of return date if user has selected Round Trip
                if (radioSelect == "Round Trip")
                {
                    ReturnDate = Convert.ToDateTime(form["ReturnDateOfJourney"].ToString());
                    returnDateToSearch = Convert.ToDateTime(form["ReturnDateOfJourney"].ToString());
                }

                //Getting  date of journey from search page.
                DateTime journeyDate = Convert.ToDateTime(form["dateOfJourney"].ToString());

                if (source != null)
                {
                    //Callingthe web api to check whether the bus is avilable on that date of Journey.
                    string urlToSerach = String.Format("http://localhost:50775/api/bus?source={0}&destination={1}&category={2}&timeSlot={3}&journetDate={4}&returnDateToSearch={5}", source, destination, category, timeSlot, journeyDate, returnDateToSearch);
                    HttpResponseMessage responseMessage = await client.GetAsync(urlToSerach);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var busToDisplayDetails = JsonConvert.DeserializeObject<List<Bus>>(responseData);

                        //Passing the data got fro web api to view to render the List of buses to user.
                        List<BusModel> busModel = new List<BusModel>();

                        foreach (var itr in busToDisplayDetails)
                        {
                            BusModel busToPassToView = new BusModel();
                            busToPassToView.BusId = itr.BusId;
                            busToPassToView.BusName = itr.BusName;
                            busToPassToView.ArrivalTime = itr.ArrivalTime;
                            busToPassToView.DepartureTime = itr.DepartureTime;
                            busToPassToView.CategoryId = itr.CategoryId;
                            busToPassToView.TotalSeats = itr.TotalSeats;
                            busToPassToView.RouteMasterId = itr.RouteMasterId;
                            busToPassToView.Source = source;
                            busToPassToView.Destination = destination;
                            busToPassToView.AvailableSeats = itr.AvailableSeats;
                            busToPassToView.TimeSlot = timeSlot;
                            busToPassToView.ReturnDate = ReturnDate;
                            busToPassToView.radioSelect = radioSelect;
                            busToPassToView.JourneyDate = journeyDate;
                            busToPassToView.dateShow = journeyDate.Date.ToString("d");
                            if (radioSelect == "One Way")
                            {
                                busToPassToView.ReturnDate = null;
                            }

                            busModel.Add(busToPassToView);
                        }
                        return View(busModel);
                    }
                }
                return View("NoBusesFound");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will select the bus chosen by user and will proceed to book tickets.
        /// </summary>
        /// <param name="id">This is id of bus.</param>
        ///  <param name="source">This is the name of source from which passenger wishes to travels.</param>
        /// <param name="destination">This is the name of destination from which passenger wishes to travels.</param>
        /// <param name="returnDate">This is return date of journey</param>
        /// <param name="radioSelect">This will decide type of journey.</param>
        /// <param name="journeydate">This is journey date.</param>
        /// <returns>Returns the view asking for number of tickets.</returns>
 
        public async Task<ActionResult> BookBus(int id, string source, string destination, DateTime? returnDate, string radioSelect, DateTime? journeydate)
        {
            try
            {
                if (id != null)
                {
                    //Calling the web api to get the details of bus selected by user.
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var busToDisplayDetails = JsonConvert.DeserializeObject<Bus>(responseData);

                        //Passing the details of bus to view.
                        if (busToDisplayDetails != null)
                        {
                            BusModel busToPassToView = new BusModel();
                            busToPassToView.BusId = busToDisplayDetails.BusId;
                            busToPassToView.BusName = busToDisplayDetails.BusName;
                            busToPassToView.ArrivalTime = busToDisplayDetails.ArrivalTime;
                            busToPassToView.DepartureTime = busToDisplayDetails.DepartureTime;
                            busToPassToView.CategoryId = busToDisplayDetails.CategoryId;
                            busToPassToView.TotalSeats = busToDisplayDetails.TotalSeats;
                            busToPassToView.RouteMasterId = busToDisplayDetails.RouteMasterId;
                            busToPassToView.Source = source;
                            busToPassToView.Destination = destination;
                            busToPassToView.AvailableSeats = busToDisplayDetails.AvailableSeats;
                            busToPassToView.ReturnDate = returnDate;
                            busToPassToView.radioSelect = radioSelect;
                            busToPassToView.JourneyDate = (DateTime)journeydate;
                            busToPassToView.dateShow = busToPassToView.JourneyDate.Date.ToString("d");

                            if (busToPassToView.ReturnDate != null)
                            {
                                busToPassToView.returnDateShow = ((DateTime)busToPassToView.ReturnDate).Date.ToString("d");
                            }
                            return View(busToPassToView);
                        }
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
                 return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will allow user to enter the passenger details.
        /// </summary>
        /// <param name="busToPass">This is Viewmodel object from view containing the information regarding Journey.</param>
        /// <returns>Returns view to entre passenger details.</returns>
       
        public async Task<ActionResult> ProceedToEnterPassengerDetails(BusModel busToPass)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    busToPass.dateShow = busToPass.JourneyDate.Date.ToString("d");

                    string urlToSerach = String.Format("http://localhost:50775/api/seatarrangement?busId={0}&dateOfBooking={1}", busToPass.BusId, busToPass.JourneyDate);

                    HttpResponseMessage responseMessageOfSeats = await client.GetAsync(urlToSerach);

                    if (responseMessageOfSeats.IsSuccessStatusCode)
                    {
                        var responseDataAboutSeats = responseMessageOfSeats.Content.ReadAsStringAsync().Result;

                        List<SeatArrangement> seatListFromDb = JsonConvert.DeserializeObject<List<SeatArrangement>>(responseDataAboutSeats);
                        for (int i = 0; i < 30; i++)
                        {
                            if (i < seatListFromDb.Count)
                            {
                                busToPass.seatForVisualization[i] = true;
                            }
                            else
                            {
                                busToPass.seatForVisualization[i] = false;
                            }
                        }
                        if (busToPass.ReturnDate != null)
                        {
                            busToPass.returnDateShow = ((DateTime)busToPass.ReturnDate).Date.ToString("d");
                        }
                        ModelState.Clear();
                    }

                }
                return View(busToPass);
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will calculate the fare according to the passenger details entered by user.
        /// </summary>
        /// <param name="ticketCalculate">This Viewmodel onject passed from view</param>
        /// <param name="form">This will get  all values from view.</param>
        /// <returns>Returns view showing the total fare of one way journey.</returns>
  
        public async Task<ActionResult> TicketFareCalculate(BusModel ticketCalculate, FormCollection form)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling the web api to get distance from database.
                    string url1 = String.Format("http://localhost:50775/api/SubRoute?routeMasterId={0}&source={1}&destination={2}", ticketCalculate.RouteMasterId, ticketCalculate.Source, ticketCalculate.Destination);
                    HttpResponseMessage responseMessage = await client.GetAsync(url1);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var subRouteFromDb = JsonConvert.DeserializeObject<SubRoute>(responseData);
                        ticketCalculate.dateShow = ticketCalculate.JourneyDate.Date.ToString("d");

                        //This will get information of passenger from view.
                        var age = form["PassengerAge"];
                        int[] nums = age.Split(',').Select(int.Parse).ToArray();

                        var passengerName = form["PassengerName"];
                        String[] passengerNameList = passengerName.Split(',').ToArray();

                        var passengerGender = form["Gender"];
                        String[] passengerGenderList = passengerGender.Split(',').ToArray();


                        if (ticketCalculate.ReturnDate != null)
                        {
                            ticketCalculate.returnDateShow = ((DateTime)ticketCalculate.ReturnDate).Date.ToString("d");
                        }
                        ticketCalculate.SubRouteId = subRouteFromDb.SubRouteId;

                        //Calculates the total fare according to the age of passenger, distance and category.
                        if (ticketCalculate != null)
                        {
                            switch (ticketCalculate.CategoryId)
                            {
                                case 1:
                                    for (int i = 1; i <= ticketCalculate.NumberOfTickets; i++)
                                    {

                                        int ageToCheck = nums[i - 1];
                                        if (ageToCheck > 16)
                                        {
                                            ticketCalculate.Fare += 2 * subRouteFromDb.Distance;
                                        }
                                        else if (ageToCheck < 16 && ageToCheck > 5)
                                        {
                                            ticketCalculate.Fare += Convert.ToDecimal(1.75 * subRouteFromDb.Distance);
                                        }
                                        else
                                        {
                                        }
                                    }
                                    break;
                                case 2:
                                    for (int i = 1; i <= ticketCalculate.NumberOfTickets; i++)
                                    {

                                        int ageToCheck = nums[i - 1];
                                        if (ageToCheck > 16)
                                        {
                                            ticketCalculate.Fare += 2 * subRouteFromDb.Distance;
                                        }
                                        else if (ageToCheck < 16 && ageToCheck > 5)
                                        {
                                            ticketCalculate.Fare += Convert.ToDecimal(1.75 * subRouteFromDb.Distance);
                                        }
                                        else
                                        {
                                        }
                                    }
                                    break;
                                case 3:
                                    for (int i = 1; i <= ticketCalculate.NumberOfTickets; i++)
                                    {

                                        int ageToCheck = nums[i - 1];
                                        if (ageToCheck > 16)
                                        {
                                            ticketCalculate.Fare += 2 * subRouteFromDb.Distance;
                                        }
                                        else if (ageToCheck < 16 && ageToCheck > 5)
                                        {
                                            ticketCalculate.Fare += Convert.ToDecimal(1.75 * subRouteFromDb.Distance);
                                        }
                                        else
                                        {
                                        }
                                    }
                                    break;
                                case 4:
                                    for (int i = 1; i <= ticketCalculate.NumberOfTickets; i++)
                                    {

                                        int ageToCheck = nums[i - 1];
                                        if (ageToCheck > 16)
                                        {
                                            ticketCalculate.Fare += 2 * subRouteFromDb.Distance;
                                        }
                                        else if (ageToCheck < 16 && ageToCheck > 5)
                                        {
                                            ticketCalculate.Fare += Convert.ToDecimal(1.75 * subRouteFromDb.Distance);
                                        }
                                        else
                                        {
                                        }
                                    }
                                    break;
                            }

                            for (int i = 1; i <= ticketCalculate.NumberOfTickets; i++)
                            {
                                BusModel passengersInList = new BusModel();
                                passengersInList.PassengerName = passengerNameList[i - 1];
                                passengersInList.PassengerAge = nums[i - 1];

                                passengersInList.Gender = passengerGenderList[i - 1];
                                ticketCalculate.passengerToSave.Add(passengersInList);
                            }
                            return View(ticketCalculate);
                        }
                    }   
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will book ticket, add passenger and make changes to bus database.
        /// </summary>
        /// <param name="busPassengerToSave">This is object from view.</param>
        /// <param name="form">This will get all values present in database.</param>
        /// <returns></returns>

        [HttpPost]
        public async Task<ActionResult> PayForBookingBus(BusModel busPassengerToSave, FormCollection form)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    Ticket ticketidFromDb = null;
                    string urlForSeat = "http://localhost:50775/api/Ticket";
                    string urlToGetTicketCount = "http://localhost:50775/api/Ticket";
                    string urlToSavePassenger = "http://localhost:50775/api/Passenger";
                    string urlToBusUpdate = "http://localhost:50775/api/bus";

                    //This will get passenger details from view.
                    var age = form["itr.PassengerAge"];
                    int[] passengerAgeArray = age.Split(',').Select(int.Parse).ToArray();

                    var passengerName = form["itr.PassengerName"];
                    String[] passengerNameList = passengerName.Split(',').ToArray();

                    var passengerGender = form["itr.Gender"];
                    String[] passengerGenderList = passengerGender.Split(',').ToArray();

                    busPassengerToSave.dateShow = busPassengerToSave.JourneyDate.Date.ToString("d");

                    for (int i = 1; i <= busPassengerToSave.NumberOfTickets; i++)
                    {
                        //Calling web api to get the count of all tickets in database.
                        HttpResponseMessage responseMessageToGetTicketCount = await client.GetAsync(urlToGetTicketCount + "/");

                        if (responseMessageToGetTicketCount.IsSuccessStatusCode)
                        {
                            var responseDataToGetTicketCount = responseMessageToGetTicketCount.Content.ReadAsStringAsync().Result;

                            var ticketCount = JsonConvert.DeserializeObject<List<Ticket>>(responseDataToGetTicketCount);

                            //Assigning unique ticket no.
                            var latestTicketCount = ticketCount.Count() + 1;
                            busPassengerToSave.TicketNo = busPassengerToSave.JourneyDate.Day.ToString() + busPassengerToSave.JourneyDate.Month.ToString() + busPassengerToSave.JourneyDate.Year.ToString() + "-" + busPassengerToSave.SubRouteId + "-" + busPassengerToSave.BusId + "-" + latestTicketCount;
                            busPassengerToSave.BookingDate = DateTime.Now;
                            var userId = User.Identity.GetUserId();
                            busPassengerToSave.UserId = userId;

                            //Save Ticket TO Database by calling web api.
                            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(urlForSeat, busPassengerToSave);
                            if (responseMessage.IsSuccessStatusCode)
                            {

                                //Get TicketId Using TicketNo for saving passenger details in database.
                                string urlToGetTicketId = String.Format("http://localhost:50775/api/ticket?ticketNo={0}&source={1}", busPassengerToSave.TicketNo, busPassengerToSave.Source);

                                HttpResponseMessage responseMessageToGetTicketId = await client.GetAsync(urlToGetTicketId + "/");

                                if (responseMessageToGetTicketId.IsSuccessStatusCode)
                                {
                                    var responseDataToGetTicketId = responseMessageToGetTicketId.Content.ReadAsStringAsync().Result;

                                    ticketidFromDb = JsonConvert.DeserializeObject<Ticket>(responseDataToGetTicketId);

                                    busPassengerToSave.TicketId = ticketidFromDb.TicketId;
                                    busPassengerToSave.UserId = userId;

                                    busPassengerToSave.radioSelect = form["radioSelect"];
                                    if (form["radioSelect"] == "Round Trip")
                                    {
                                        busPassengerToSave.seatNoToShow[i - 1] = Convert.ToInt32(form[string.Format("seatNoToShow[{0}]", i - 1)]);
                                        busPassengerToSave.seatNoToShowForRoundTrip[i - 1] = ticketidFromDb.SeatArrangementId;
                                        busPassengerToSave.ReturnDateTodisplay = busPassengerToSave.JourneyDate.Date.ToString("d");

                                    }
                                    else
                                    {
                                        busPassengerToSave.seatNoToShow[i - 1] = ticketidFromDb.SeatArrangementId;
                                    }

                                    busPassengerToSave.PassengerName = passengerNameList[i - 1];
                                    busPassengerToSave.Gender = passengerGenderList[i - 1];

                                    busPassengerToSave.PassengerAge = passengerAgeArray[i - 1];

                                    busPassengerToSave.PassengerName = passengerNameList[i - 1];
                                    busPassengerToSave.PassengerAge = passengerAgeArray[i - 1];

                                    busPassengerToSave.Gender = passengerGenderList[i - 1];

                                    //Saving passenger in database by calling web api.
                                    HttpResponseMessage responseMessageToSavePassenger = await client.PostAsJsonAsync(urlToSavePassenger, busPassengerToSave);
                                    if (responseMessageToSavePassenger.IsSuccessStatusCode)
                                    {
                                        //Calling web api to update available seats in Bus table.
                                        HttpResponseMessage responseMessageToUpdateBus = await client.PutAsJsonAsync(urlToBusUpdate, busPassengerToSave);
                                        if (responseMessageToUpdateBus.IsSuccessStatusCode)
                                        {
                                            if (form["radioSelect"] != "Round Trip")
                                            {
                                                busPassengerToSave.JourneyDateTodisplay = busPassengerToSave.JourneyDate.Date.ToString("d");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //Adding passenger to list to pass it to return view.
                    for (int k = 1; k <= busPassengerToSave.NumberOfTickets; k++)
                    {
                        BusModel passengerIntoList = new BusModel();
                        passengerIntoList.PassengerName = passengerNameList[k - 1];
                        passengerIntoList.PassengerAge = passengerAgeArray[k - 1];

                        passengerIntoList.Gender = passengerGenderList[k - 1];
                        busPassengerToSave.passengerToSave.Add(passengerIntoList);
                    }

                    //Checking if user has opted for return journey.
                    if (busPassengerToSave.ReturnDate != null)
                    {
                        //Assigning source to destination and vice-versa.
                        string ss = busPassengerToSave.Source;
                        string dd = busPassengerToSave.Destination;
                        busPassengerToSave.Source = dd;
                        busPassengerToSave.Destination = ss;



                        //Calling web api to get the subroute id of return journey.
                        string urlForReturnJourneySubRouteId = String.Format("http://localhost:50775/api/SubRoute?routeMasterId={0}&source={1}&destination={2}", busPassengerToSave.RouteMasterId, busPassengerToSave.Source, busPassengerToSave.Destination);
                        HttpResponseMessage subRouteIdToGet = await client.GetAsync(urlForReturnJourneySubRouteId);

                        if (subRouteIdToGet.IsSuccessStatusCode)
                        {
                            var responseDataFroSubRoute = subRouteIdToGet.Content.ReadAsStringAsync().Result;
                            var subRouteId = JsonConvert.DeserializeObject<SubRoute>(responseDataFroSubRoute);

                            //Calling the web api to get bus id of same bus returning from that destination.
                            string UrlToAssignBusId = String.Format("http://localhost:50775/api/Bus?dateOfJourney={0}&id={1}", busPassengerToSave.ReturnDate, busPassengerToSave.BusId);
                            HttpResponseMessage responseDataForBusIdOnReturn = await client.GetAsync(UrlToAssignBusId);

                            if (responseDataForBusIdOnReturn.IsSuccessStatusCode)
                            {
                                var responseDataForBusId = responseDataForBusIdOnReturn.Content.ReadAsStringAsync().Result;
                                var busIdToGet = JsonConvert.DeserializeObject<Bus>(responseDataForBusId);

                                //Assigning return date as journey date for round trip.
                                busPassengerToSave.JourneyDateTodisplay = busPassengerToSave.JourneyDate.Date.ToString("d");

                                busPassengerToSave.radioSelect = "Round Trip";
                                //making return date null.
                                busPassengerToSave.JourneyDate = (DateTime)busPassengerToSave.ReturnDate;
                                busPassengerToSave.ReturnDate = null;

                                busPassengerToSave.SubRouteId = subRouteId.SubRouteId;
                                busPassengerToSave.BusId = busIdToGet.BusId;

                                busPassengerToSave.ArrivalTime = busPassengerToSave.DepartureTime;
                                busPassengerToSave.DepartureTime = busIdToGet.DepartureTime;
                                busPassengerToSave.dateShow = busPassengerToSave.JourneyDate.Date.ToString("d");

                                ModelState.Clear();
                                return View(busPassengerToSave);
                            }
                        }
                    }

                }
                return View("FinalBill", busPassengerToSave);
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
    }
    
	}
	
}
