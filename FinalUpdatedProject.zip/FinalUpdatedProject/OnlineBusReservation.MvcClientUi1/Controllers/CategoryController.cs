﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{
    [Authorize(Roles = "admin")]
    public class CategoryController : Controller
    {
         HttpClient client;
         string url = "http://localhost:50775/api/category";

        public CategoryController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This method is action method that will return all categories. 
        /// </summary>
        /// <returns>Returns view showing all category information.</returns>
        public async Task<ActionResult> Index()
        {
            try
            {
                //Calling web api to get the information of all categories And pass that list to view.
                HttpResponseMessage responseMessage = await client.GetAsync(url);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var categoryListFromDb = JsonConvert.DeserializeObject<List<Category>>(responseData);

                    List<BusModel> categoryModel = new List<BusModel>();

                    foreach (var itr in categoryListFromDb)
                    {
                        BusModel categoryToPassToView = new BusModel();
                        categoryToPassToView.CategoryId = itr.CategoryId;
                        categoryToPassToView.CategoryName = itr.CategoryName;

                        categoryModel.Add(categoryToPassToView);
                    }
                    return View(categoryModel);
                }
                return View("Error");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This will show details of the selected category.
        /// </summary>
        /// <param name="idOfCategory"> This is id of category.</param>
        /// <returns>Returns index page if successful.</returns>
        public async Task<ActionResult> Details(int? idOfCategory)
        {
            try
            {
                if (idOfCategory != null)
                {
                    //Calling web api to get information of particular category. and pass it to view.
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + idOfCategory);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var categoryToDisplayDetails = JsonConvert.DeserializeObject<Category>(responseData);

                        BusModel categoryToPassToView = new BusModel();
                        categoryToPassToView.CategoryId = categoryToDisplayDetails.CategoryId;
                        categoryToPassToView.CategoryName = categoryToDisplayDetails.CategoryName;

                        return View(categoryToPassToView);
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
             return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This will allow to create the new category. 
        /// </summary>
        /// <returns>Returns view allowing user to add category.</returns>
        public ActionResult Create()
        {
            return View(new BusModel());
        }

        /// <summary>
        /// This method will save the category passed from view into database.
        /// </summary>
        /// <param name="categoryToAdd">Category object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Create(BusModel categoryToAdd)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling web api to save the category object into the database.
                    HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, categoryToAdd);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will show the data of particular bus which he has selected.
        /// </summary>
        /// <param name="idOfCategory">This is the id of bus tobe edited.</param>
        /// <returns>Returns the view with category details.</returns>
        public async Task<ActionResult> Edit(int? idOfCategory)
        {
            try
            {
                //Querying database to get details of bus.
                if (idOfCategory != null)
                {
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + idOfCategory);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        var categoryToUpdate = JsonConvert.DeserializeObject<Category>(responseData);

                        if (categoryToUpdate != null)
                        {
                            BusModel categoryToPassToView = new BusModel();
                            categoryToPassToView.CategoryId = categoryToUpdate.CategoryId;
                            categoryToPassToView.CategoryName = categoryToUpdate.CategoryName;

                            return View(categoryToPassToView);
                        }
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will save changes made by user to database.
        /// </summary>
        /// <param name="categoryFromUser">This category object edited by user.</param>
        /// <returns>Returns View with index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Edit([Bind(Include = "CategoryId,CategoryName")]BusModel categoryFromUser)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    if (categoryFromUser != null)
                    {
                        //Saving the altered object in database by calling web api.
                        HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + categoryFromUser.CategoryId);
                        if (responseMessage.IsSuccessStatusCode)
                        {
                            var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                            var categoryToUpdateDetails = JsonConvert.DeserializeObject<Category>(responseData);

                            categoryToUpdateDetails.CategoryName = categoryFromUser.CategoryName;

                            //Assigning the values of passed object to object got from database.
                            //Calling web api to save that changed object.
                            HttpResponseMessage responseMessage1 = await client.PutAsJsonAsync(url, categoryToUpdateDetails);
                            if (responseMessage1.IsSuccessStatusCode)
                            {
                                return RedirectToAction("Index");
                            }

                        }
                    }
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will show the details of object to be deleted.
        /// </summary>
        /// <param name="categoryId">This is id of category object to be deleted.</param>
        /// <returns>Return the view with all category details.</returns>
        public async Task<ActionResult> Delete(int? categoryId)
        {
            try
            {
                if (categoryId != null)
                {
                    //Querying the database to get details of category object.
                    HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + categoryId);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                        Category categoryToDelete = JsonConvert.DeserializeObject<Category>(responseData);

                        if (categoryToDelete != null)
                        {
                            BusModel categoryToPassToView = new BusModel();
                            categoryToPassToView.CategoryId = categoryToDelete.CategoryId;
                            categoryToPassToView.CategoryName = categoryToDelete.CategoryName;

                            return View(categoryToPassToView);
                        }
                    }
                }
                return View("Error");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will delete the category object from databse.
        /// </summary>
        /// <param name="categoryId">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [HttpPost]
        [ActionName("Delete")]
        public async Task<ActionResult> DeleteCategory(int? categoryId)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling web api to delete category object using id.
                    if (categoryId != null)
                    {
                        HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + categoryId);
                        if (responseMessage.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                    }
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }
	}
}