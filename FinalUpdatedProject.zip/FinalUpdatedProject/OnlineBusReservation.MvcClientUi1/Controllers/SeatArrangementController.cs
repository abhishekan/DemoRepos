﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{
     [Authorize(Roles = "admin")]
    public class SeatArrangementController : Controller
    {
        HttpClient client;

        string url = "http://localhost:50775/api/seatarrangement";

        public SeatArrangementController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This method is action method that will return all seats. 
        /// </summary>
        /// <returns>Returns view showing all seat information.</returns>
        public async Task<ActionResult> Index()
        {
            try
            {
                //Calling web api to get the information of all seats And pass that list to view.
                HttpResponseMessage responseMessage = await client.GetAsync(url);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var seatListFromDb = JsonConvert.DeserializeObject<List<SeatArrangement>>(responseData);

                    List<BusModel> seatArrangementModel = new List<BusModel>();

                    foreach (var itr in seatListFromDb)
                    {
                        BusModel seatToPassToView = new BusModel();
                        seatToPassToView.SeatArrangementId = itr.SeatArrangementId;
                        seatToPassToView.SeatNumber = itr.SeatNumber;
                        seatArrangementModel.Add(seatToPassToView);
                    }
                    return View(seatArrangementModel);
                }
                return View("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This will show details of the selected seats.
        /// </summary>
        /// <param name="id"> This is id of seat.</param>
        /// <returns>Returns index page if successful.</returns>
        public async Task<ActionResult> Details(int id)
        {
            try
            {
                //Calling web api to get information of particular seat. and pass it to view.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var seatArrangementModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                    return View(seatArrangementModel);
                }
                return View("Error");
            }
            catch (Exception e)
            {
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This will allow to create the new seat. 
        /// </summary>
        /// <returns>Returns view allowing user to add seat.</returns>
        public ActionResult Create()
        {
            return View(new BusModel());
        }

        /// <summary>
        /// This method will save the seat passed from view into database.
        /// </summary>
        /// <param name="seatToAdd">Seat object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Create(BusModel seatToAdd)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling web api to save the seat object into the database.
                    HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, seatToAdd);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will show the data of particular seat which he has selected.
        /// </summary>
        /// <param name="id">This is the id of seat tobe edited.</param>
        /// <returns>Returns the view with seat details.</returns>
        public async Task<ActionResult> Edit(int id)
        {
            try
            {
                //Querying database to get details of seat.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var seatArrangementModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                    return View(seatArrangementModel);
                }
                return View("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will save changes made by user to database.
        /// </summary>
        /// <param name="seat">This seat object edited by user.</param>
        /// <returns>Returns View with index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Edit(int id, BusModel seat)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Saving the altered object in database by calling web api.
                    HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url + "/" + id, seat);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }


        /// <summary>
        /// This method will show the details of object to be deleted.
        /// </summary>
        /// <param name="id">This is id of seat object to be deleted.</param>
        /// <returns>Return the view with all seat details.</returns>
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                //Querying the database to get details of seat object.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var seatArrangementModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                    return View(seatArrangementModel);
                }
                return View("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This action method will delete the seat object from databse.
        /// </summary>
        /// <param name="seatId">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [HttpPost]
        [ActionName("Delete")]
        public async Task<ActionResult> FinalDelete(int seatId)
        {
            try
            {
                //Calling web api to delete seat object using id.
                HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + seatId);
                if (responseMessage.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Error");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }
	}
}