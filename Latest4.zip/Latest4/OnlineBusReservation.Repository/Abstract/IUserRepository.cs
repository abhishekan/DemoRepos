﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface IUserRepository
    {
        void AddNewUser(AspNetUser userAddToDb);
        IEnumerable<AspNetUser> GetAllUsers();
        AspNetUser GetUserByUserName(string userIdToSearch);
        void UpdateUser(AspNetUser userFromApi);
        void DeleteUserByUserId(int? userIdToDelete);
    }
}
