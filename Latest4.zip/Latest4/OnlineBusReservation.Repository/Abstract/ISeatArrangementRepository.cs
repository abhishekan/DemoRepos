﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface ISeatArrangementRepository
    {
        void AddNewSeat(SeatArrangement seatAddToDb);
        IEnumerable<SeatArrangement> GetAllSeats();
        SeatArrangement GetSeatBySeatId(int? seatIdToSearch);
        void UpdateSeatArrangement(SeatArrangement seatFromApi);
        void DeleteSeatBySeatId(int? seatIdToDelete);
        IEnumerable<Ticket> GetSeatByBusIDAndDateOfBooking(int busId, DateTime dateOfBooking);
    }
}
