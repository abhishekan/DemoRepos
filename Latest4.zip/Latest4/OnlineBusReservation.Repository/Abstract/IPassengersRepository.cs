﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface IPassengersRepository
    {
        void AddNewPassenger(Passenger passengerAddToDb);
        IEnumerable<Passenger> GetAllPassengers();
        Passenger GetPassengerByPassengerId(int? passengerIdToSearch);
        void DeletePassengerByPassengerId(int? passengerIdToDelete);
    }
}
