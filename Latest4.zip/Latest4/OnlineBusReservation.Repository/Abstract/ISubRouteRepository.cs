﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface ISubRouteRepository
    {
        void AddNewSubRoute(SubRoute subRouteAddToDb);
        IEnumerable<SubRoute> GetAllSubRoutes();
        void UpdateSubRoute(SubRoute subRouteFromApi);
        void DeleteSubRouteBysubRouteId(int? subRouteIdToDelete);
        SubRoute GetSubRouteByRouteMasterSourceDestination(int routeMasterId = 0, String source = null, String destination = null);
        SubRoute GetSubRouteBySubRouteId(int? subRouteIdToSearch);
       }
}
