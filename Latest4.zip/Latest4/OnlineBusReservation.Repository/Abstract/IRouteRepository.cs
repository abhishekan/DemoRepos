﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface IRouteRepository
    {
        void AddNewRoute(RouteMaster routeAddToDb);
        IEnumerable<RouteMaster> GetAllRoutes();
        RouteMaster GetRouteByRouteId(int? routeIdToSearch);
        void DeleteRouteByRouteId(int? routeIdToDelete);
    }
}
