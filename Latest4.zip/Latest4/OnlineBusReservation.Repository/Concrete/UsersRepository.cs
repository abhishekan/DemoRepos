﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class UsersRepository : IUserRepository
    {
        OnlineBusReservationEntities userContext = new OnlineBusReservationEntities();
        public void AddNewUser(AspNetUser userAddToDb)
        {
            userContext.AspNetUsers.Add(userAddToDb);
            userContext.SaveChanges();
        }

        public IEnumerable<AspNetUser> GetAllUsers()
        {
            return userContext.AspNetUsers.ToList();
        }

        public AspNetUser GetUserByUserName(string userNameToSearch)
        {
            if (userNameToSearch != null)
            {
                AspNetUser userFound = userContext.AspNetUsers.Where(user=>user.UserName==userNameToSearch).FirstOrDefault();
                if (userFound != null)
                {
                    return userFound;
                }
            }
            return null;
        }

        public void UpdateUser(AspNetUser userFromApi)
        {
            if (userFromApi != null)
            {
                AspNetUser userFromDb = userContext.AspNetUsers.Find(userFromApi.Id);
                if (userFromDb != null)
                {
                    userFromDb.UserName = userFromApi.UserName;
                    userFromDb.ContactNo = userFromApi.ContactNo;
                    userFromDb.email = userFromApi.email;
                    userFromDb.Name = userFromApi.Name;
                    userFromDb.Gender = userFromApi.Gender;
                    userFromDb.DateOfBirth = userFromApi.DateOfBirth;

                    userContext.SaveChanges();
                }
            }
        }

        public void DeleteUserByUserId(int? userIdToDelete)
        {
            if (userIdToDelete != null)
            {
                AspNetUser userToDeleteFromDb = userContext.AspNetUsers.Find(userIdToDelete);
                userContext.AspNetUsers.Remove(userToDeleteFromDb);
                userContext.SaveChanges();
            }
        }

    }
}
