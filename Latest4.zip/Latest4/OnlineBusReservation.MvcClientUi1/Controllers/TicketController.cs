﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;


namespace OnlineBusReservation.MvcClientUi1.Controllers
{
    public class TicketController : Controller
    {
        HttpClient client;

        string url = "http://localhost:50775/api/Ticket";

        public TicketController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This method is action method that will return all ticket. 
        /// </summary>
        /// <returns>Returns view showing all ticket information.</returns>
        public async Task<ActionResult> GetAllTickets()
        {
            var id = User.Identity.GetUserId(); ;
            //Calling web api to get the information of all ticket And pass that list to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
               
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var ticketListFromDb = JsonConvert.DeserializeObject<List<Ticket>>(responseData);

                List<BusModel> ticketList = new List<BusModel>();

                foreach (var itr in ticketListFromDb)
                {
                    BusModel ticketToPassToView = new BusModel();

                    ticketToPassToView.TicketId = itr.TicketId;
                    ticketToPassToView.TicketNo = itr.TicketNo;
                    ticketToPassToView.JourneyDate = itr.JourneyDate;
                    ticketToPassToView.Fare = itr.Fare;
                    ticketToPassToView.BookingDate = itr.BookingDate;
                    ticketToPassToView.BookingStatus = itr.BookingStatus;
                    ticketToPassToView.SubRouteId = itr.SubRouteId;
                    ticketToPassToView.SeatArrangementId = itr.SeatArrangementId;
                    ticketToPassToView.BusId = itr.BusId;
                    ticketToPassToView.UserName = id;

                    ticketList.Add(ticketToPassToView);
                }

                return View("Index",ticketList);
            }
            return View("Error");
        }

        /// <summary>
        /// This will show details of the selected ticket.
        /// </summary>
        /// <param name="id"> This is id of ticket.</param>
        /// <returns>Returns index page if successful.</returns>       
        public async Task<ActionResult> GetTicketByTicketId(int? id)
        {
            //Calling web api to get information of particular ticket. and pass it to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var ticketIdFromDb = JsonConvert.DeserializeObject<BusModel>(responseData);

                BusModel ticketToPassToView = new BusModel();

                ticketToPassToView.TicketId = ticketIdFromDb.TicketId;
                ticketToPassToView.TicketNo = ticketIdFromDb.TicketNo;
                ticketToPassToView.JourneyDate = ticketIdFromDb.JourneyDate;
                ticketToPassToView.Fare = ticketIdFromDb.Fare;
                ticketToPassToView.BookingDate = ticketIdFromDb.BookingDate;
                ticketToPassToView.BookingStatus = ticketIdFromDb.BookingStatus;
                ticketToPassToView.SubRouteId = ticketIdFromDb.SubRouteId;
                ticketToPassToView.SeatArrangementId = ticketIdFromDb.SeatArrangementId;
                ticketToPassToView.BusId = ticketIdFromDb.BusId;
                ticketToPassToView.UserId = ticketIdFromDb.UserId;

                return View(ticketToPassToView);
            }
            return View("Error");
        }

        /// <summary>
        /// This will allow to create the new ticket. 
        /// </summary>
        /// <returns>Returns view allowing user to add ticket.</returns>
        [HttpGet]
        public ActionResult AddNewTicket()
        {
            return View();
        }

        /// <summary>
        /// This method will save the ticket passed from view into database.
        /// </summary>
        /// <param name="newTicketModel">Ticket object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> AddNewTicket(BusModel newTicketModel)
        {
            //Calling web api to save the ticket object into the database.
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, newTicketModel);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        /// <summary>
        /// This method will show the data of particular ticket which he has selected.
        /// </summary>
        /// <param name="id">This is the id of ticket tobe edited.</param>
        /// <returns>Returns the view with ticket details.</returns>
        [HttpGet]
        public async Task<ActionResult> UpdateTicket(int? id)
        {
            //Querying database to get details of ticket.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var updateTicketModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                return View(updateTicketModel);
            }
            return View("Error");
        }

        /// <summary>
        /// This action method will save changes made by user to database.
        /// </summary>
        /// <param name="updateTicketModel">This ticket object edited by user.</param>
        /// <returns>Returns View with index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> UpdateTicket(BusModel updateTicketModel)
        {
            //Saving the altered object in database by calling web api.
            HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url, updateTicketModel);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View("Error");
        }

        /// <summary>
        /// This method will show the details of ticket object to be deleted.
        /// </summary>
        /// <param name="id">This is id of ticket object to be deleted.</param>
        /// <returns>Return the view with all ticket details.</returns>
        [HttpGet]
        public async Task<ActionResult> DeleteTicketByTicketId(int? id)
        {
            //Querying the database to get details of ticket object.
            string urlToCheckDeletingObject = String.Format("http://localhost:50775/api/Ticket?ticketId={0}",id );

            HttpResponseMessage responseMessage = await client.GetAsync(urlToCheckDeletingObject);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var deleteTicketModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                return View(deleteTicketModel);
            }
            return View("Error");
        }

        /// <summary>
        /// This action method will delete the ticket object from databse.
        /// </summary>
        /// <param name="id">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [ActionName("DeleteTicketByTicketId")]
        [HttpPost]
        public async Task<ActionResult> FinalTicketByTicketId(int? id)
        {
            //Calling web api to delete ticket object using id.
            HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("GetAllTickets");
            }

            return View("Error");
        }

        /// <summary>
        /// This method will search ticket using ticket no.
        /// </summary>
        /// <param name="name">This is the ticket number of ticket.</param>
        /// <returns>Returns the found ticket details.</returns>
        [HttpGet]
        public async Task<ActionResult> SearchTicketByTicketNo(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return RedirectToAction("Index");
            }
            else
            {
                //Calling web api to get ticket matching the search parameter.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + name);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                    var searchTicketModel = JsonConvert.DeserializeObject<List<BusModel>>(responseData);
                    return View(searchTicketModel);
                }
                return View();
            }
        }
	}
}