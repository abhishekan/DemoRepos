﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{
    public class RouteMasterController : Controller
    {
        
        HttpClient client;
        string url = "http://localhost:50775/api/RouteMaster";

        //The HttpClient Class, this will be used for performing 
        //HTTP Operations, GET, POST, PUT, DELETE
        //Set the base address and the Header Formatte
        public RouteMasterController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        
        }



        /// <summary>
        /// This method is action method that will return all routemaster. 
        /// </summary>
        /// <returns>Returns view showing all rotemaster information.</returns>
        public async Task<ActionResult> Index()
        {
            //Calling web api to get the information of all rotemasters And pass that list to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeListFromDb = JsonConvert.DeserializeObject<List<RouteMaster>>(responseData);

                List<BusModel> busModel = new List<BusModel>();
                foreach (var itr in routeListFromDb)
                {
                    BusModel routeToPassToView = new BusModel();

                    routeToPassToView.RouteName = itr.RouteName;
                    routeToPassToView.RouteMasterId = itr.RouteMasterId;

                    busModel.Add(routeToPassToView);
                }

                return View(busModel);
            }
            return View("Error");
        }




        /// <summary>
        /// This will allow to create the new rotemaster. 
        /// </summary>
        /// <returns>Returns view allowing user to add rotemaster.</returns>
        public ActionResult Create()
        {
            return View(new BusModel());
        }


        /// <summary>
        /// This method will save the rotemaster passed from view into database.
        /// </summary>
        /// <param name="routeToAdd">rotemaster object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Create(BusModel routeToAdd)
        {

            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, routeToAdd);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        /// <summary>
        /// This will show details of the selected routemaster.
        /// </summary>
        /// <param name="id"> This is id of route.</param>
        /// <returns>Returns index page if successful.</returns>
        public async Task<ActionResult> Details(int? id)
        {
            //Calling web api to get information of particular route. and pass it to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeFound = JsonConvert.DeserializeObject<RouteMaster>(responseData);

                BusModel routeToPassToView = new BusModel();

                routeToPassToView.RouteMasterId = routeFound.RouteMasterId;
                routeToPassToView.RouteName = routeFound.RouteName;

                return View(routeToPassToView);
            }
            return RedirectToAction("Error");

        }



        /// <summary>
        /// This method will show the details of object to be deleted.
        /// </summary>
        /// <param name="id">This is id of route object to be deleted.</param>
        /// <returns>Return the view with all route details.</returns>
        public async Task<ActionResult> Delete(int? id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                //Querying the database to get details of route object.
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeToDelete = JsonConvert.DeserializeObject<RouteMaster>(responseData);

                BusModel routeToPassToView = new BusModel();
                routeToPassToView.RouteMasterId = routeToDelete.RouteMasterId;
                routeToPassToView.RouteName = routeToDelete.RouteName;

                return View(routeToPassToView);
            }
            return RedirectToAction("Error");
        }

        /// <summary>
        /// This action method will delete the route object from databse.
        /// </summary>
        /// <param name="id">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Delete(int id, RouteMaster routeTODelete)
        {
            HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");

        }

        


	}
	
}