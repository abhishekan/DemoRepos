﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{
    public class SubRouteController : Controller
    {
        HttpClient client;
        //The URL of the WEB API Service
        string url = "http://localhost:50775/api/subroute/";
        string urlForRoute = "http://localhost:50775/api/RouteMaster";


        //The HttpClient Class, this will be used for performing 
        //HTTP Operations, GET, POST, PUT, DELETE
        //Set the base address and the Header Formatter
        public SubRouteController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This method is action method that will return all subroutes. 
        /// </summary>
        /// <returns>Returns view showing all subroutes information.</returns>
        public async Task<ActionResult> Index()
        {
            //Calling web api to get the information of all subroutes And pass that list to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url);

            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var busListFromDb = JsonConvert.DeserializeObject<List<SubRoute>>(responseData);

                List<BusModel> busModel1 = new List<BusModel>();

                foreach (var itr in busListFromDb)
                {
                    BusModel subRouteToPassToView = new BusModel();

                    subRouteToPassToView.SubRouteId = itr.SubRouteId;
                    subRouteToPassToView.Source = itr.Source;
                    subRouteToPassToView.Destination = itr.Destination;
                    subRouteToPassToView.Distance = itr.Distance;
                    subRouteToPassToView.RouteMasterId = itr.RouteMasterId;
                    subRouteToPassToView.StopNo = itr.StopNo;

                    busModel1.Add(subRouteToPassToView);
                }

                return View(busModel1);
            }
            return View("Error");
        }

        /// <summary>
        /// This will show details of the selected subroute.
        /// </summary>
        /// <param name="id"> This is id of subroute.</param>
        /// <returns>Returns index page if successful.</returns>
        public async Task<ActionResult> Details(int? id)
        {
            //Calling web api to get information of particular subroute. and pass it to view.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);

            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeFound = JsonConvert.DeserializeObject<SubRoute>(responseData);

                BusModel subRouteToPassToView = new BusModel();

                subRouteToPassToView.RouteMasterId = routeFound.RouteMasterId;

                HttpResponseMessage responseMessageForRouteName = await client.GetAsync(urlForRoute + "/" + routeFound.RouteMasterId);
                if (responseMessageForRouteName.IsSuccessStatusCode)
                {
                    var responseDataForRouteName = responseMessageForRouteName.Content.ReadAsStringAsync().Result;
                    var routeMasterFound = JsonConvert.DeserializeObject<RouteMaster>(responseDataForRouteName);
                    subRouteToPassToView.RouteName = routeMasterFound.RouteName;
                    subRouteToPassToView.Source = routeFound.Source;
                    subRouteToPassToView.StopNo = routeFound.StopNo;
                    subRouteToPassToView.Destination = routeFound.Destination;
                    subRouteToPassToView.Distance = routeFound.Distance;
                    subRouteToPassToView.SubRouteId = routeFound.SubRouteId;
                    return View(subRouteToPassToView);
                }
            }
            return RedirectToAction("Error");

        }

        /// <summary>
        /// This will allow to create the new subroute. 
        /// </summary>
        /// <returns>Returns view allowing user to add subroute.</returns>
        public async Task<ActionResult> Create()
        {
            List<SelectListItem> routeItems = new List<SelectListItem>();

            ViewBag.choice = "";

            HttpResponseMessage responseMessage = await client.GetAsync(urlForRoute);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                //Deserializing the bus object which we got from web api.
                IEnumerable<RouteMaster> routes = JsonConvert.DeserializeObject<List<RouteMaster>>(responseData);

                foreach (var itr in routes)
                {
                    routeItems.Add(new SelectListItem { Text = itr.RouteName, Value = itr.RouteMasterId.ToString() });
                }
                ViewBag.routeDropDownList = routeItems;
            }

            return View(new BusModel());
        }

        /// <summary>
        /// This method will save the subroute passed from view into database.
        /// </summary>
        /// <param name="subRouteToAdd">Subroute object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Create(BusModel subRouteToAdd, FormCollection form)
        {
            subRouteToAdd.RouteMasterId = Convert.ToInt32(form["routeDropDownList"].ToString());

            //Calling web api to save the subroute object into the database.
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, subRouteToAdd);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }


        /// <summary>
        /// This method will show the data of particular subroute which he has selected.
        /// </summary>
        /// <param name="id">This is the id of subroute tobe edited.</param>
        /// <returns>Returns the view with subroute details.</returns>
        public async Task<ActionResult> Edit(int? id)
        {
            //Querying database to get details of subroute.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeFound = JsonConvert.DeserializeObject<SubRoute>(responseData);

                BusModel subRouteToPassToView = new BusModel();
                subRouteToPassToView.SubRouteId = routeFound.SubRouteId;
                subRouteToPassToView.RouteMasterId = routeFound.RouteMasterId;
                subRouteToPassToView.Source = routeFound.Source;
                subRouteToPassToView.StopNo = routeFound.StopNo;
                subRouteToPassToView.Destination = routeFound.Destination;
                subRouteToPassToView.Distance = routeFound.Distance;
                return View(subRouteToPassToView);
            }
            return RedirectToAction("Error");

        }

        /// <summary>
        /// This action method will save changes made by user to database.
        /// </summary>
        /// <param name="subRouteToUpdate">This subroute object edited by user.</param>
        /// <returns>Returns View with index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Edit([Bind(Include = "StopNo,SubRouteId")] BusModel subRouteToUpdate)
        {
            //Saving the altered object in database by calling web api.
            SubRoute subRouteToPass = new SubRoute();
            subRouteToPass.StopNo = subRouteToUpdate.StopNo;
            subRouteToPass.SubRouteId = subRouteToUpdate.SubRouteId;

            //Assigning the values of passed object to object got from database.
            //Calling web api to save that changed object.
            HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url, subRouteToPass);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        /// <summary>
        /// This method will show the details of object to be deleted.
        /// </summary>
        /// <param name="id">This is id of subroute object to be deleted.</param>
        /// <returns>Return the view with all subroute details.</returns>
        public async Task<ActionResult> Delete(int? id)
        {
            //Querying the database to get details of subroute object.
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;
                var routeFound = JsonConvert.DeserializeObject<SubRoute>(responseData);

                BusModel subRouteToPassToView = new BusModel();

                subRouteToPassToView.SubRouteId = routeFound.SubRouteId;
                subRouteToPassToView.RouteMasterId = routeFound.RouteMasterId;
                subRouteToPassToView.Source = routeFound.Source;
                subRouteToPassToView.StopNo = routeFound.StopNo;
                subRouteToPassToView.Destination = routeFound.Destination;
                subRouteToPassToView.Distance = routeFound.Distance;
                return View(subRouteToPassToView);
            }
            return RedirectToAction("Error");

        }

        /// <summary>
        /// This action method will delete the subroute object from databse.
        /// </summary>
        /// <param name="id">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [ActionName("Delete")]
        [HttpPost]
        public async Task<ActionResult> DeleteRoute(int? id)
        {
            if (id != null)
            {
                HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
                return RedirectToAction("Index");
            }
            else
                return RedirectToAction("Error");

        }
	}
}