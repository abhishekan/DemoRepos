﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using OnlineBusReservation.WebApi.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace OnlineBusReservation.WebApi.Controllers
{
   [EnableCors(origins: "http://localhost:62359", headers: "*", methods: "*")]
    public class BusController : ApiController
    {
        //Instance of repository to get data from database.
        IBusRepository busRepository = new BusRepository();

        [HttpGet]
        public IHttpActionResult GetById(int? id)
        {
            Bus busFound = busRepository.GetBusByBusId(id);
            if (busFound != null)
            {
                return Ok(busFound);
            }
            return NotFound();
        }

        public IHttpActionResult Get()
        {
            IEnumerable<Bus> busListToReturn = busRepository.GetAllBuses();
            if (busListToReturn == null)
            {
                return NotFound();
            }
            return Ok(busListToReturn);
        }

        //[HttpGet]
        public IHttpActionResult GetBusSearch(string source, string destination, string category, string timeSlot, DateTime journetDate, DateTime? returnDateToSearch)
        {
            IEnumerable<Bus> busListToReturn = busRepository.SearchBusByUserChoice(source, destination, category, timeSlot, journetDate, returnDateToSearch);
            if (busListToReturn == null)
            {
                return NotFound();
            }
            return Ok(busListToReturn);
        }

        public IHttpActionResult Get(DateTime dateOfJourney, int id)
        {
            Bus busToReturn = busRepository.SearchReturnBusToGetBusId(id, dateOfJourney);
            if (busToReturn == null)
            {
                return NotFound();
            }
            return Ok(busToReturn);
        }
       
        public IHttpActionResult PostBus([FromBody]Bus busToAddToDb)
        {
            busRepository.AddNewBus(busToAddToDb);
            return Created(Request.RequestUri + "/", busToAddToDb);
        }

        public IHttpActionResult PutBus([FromBody]Bus busToUpdate)
        {
            Bus busToCompare = busRepository.GetBusByBusId(busToUpdate.BusId);
            if (busToCompare.ArrivalTime != busToUpdate.ArrivalTime || busToCompare.DepartureTime != busToUpdate.DepartureTime || busToCompare.RouteMasterId != busToUpdate.RouteMasterId)
            {
                busRepository.UpdateBusByAdmin(busToUpdate);
                return Ok();
            }
            else if (busToUpdate != null)
            {
                busRepository.UpdateBus(busToUpdate);
                return Ok();
            }


            return NotFound();
        }

        public IHttpActionResult DeleteBus(int? id)
        {
            if (id != null)
            {
                busRepository.DeleteBusByBusId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
