﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class PassengerController : ApiController
    {
        IPassengersRepository passengersRepository = new PassengersRepository();

        public IHttpActionResult Get()
        {
            IEnumerable<Passenger> passengersListToReturn = passengersRepository.GetAllPassengers();
            if (passengersListToReturn == null)
            {
                return NotFound();
            }
            return Ok(passengersListToReturn);
        }


        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            Passenger passengerFound = passengersRepository.GetPassengerByPassengerId(id);
            if (passengerFound == null)
            {
                return NotFound();
            }
            return Ok(passengerFound);
        }

        public IHttpActionResult PostPassenger([FromBody]Passenger passengerToAddToDb)
        {
            passengersRepository.AddNewPassenger(passengerToAddToDb);
            return Created(Request.RequestUri + "/", passengerToAddToDb);
        }


        public IHttpActionResult DeletePassenger(int? id)
        {
            if (id != 0)
            {
                passengersRepository.DeletePassengerByPassengerId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
