﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class SeatArrangementController : ApiController
    {
        ISeatArrangementRepository seatArrangementRepository = new SeatArrangementRepository();

        public IHttpActionResult Get()
        {
            IEnumerable<SeatArrangement> seatListToReturn = seatArrangementRepository.GetAllSeats();
            if (seatListToReturn == null)
            {
                return NotFound();
            }
            return Ok(seatListToReturn);
        }


        [HttpGet]
        public IHttpActionResult Get(int seatToReturnBySeatArrangementId)
        {
            SeatArrangement seatFound = seatArrangementRepository.GetSeatBySeatId(seatToReturnBySeatArrangementId);
            if (seatToReturnBySeatArrangementId == null)
            {
                return NotFound();
            }
            return Ok(seatToReturnBySeatArrangementId);
        }

        [HttpGet]
        public IHttpActionResult Get(int busId, DateTime dateOfBooking)
        {
            IEnumerable<Ticket> seatFound = seatArrangementRepository.GetSeatByBusIDAndDateOfBooking(busId, dateOfBooking);
            if (seatFound == null)
            {
                return NotFound();
            }
            return Ok(seatFound);
        }


        public IHttpActionResult PostSeatArrangement([FromBody]SeatArrangement seatToAddToDb)
        {
            seatArrangementRepository.AddNewSeat(seatToAddToDb);
            return Created(Request.RequestUri + "/" + seatToAddToDb.SeatArrangementId, seatToAddToDb);
        }


        public IHttpActionResult PutSeatArrangement([FromBody]SeatArrangement seatToUpdate)
        {
            if (seatToUpdate != null)
            {
                seatArrangementRepository.UpdateSeatArrangement(seatToUpdate);
                return Ok();
            }
            return NotFound();
        }


        public IHttpActionResult DeleteSeatArrangement(int? seatToDeleteBySeatArrangementId)
        {
            if (seatToDeleteBySeatArrangementId != 0)
            {
                seatArrangementRepository.DeleteSeatBySeatId(seatToDeleteBySeatArrangementId);
                return Ok();
            }
            return NotFound();
        }
    }
}
