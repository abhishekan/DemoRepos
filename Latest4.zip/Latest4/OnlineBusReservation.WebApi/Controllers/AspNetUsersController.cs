﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class AspNetUsersController : ApiController
    {
        IUserRepository userRepository = new UsersRepository();
        [HttpGet]
        public IHttpActionResult GetById(string id)
        {
            AspNetUser userFound = userRepository.GetUserByUserName(id);
            if (userFound != null)
            {
                return Ok(userFound);
            }
            return NotFound();
        }

        public IHttpActionResult PutBus([FromBody]AspNetUser userToUpdate)
        {
            if (userToUpdate != null)
            {
                userRepository.UpdateUser(userToUpdate);
                return Ok();
            }
            return NotFound();
        }


    }
}
