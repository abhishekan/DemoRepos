﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBusReservation.WebApi.ViewModel
{
    public class SearchModel
    {
        public string Source { get; set; }
        public string Destination { get; set; }
        public int CategoryId { get; set; }
    }
}