﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BookStoreAppMVC.Startup))]
namespace BookStoreAppMVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
