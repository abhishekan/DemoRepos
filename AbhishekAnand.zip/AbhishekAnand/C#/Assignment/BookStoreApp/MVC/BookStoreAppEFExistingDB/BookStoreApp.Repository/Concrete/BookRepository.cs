﻿
//BookStoreApp.Repository

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BookStoreApp.Repository.Abstract;
using BookStoreApp.Repository.EntityDataModel;

namespace BookStoreApp.Repository
{
    //BookRepository Class
    public class BookRepository : iBookRepository
    {
        BookStoreDBEntities context = new BookStoreDBEntities();
        
        //Method for ADDING a Book.
        public void i_AddBook(BOOK book)
        {
            context.BOOKs.Add(book);
            context.SaveChanges();        
        }


        //Method for DISPLAYING ALL the Books
        public IEnumerable<BOOK> i_displayBook()
        {
            return context.BOOKs.ToList();
        }


        //Method for DISPLAYING the Books by id.
        public BOOK i_findBookById(int id)
        {
            return context.BOOKs.Find(id);
        }


        //Method for UPDATING the book by id.
        public void i_updateBookById(BOOK oldBook)
        {
            BOOK newBook = i_findBookById(oldBook.BookId);

            newBook.BookId = oldBook.BookId;
            newBook.Title = oldBook.Title;
            newBook.Description = oldBook.Description;
            newBook.Price = oldBook.Price;
            newBook.ISBN = oldBook.ISBN;
            newBook.PublicationDate = oldBook.PublicationDate;
            newBook.B_Cid = oldBook.B_Cid;
            newBook.B_Pid = oldBook.B_Pid;

            context.SaveChanges();
        }


        //Method for DELETING the Book by id.
        public void i_RemoveById(int id)
        {
            BOOK book = context.BOOKs.Find(id);
            context.BOOKs.Remove(book);
            context.SaveChanges();
        }


        //Method for SEARCHING the Books by Title.
        public IEnumerable<BOOK> i_searchBookByTitle(string name)
        {
            IEnumerable<BOOK> search = context.BOOKs.Where(p => p.Title.Contains(name));
            return search;
        }



        ////Get All the books written by specific Author
        //public IEnumerable<BOOK> i_All_BooksBy_Specific_Author(string authorName)
        //{
        //    var Book = (from book in context.BOOKs
        //                where book.AUTHORs.Any(a => a.AuthorName == authorName)
        //                select book).ToList();
        //    return Book;
        //}




        ////Get all the books written by specific author and published by specific publisher belonging to “Technical” book Category
        //public IEnumerable<BOOK> i_All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory(string authorName, string publisherName, string categoryName)
        //{
        //    var Book = (from book in context.BOOKs
        //                join publisher in context.PUBLISHERs on book.PUBLISHER.PublisherId equals publisher.PublisherId
        //                join category in context.CATEGORies on book.CATEGORY.CategoryId equals category.CategoryId
        //                where book.AUTHORs.Any(a => a.AuthorName == authorName) && publisher.PublisherName == publisherName && category.Categoryname == categoryName
        //                select book).ToList();
        //    return Book;    
        //}


        ////Get total Books published by each Publisher
        //public Book i_Get_Books_by_eachPublisher()
        //{
        //    GetConnection();
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = con;
        //    cmd.CommandText = "GetTotalBooks";
        //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //    SqlDataReader reader = null;
        //    try
        //    {
        //        reader = cmd.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            Book b1 = new Book() { PublisherId = (int)reader["B_Pid"], totalBooks = (int)reader["Total Books"] };
        //            CloseConnection();
        //            return b1;
        //        }
        //    }
        //    catch (SqlException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    CloseConnection();
        //    return null;
        //}
    }
}



