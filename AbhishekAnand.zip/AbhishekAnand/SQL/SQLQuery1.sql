
-- Assignment - 1 :

-- Create Database
CREATE DATABASE BookStoreDB
USE BookStoreDB


--Author Table
CREATE TABLE AUTHOR(
	AuthorId int IDENTITY(1,1) NOT NULL,
	AuthorName char(50), 
	DateOfBirth date,
	State char(50),
	City char(50),
	Phone bigint 
)
ALTER TABLE AUTHOR ADD CONSTRAINT pk_authorId PRIMARY KEY (AuthorId)
SELECT * FROM AUTHOR



--Publisher Table
CREATE TABLE PUBLISHER(
	PublisherId int IDENTITY(1,1) NOT NULL,
	PublisherName char(50),
	DateOfBirth date,
	State char(50),
	City char(50),
	Phone bigint 
)	
ALTER TABLE PUBLISHER ADD CONSTRAINT pk_publisherId PRIMARY KEY (PublisherId)
SELECT * FROM PUBLISHER 



--Category Table
CREATE TABLE CATEGORY(
	CategoryId int IDENTITY(1,1) NOT NULL,
	Categoryname char(50),
	Description char(50)
)
ALTER TABLE CATEGORY ADD CONSTRAINT pk_categoryId PRIMARY KEY (CategoryId)
SELECT * FROM CATEGORY



--Book Table
CREATE TABLE BOOK(
	BookId int IDENTITY(1,1) NOT NULL,
	Title char(50),
	Description char(50),
	Price int,
	ISBN char(10),
	PublicationDate char(50),
	Image char(100)
)
ALTER TABLE BOOK ADD CONSTRAINT pk_bookId PRIMARY KEY (BookId)
SELECT * FROM BOOK



--Order Table
CREATE TABLE [ORDER](
	OrderId int IDENTITY(1,1) NOT NULL,
	Date date,
	Quantity int,
	UnitPrice bigint,
	ShipingAddress char(50) 
)
ALTER TABLE [ORDER] ADD CONSTRAINT pk_orderId PRIMARY KEY (OrderId)
SELECT * FROM [ORDER]



--*****************************************************************************************************************************************************************************************************

-- Assignment - 2 :


-- I. A Book can have multiple authors. AND
-- II. An Author can write more than one book.

--Junction Table (BOOK_AUTHOR)
CREATE TABLE BOOK_AUTHOR
(
	Bid int NOT NULL,
	Aid int NOT NULL,
)
ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT pk_book_author PRIMARY KEY (Bid, Aid)

ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT fk_BookId FOREIGN KEY(Bid) REFERENCES BOOK(BookId)
ON DELETE CASCADE

ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT fk_AuthorId FOREIGN KEY(Aid) REFERENCES AUTHOR(AuthorId)
ON DELETE CASCADE

 
SELECT * FROM BOOK_AUTHOR



-- III. A Book belongs to only one category.
ALTER TABLE BOOK ADD B_Cid int 

ALTER TABLE BOOK ADD CONSTRAINT fk_B_Cid FOREIGN KEY(B_Cid) REFERENCES CATEGORY(CategoryId)
ON DELETE CASCADE



-- IV. A Book can be published by only one publishing house.
ALTER TABLE BOOK ADD B_Pid int 

ALTER TABLE BOOK ADD CONSTRAINT fk_B_Pid FOREIGN KEY(B_Pid) REFERENCES PUBLISHER(PublisherId)
ON DELETE CASCADE



-- V. An order can be placed for a single book but multiple quantities.
ALTER TABLE [ORDER] ADD O_Bid int

ALTER TABLE [ORDER] ADD CONSTRAINT fk_O_Bid FOREIGN KEY(O_Bid) REFERENCES BOOK(BookId)
ON DELETE CASCADE




-- ******************************************************************************************************************************************

-- A) Insert into Author Table:
INSERT INTO AUTHOR(AuthorName, DateOfBirth, State, City, Phone) VALUES('Herbert Schildt', '04-01-1984', 'Maharashtra', 'Pune', 8485028926)
INSERT INTO AUTHOR(AuthorName, DateOfBirth, State, City, Phone) VALUES('Dino Esposito', '05-05-1973', 'Punjab', 'Chandigarh', 9730612333)
INSERT INTO AUTHOR(AuthorName, DateOfBirth, State, City, Phone) VALUES('Paul Hawken ', '07-02-1991', 'Andhra Pradesh', 'Hyderabad', 7730602333)

SELECT * FROM AUTHOR


-- B) Insert into Publisher Table:
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('Tata McGraw-Hill', '01-08-1983', 'Maharashtra', 'Thane', 9730612333)
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('Oracle Press', '09-08-1972', 'Punjab', 'Chandigarh', 8485028926)
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('Microsoft', '07-01-1999', 'Andhra Pradesh', 'Hyderabad', 7285028926)

SELECT * FROM PUBLISHER 


-- C) Insert into Category Table:
INSERT INTO CATEGORY(Categoryname, Description) VALUES('Technical', 'Technical_Description')
INSERT INTO CATEGORY(Categoryname, Description) VALUES('Management', 'Management_Description')

SELECT * FROM CATEGORY


-- D) Insert into Book Table:
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Microsoft ASP.NET MVC Book', '3rd Edition', 1450, 1077, '11-21-2016', 'C:\Users\abhishekan\Pictures\ASP_.Net.jpeg', 1, 3)
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Java: A Beginner�s Guide', '6th Edition', 1750, 3047, '05-11-2013', 'C:\Users\abhishekan\Pictures\Java.jpeg', 1, 2)
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Professional PHP6', 'Dynamic Web Design', 2050, 1104, '01-12-2005', 'C:\Users\abhishekan\Pictures\Php.jpeg', 1, 1)
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Growing A Business', 'Critical Success Strategies', 1065, 8087, '08-18-1990', 'C:\Users\abhishekan\Pictures\Fianance.jpeg', 2, 2)

SELECT * FROM BOOK


-- E) Insert into Order Table:
INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('05-01-2013', 7, 9000, 'Mumbai', 1)

SELECT * FROM [ORDER]


-- F) Insert into BOOK_AUTHOR Table:
INSERT INTO BOOK_AUTHOR(Bid, Aid) VALUES(1, 3)
INSERT INTO BOOK_AUTHOR(Bid, Aid) VALUES(2, 1)
INSERT INTO BOOK_AUTHOR(Bid, Aid) VALUES(3, 2)
INSERT INTO BOOK_AUTHOR(Bid, Aid) VALUES(4, 2)

SELECT * FROM BOOK_AUTHOR



--*****************************************************************************************************************************************************************************************************

-- Assignment - 3 :


-- a.) Get All the books written by specific author
SELECT * FROM BOOK WHERE BookId IN(SELECT Bid FROM BOOK_AUTHOR WHERE Aid = 2)



-- b.) Get all the books written by specific author and published by specific publisher belonging to �Technical� book Category
SELECT * FROM BOOK WHERE BookId 
IN (SELECT Bid FROM BOOK_AUTHOR WHERE Aid = 3) 
AND B_Pid = (SELECT PublisherId FROM PUBLISHER WHERE PublisherName = 'Microsoft')
AND B_Cid = (SELECT CategoryId FROM CATEGORY WHERE Categoryname = 'Technical')



-- c. Get total books published by each publisher.
SELECT B_Pid, COUNT(BookId) AS "Total_Books "FROM BOOK  WHERE B_Pid IN (SELECT DISTINCT(B_Pid) FROM BOOK) GROUP BY B_Pid 



-- d. Get all the books for which the orders are placed.
SELECT * FROM BOOK B, [ORDER] O WHERE B.BookId = O.O_Bid




--*****************************************************************************************************************************************************************************************************

-- Assignment - 4 :

-- Stored Procedures: 


-- 4. Write the following stored procedure using SQL Server in BookStoreDB database to support following operations:


-- a. Get All the books written by specific author
 CREATE PROCEDURE GetBook_byAuthor @AuthorName CHAR(50)
 AS
 BEGIN
		SELECT * FROM BOOK WHERE BookId IN (SELECT Bid FROM BOOK_AUTHOR WHERE Aid IN (SELECT AuthorId FROM AUTHOR WHERE AuthorName = @AuthorName)) 		
 END

EXECUTE GetBook_byAuthor 'Herbert Schildt'




-- b. Get all the books written by specific author and published by specific publisher belonging to �Technical� book Category
 CREATE PROCEDURE GetAllBook @AuthorName char(50), @PublisherName char(50), @CategoryName char(50)
 AS
 BEGIN
		SELECT * FROM BOOK WHERE BookId 
		IN (SELECT Bid FROM BOOK_AUTHOR WHERE Aid IN (SELECT AuthorId FROM AUTHOR WHERE AuthorName = @AuthorName)) 
		AND B_Pid = (SELECT PublisherId FROM PUBLISHER WHERE PublisherName = @PublisherName)
		AND B_Cid = (SELECT categoryid FROM category WHERE Categoryname = @CategoryName)		
 END

 EXECUTE GetAllBook 'Herbert Schildt', 'Oracle Press', 'Technical'
 


 -- c. Get total books published by each Publisher.
 CREATE PROCEDURE GetTotalBooks
 AS
 BEGIN
		SELECT B_Pid, COUNT(BookId) AS "Total Books" FROM BOOK WHERE B_Pid IN (SELECT DISTINCT(B_Pid) FROM BOOK) GROUP BY B_Pid 		
 END

EXECUTE GetTotalBooks




-- d. Insert a particular book
 CREATE PROCEDURE InsertBook @AuthorId int, @Title char(50), @Description char(50), @Price int, @ISBN char(10), @PublicationDate char(50), @Image char(50), @B_Cid int, @B_Pid int								
 AS
 DECLARE @Bid int
 BEGIN
		
		INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES(@Title, @Description, @Price, @ISBN, @PublicationDate, @Image, @B_Cid, @B_Pid)
		SELECT @Bid = BookId From BOOK WHERE Title = @Title 
		INSERT INTO BOOK_AUTHOR (Bid, Aid) VALUES(@Bid, @AuthorId)
 END

 EXECUTE InsertBook 2, 'Business Model Generation', 'Improve a Business Model', 3350, 1611, '11-11-2011', 'C:\Users\abhishekan\Pictures\Business.jpeg', 2, 2



 
-- e. Update a particular book by id
 CREATE PROCEDURE UpdateBook @BookId int, @PublicationDate char(50), @Price int
 AS 
 BEGIN
		
		UPDATE BOOK SET PublicationDate = @PublicationDate, Price = @Price WHERE BookId = @BookId
 END

 EXECUTE UpdateBook 5, '12-11-2012', 5000

 
 

-- f. Delete a particular book by id
 CREATE PROCEDURE DeleteBook @BookId int
 AS 
 BEGIN
		
		DELETE FROM BOOK WHERE BookId = @BookId
 END

 EXECUTE DeleteBook 6



 
 --*****************************************************************************************************************************************************************************************************

-- Assignment - 5 :

-- Triggers


-- 5. Let�s assume that we have a table name �Book_History� table. If a particular book is deleted from the �Book� table, 
-- 	  an entry with same book records to �Book_History� table must take place. Automate this process using trigger.

CREATE TABLE BOOK_HISTORY
(
	BookId int NOT NULL,
	Title char(50),
	Description char(50),
	Price int,
	ISBN char(10),
	PublicationDate char(50),
	Image char(100),
	B_Cid int,
	B_Pid int
)
ALTER TABLE BOOK_HISTORY ADD CONSTRAINT pk_Book_History_Id PRIMARY KEY (BookId)
 SELECT * FROM BOOK
 SELECT * FROM BOOK_HISTORY
 

CREATE TRIGGER uspDELETE
ON BOOK
FOR DELETE
AS
DECLARE @ID INT,
		@BOOKNAME VARCHAR(20),
		@BOOKDESC VARCHAR(20),
		@BOOKPRICE INT,
		@BOOKISBN VARCHAR(10),
		@BOOKPUBDATE VARCHAR(50),
		@IMAGE VARCHAR(50),
		@B_CID int,
		@B_PID int 

 BEGIN
	SELECT @ID = BookId,
		@BOOKNAME = Title,
		@BOOKDESC = Description,
		@BOOKPRICE = Price,
		@BOOKISBN = ISBN,
		@BOOKPUBDATE = PublicationDate,
		@IMAGE = Image,
		@B_CID = B_Cid,
		@B_PID = B_Pid
	FROM DELETED

	INSERT INTO BOOK_HISTORY (BookId, Title, Description, Price, ISBN, PublicationDate)
	VALUES (@ID, @BOOKNAME, @BOOKDESC, @BOOKPRICE, @BOOKISBN, @BOOKPUBDATE)
END

DELETE FROM BOOK WHERE BookId = 8






-- 6. The �Book� table got an attribute �Price�. Let�s assume that we have a business requirement where we must ensure that the �Price� 
--		should not be less than 1. If any insert or update statement tries to make the �Price� less than 1, the SQL Server must terminate 
--		such insert or update statements. Write an appropriate trigger to implement the business requirement.

CREATE TRIGGER CHECKPRICE
ON BOOK
FOR INSERT, UPDATE
AS
BEGIN
	DECLARE @PRICE INT
	SELECT @PRICE = Price FROM INSERTED
	
	IF @PRICE < 1
		BEGIN
			ROLLBACK
			PRINT 'Price should not be less than 1.'
		END
	ELSE
		BEGIN
			PRINT 'SUCCESSFULLY INSERTED'
		END
END

INSERT INTO BOOK (Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Dot Net', 'Dot_Net_Description', 0, 10767, '11-21-2016', 'C:\Users\omkarpa\Pictures\Dot_Net.jpeg', 1, 3)






-- 7. Create a trigger on the table �Order� and add the following functionalities. When a new order is placed, it should check whether
--	the required quantity is available in the �Book� table. If not, it should show appropriate message and the insert statement to 
--	�Order� table should be terminated. If the quantity in book table is sufficient, it should deduct the quantity ordered from the 
--	quantity in hand in the book table and update the quantity.

ALTER TABLE BOOK
ADD Available_Book INT

SELECT * FROM BOOK

UPDATE  BOOK SET Available_Book = 10 WHERE BookId = 1
UPDATE  BOOK SET Available_Book = 20 WHERE BookId = 2

CREATE TRIGGER Check_Order
ON [ORDER] 
FOR INSERT
AS
BEGIN
	DECLARE @avilabelbooks INT, @bookid INT, @Quantity INT
	
	SELECT @bookid = O_Bid, @Quantity = Quantity FROM INSERTED
	SELECT @avilabelbooks = Available_Book FROM BOOK WHERE BookId = @bookid
	
	IF @avilabelbooks < @Quantity
		BEGIN
			ROLLBACK
			PRINT'Book Out Of Stock !!'
		END
	ELSE
		BEGIN
			PRINT'Book is Availabe !!'
			PRINT'Your Order is Placeced !!'
			UPDATE BOOK SET Available_Book = Available_Book - @Quantity
		END
END

INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('05-01-2013', 17, 9000, 'Mumbai', 1)
INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('06-02-2015', 7, 8000, 'Delhi', 1)

SELECT * FROM [ORDER]




--*****************************************************************************************************************************************************************************************************





-- Store Procedure for INSERTING into BOOK: 
 CREATE PROCEDURE sp_InsertBook @Title char(50), @Description char(50), @Price bigint, @ISBN bigint, @PublicationDate date, @Image char(50), @B_Cid int, @B_Pid int								
 AS
 BEGIN
		
		INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES(@Title, @Description, @Price, @ISBN, @PublicationDate, @Image, @B_Cid, @B_Pid)
 END

SELECT * FROM BOOK





-- Store Procedure for DISPLAYING from BOOK: 
 CREATE PROCEDURE sp_DisplayBook								
 AS
 BEGIN
		SELECT * FROM BOOK
 END





-- Store Procedure for DISPLAYING BOOK by ID: 
 CREATE PROCEDURE sp_DisplayBook_by_id @BookId int
 AS 
 BEGIN
		
		SELECT * FROM BOOK WHERE BookId = @BookId
 END

SELECT * FROM BOOK 


