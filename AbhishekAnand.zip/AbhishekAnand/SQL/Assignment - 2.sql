
-- Assignment - 2 :

-- I. A Book can have multiple authors. AND
-- II. An Author can write more than one book.

--Junction Table (BOOK_AUTHOR)
CREATE TABLE BOOK_AUTHOR
(
	Bid int NOT NULL,
	Aid int NOT NULL,
)
ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT pk_book_author PRIMARY KEY (Bid, Aid)

ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT fk_BookId FOREIGN KEY(Bid) REFERENCES BOOK(BookId)
ON DELETE CASCADE

ALTER TABLE BOOK_AUTHOR ADD CONSTRAINT fk_AuthorId FOREIGN KEY(Aid) REFERENCES AUTHOR(AuthorId)
ON DELETE CASCADE
 

-- III. A Book belongs to only one category.
ALTER TABLE BOOK ADD B_Cid int 

ALTER TABLE BOOK ADD CONSTRAINT fk_B_Cid FOREIGN KEY(B_Cid) REFERENCES CATEGORY(CategoryId)
ON DELETE CASCADE


-- IV. A Book can be published by only one publishing house.
ALTER TABLE BOOK ADD B_Pid int 

ALTER TABLE BOOK ADD CONSTRAINT fk_B_Pid FOREIGN KEY(B_Pid) REFERENCES PUBLISHER(PublisherId)
ON DELETE CASCADE


-- V. An order can be placed for a single book but multiple quantities.
ALTER TABLE [ORDER] ADD O_Bid int

ALTER TABLE [ORDER] ADD CONSTRAINT fk_O_Bid FOREIGN KEY(O_Bid) REFERENCES BOOK(BookId)
ON DELETE CASCADE




-- ******************************************************************************************************************************************

-- A) Insert into Author Table:
INSERT INTO AUTHOR(AuthorName, DateOfBirth, State, City, Phone) VALUES('Abhishek', '04-01-1994', 'Maharashtra', 'Pune', 8485028926)
INSERT INTO AUTHOR(AuthorName, DateOfBirth, State, City, Phone) VALUES('Omkar', '05-05-1993', 'Punjab', 'Chandigarh', 9730612333)

SELECT * FROM AUTHOR


-- B) Insert into Publisher Table:
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('TechMax', '01-08-1993', 'Maharashtra', 'Thane', 9730612333)
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('Technical', '09-08-1992', 'Punjab', 'Chandigarh', 8485028926)
INSERT INTO PUBLISHER(PublisherName, DateOfBirth, State, City, Phone) VALUES('Nirali', '07-01-1999', 'Andhra Pradesh', 'Banglore', 7285028926)

SELECT * FROM PUBLISHER 


-- C) Insert into Category Table:
INSERT INTO CATEGORY(Categoryname, Description) VALUES('Technical', 'Technical_Description')
INSERT INTO CATEGORY(Categoryname, Description) VALUES('Management', 'Management_Description')

SELECT * FROM CATEGORY


-- D) Insert into Book Table:
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Dot Net', 'Dot_Net_Description', 450, 1077, '11-21-2016', 'C:\Users\abhishekan\Pictures\Dot_Net.jpeg', 1, 1)
INSERT INTO BOOK(Title, Description, Price, ISBN, PublicationDate, Image, B_Cid, B_Pid) VALUES('Fianance', 'Fianance_Description', 750, 3047, '05-11-2013', 'C:\Users\abhishekan\Pictures\Fianance.jpeg', 2, 2)

SELECT * FROM BOOK


-- E) Insert into Order Table:
INSERT INTO [ORDER](Date, Quantity, UnitPrice, ShipingAddress, O_Bid) VALUES('05-01-2013', 7, 9000, 'Mumbai', 1)

SELECT * FROM [ORDER]


-- F) Insert into BOOK_AUTHOR Table:
INSERT INTO BOOK_AUTHOR(Bid, Aid) VALUES(1, 1)

SELECT * FROM BOOK_AUTHOR
