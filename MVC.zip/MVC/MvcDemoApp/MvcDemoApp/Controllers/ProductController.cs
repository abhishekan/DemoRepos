﻿	using MvcDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using EFDemo.Repository.Concrete;

namespace MvcDemoApp.Controllers
{
    public class ProductController : Controller
    {
        //creating object of repository
       // ProductRepository repo = new ProductRepository();

        private static List<Product> db = new List<Product>()
        {
            new Product{ProductId = 1, Name = "Cricket Kit", Price = 5000, Quantity = 50},
            new Product{ProductId =2, Name="Football", Price = 1000, Quantity=60}
        };

        public ViewResult SayHello(string name)
        {
            //return "Hello " + name;
            ViewBag.Username = name;
            return View();
        }

        [HttpGet]
        public ActionResult GetProducts(string name)
        {
            IEnumerable<Product> productModel = null;

            if (name != null)
            {
                productModel = from p in db
                               where p.Name == name
                               select p;

                return View(productModel);
            }

            return View(db.ToList());
        }
       
        [HttpGet]
        public ActionResult GetProductById(int? id)
        {
            Product productModel = null;

            if(id != null)
            {
                productModel = db.Find(p => p.ProductId == id);
                return View(productModel);
            }

            return HttpNotFound();
        }

        [HttpGet]
        public ViewResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddProduct(Product product)
        {
            if(product != null)
            {
                int id = db.Count;
                product.ProductId = id + 1;

                db.Add(product);
                return RedirectToAction("GetProducts");
            }

            return View();
        }

        [HttpGet]
        public ActionResult UpdateProduct(int? id)
        {
            Product productModel = null;

            if (id != null)
            {
                productModel = db.Find(p => p.ProductId == id);
                return View(productModel);
            }

            return HttpNotFound();
        }

        [HttpPost]
        public ActionResult UpdateProduct(Product product)
        {
            if (product != null)
            {
                var existingProduct = db.Find(p => p.ProductId == product.ProductId);

                if(existingProduct != null)
                {
                    db.Remove(existingProduct);
                    db.Add(product);
                    return RedirectToAction("GetProducts");
                }
            }

            return HttpNotFound();
        }

        [HttpGet]
        public ActionResult DeleteProduct(int? id)
        {
            var productModel = db.Find(p => p.ProductId == id);

            if (productModel != null)
            {
                return View(productModel);
            }

            return HttpNotFound();
        }

      //  [ActionName("DeleteProduct")]
        [HttpPost]
        public ActionResult FinalDelete(int? id)
        {
            var existingProduct = db.Find(p => p.ProductId == id);

            if (existingProduct != null)
            {
                db.Remove(existingProduct);
                
                return RedirectToAction("GetProducts");
            }

            return HttpNotFound();
        }
    }
}