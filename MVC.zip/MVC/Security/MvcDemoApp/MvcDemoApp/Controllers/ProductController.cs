﻿using MvcDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using EFDemo.Repository.Concrete;
using MvcDemoApp.ViewModels;

namespace MvcDemoApp.Controllers
{
     //[HandleError(View = "DivideByZeroError")]
    [Authorize(Roles = "admin")]
    public class ProductController : Controller
    {
        //creating object of repository
       // ProductRepository repo = new ProductRepository();

        private static List<Product> db = new List<Product>()
        {
            new Product{ProductId = 1, Name = "Cricket Kit", Price = 5000, Quantity = 50, LaunchDate=DateTime.Now},
            new Product{ProductId =2, Name="Football", Price = 1000, Quantity=60, LaunchDate=DateTime.Now, Email="abc@cybage.com<script>alert('XSS Attack')</script>"},
            new Product{ProductId = 3, Name = "Cricket Bat", Price = 1000, Quantity = 60, LaunchDate=DateTime.Now, Email="admin@cybage.com"},
        };

        public ViewResult SayHello(string name)
        {
            //assume that script is somehow came to server
            string nameWithScript = name + "<script>alert('XSS Attack')</script>";
            //return "Hello " + name;

            string filteredString = Server.HtmlEncode(nameWithScript);

            ViewBag.Username = filteredString;
            return View();
        }

        //public ActionResult ShowCartInfo()
        //{
        //    var prodId = 1;
        //    var username = "user1";
        //    var productAdded = true;

        //    var viewModel = new ProductViewModel()
        //    {
        //         ProductId = prodId, Username= username, IsProductAddedToCart = productAdded
        //    };
        //    return View(viewModel);
        //}

        [AllowAnonymous]
        [HttpGet]
        //[HandleError(View = "DivideByZeroError")]
        public ActionResult GetProducts(string name)
        {
            //throw new DivideByZeroException();
            //ViewBag.Name = "Sachin";
            //ViewData["City"] = "Mumbai";
            //TempData["Phone"] = 123;
            //Session["Profession"] = "Cricket Player";

            //return RedirectToAction("SayHello");


            IEnumerable<Product> productModel = null;

            if (name != null)
            {
                productModel = from p in db
                               where p.Name.Contains(name)
                               select p;

                return View(productModel);
            }

            return View(db.ToList());
        }
       
        [AllowAnonymous]
        [HttpGet]
        public ActionResult GetProductById(int? id)
        {
            Product productModel = null;

            if(id != null)
            {
                productModel = db.Find(p => p.ProductId == id);
                return View(productModel);
            }

            return HttpNotFound();
        }

       
        [HttpGet]
        public ViewResult AddProduct()
        {
            return View();
        }

       
        [HttpPost]
        public ActionResult AddProduct([Bind(Include = "ProductId,Name,Price,Quantity")] Product product)
        {
            if(product != null)
            {
                int id = db.Count;
                product.ProductId = id + 1;

                db.Add(product);
                return RedirectToAction("GetProducts");
            }

            return View();
        }

        
        [HttpGet]
        public ActionResult UpdateProduct(int? id)
        {
            Product productModel = null;

            if (id != null)
            {
                productModel = db.Find(p => p.ProductId == id);
                return View(productModel);
            }

            return HttpNotFound();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateProduct([Bind(Include = "ProductId,Name,Price,Quantity,Email")] Product product)
        {
            if (product != null)
            {
                //Explicitly validating model
                //if(string.IsNullOrEmpty(product.Name))
                //{
                //    ModelState.AddModelError("Name", "Name is required");
                //}

                var existingProduct = db.Find(p => p.ProductId == product.ProductId);

                if(existingProduct != null)
                {
                    if(ModelState.IsValid)
                    {
                        db.Remove(existingProduct);
                        db.Add(product);
                        return RedirectToAction("GetProducts");
                    }
                }
            }

            return View(product);
        }

        
        [HttpGet]
        public ActionResult DeleteProduct(int? id)
        {
            var productModel = db.Find(p => p.ProductId == id);

            if (productModel != null)
            {
                return View(productModel);
            }

            return HttpNotFound();
        }

        
        [ActionName("DeleteProduct")]
        [HttpPost]
        public ActionResult FinalDelete(int? id)
        {
            var existingProduct = db.Find(p => p.ProductId == id);

            if (existingProduct != null)
            {
                db.Remove(existingProduct);
                
                return RedirectToAction("GetProducts");
            }

            return HttpNotFound();
        }

        //Remote validation method
        public JsonResult IsUserEmailAvailable(string email)
        {
            return Json(!db.Any(x => x.Email == email), JsonRequestBehavior.AllowGet);
        }     
    }
}