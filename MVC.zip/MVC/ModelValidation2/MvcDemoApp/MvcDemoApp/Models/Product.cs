﻿using MvcDemoApp.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemoApp.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        [DisplayName("Product Name")]
        [Required(ErrorMessage = "Please enter name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter Price")]
        public decimal Price { get; set; }
        [Required(ErrorMessage = "Please enter Quantity")]
        public int Quantity { get; set; }
        [DataType(DataType.Date)]//this is not for validating but for setting data type
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Please enter product launch date")]
        [PastDate(ErrorMessage = "Please enter date in the past")]
        public DateTime LaunchDate { get; set; }

        //[Remote("IsUserEmailAvailable", "Product", ErrorMessage = "Email already exists!")]
        public string Email { get; set; }
    }


    //implementing self-validation in models
    //public class Product : IValidatableObject
    //{
    //    public int ProductId { get; set; }
    //    [DisplayName("Product Name")]
    //    //[Required(ErrorMessage = "Please enter name")]
    //    public string Name { get; set; }
    //    [Required(ErrorMessage = "Please enter Price")]
    //    public decimal Price { get; set; }
    //    [Required(ErrorMessage = "Please enter Quantity")]
    //    public int Quantity { get; set; }
    //    [DataType(DataType.Date)]//this is not for validating but for setting data type
    //    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    //    [Required(ErrorMessage = "Please enter product launch date")]
    //    [PastDate(ErrorMessage = "Please enter date in the past")]
    //    public DateTime LaunchDate { get; set; }

    //    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    //    {
    //        List<ValidationResult> errors = new List<ValidationResult>();

    //        //adding property level errors
    //        if (string.IsNullOrWhiteSpace(Name))
    //        {
    //            errors.Add(new ValidationResult("Please enter name."));
    //        }           

    //        return errors;
    //    }
    //}
}