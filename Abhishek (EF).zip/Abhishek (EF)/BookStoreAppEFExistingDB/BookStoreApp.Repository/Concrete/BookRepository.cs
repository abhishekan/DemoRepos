﻿
//BookStoreApp.Repository

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BookStoreApp.Repository.Abstract;
using BookStoreApp.Repository.EntityDataModel;

namespace BookStoreApp.Repository
{
    //BookRepository Class
    public class BookRepository : ApplicationException, iBookRepository
    {
        BookStoreDBEntities context = new BookStoreDBEntities();
        
        //Method for ADDING a Book.
        public void i_AddBook(BOOK book)
        {
            context.BOOKs.Add(book);
            context.SaveChanges();        
        }


        //Method for DISPLAYING ALL the Books
        public IEnumerable<BOOK> i_displayBook()
        {
            return context.BOOKs.ToList();
        }


        //Method for DISPLAYING the Books by id.
        public BOOK i_findBookById(int id)
        {
            return context.BOOKs.Find(id);
        }


        //Method for UPDATING the book by id.
        public void i_updateBookById(BOOK b)
        {
            context.SaveChanges();
        }


        //Method for DELETING the Book by id.
        public void i_RemoveById(int id)
        {
            BOOK book = context.BOOKs.Find(id);
            context.BOOKs.Remove(book);
            context.SaveChanges();
        }



        ////Get All the books written by specific Author
        //public Book i_All_BooksBy_Specific_Author(Book b)
        //{
        //    GetConnection();
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = con;
        //    cmd.CommandText = "GetBook_byAuthor";
        //    cmd.Parameters.Add(new SqlParameter("@AuthorName", SqlDbType.Char, 50, "AuthorName")).Value = b.authorName;
        //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //    SqlDataReader reader = null;
        //    try
        //    {
        //        reader = cmd.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            Book b1 = new Book() { BookId = (int)reader["BookId"], Title = Convert.ToString(reader["Title"]), Description = Convert.ToString(reader["Description"]), Price = (int)reader["Price"], ISBN = Convert.ToString(reader["ISBN"]), PublicationDate = Convert.ToString(reader["PublicationDate"]), CategoryId = (int)reader["B_Cid"], PublisherId = (int)reader["B_Pid"] };
        //            CloseConnection();
        //            return b1;
        //        }
        //    }
        //    catch (SqlException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    CloseConnection();
        //    return null;
        //}




        ////Get all the books written by specific author and published by specific publisher belonging to “Technical” book Category
        //public Book i_All_booksBy_specificAuthor_and_Publisher_BelongsTo_TechnicalCategory(Book b)
        //{
        //    GetConnection();
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = con;
        //    cmd.CommandText = "GetAllBook";
        //    cmd.Parameters.Add(new SqlParameter("@AuthorName", SqlDbType.Char, 50, "AuthorName")).Value = b.authorName;
        //    cmd.Parameters.Add(new SqlParameter("@PublisherName", SqlDbType.Char, 50, "PublisherName")).Value = b.publisherName;
        //    cmd.Parameters.Add(new SqlParameter("@CategoryName", SqlDbType.Char, 50, "CategoryName")).Value = b.categoryName;
        //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //    SqlDataReader reader = null;
        //    try
        //    {
        //        reader = cmd.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            Book b1 = new Book() { BookId = (int)reader["BookId"], Title = Convert.ToString(reader["Title"]), Description = Convert.ToString(reader["Description"]), Price = (int)reader["Price"], ISBN = Convert.ToString(reader["ISBN"]), PublicationDate = Convert.ToString(reader["PublicationDate"]), CategoryId = (int)reader["B_Cid"], PublisherId = (int)reader["B_Pid"] };
        //            CloseConnection();
        //            return b1;
        //        }
        //    }
        //    catch (SqlException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    CloseConnection();
        //    return null;
        //}


        ////Get total Books published by each Publisher
        //public Book i_Get_Books_by_eachPublisher()
        //{
        //    GetConnection();
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.Connection = con;
        //    cmd.CommandText = "GetTotalBooks";
        //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //    SqlDataReader reader = null;
        //    try
        //    {
        //        reader = cmd.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            Book b1 = new Book() { PublisherId = (int)reader["B_Pid"], totalBooks = (int)reader["Total Books"] };
        //            CloseConnection();
        //            return b1;
        //        }
        //    }
        //    catch (SqlException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    CloseConnection();
        //    return null;
        //}
    }
}



