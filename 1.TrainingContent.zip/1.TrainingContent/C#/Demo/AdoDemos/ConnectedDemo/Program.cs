﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectedDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DAL.CheckConnection();
            DAL.CloseConnection();

            


            Console.ReadLine();
        }
    }
}
