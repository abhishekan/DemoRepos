﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalcDemo
{
    public class Calculator
    {
        //static member
        //public static int Add(int a, int b)
        //{
        //    return a + b;
        //}

        //instance member
        public int Add(int a, int b)
        {
            return a + b;
        }

        private int Subtract(int a, int b)
        {
            return a - b;
        }

        protected int Multiply(int a, int b)
        {
            return a * b;
        }

        internal int Divide(int a, int b)
        {
            return a + b;
        }

        protected internal int Remainder(int a, int b)
        {            
            return a % b;
        }
    }

    class program : Calculator
    {
        public void Try()
        {
            Calculator calc = new Calculator();
            //Calculator.Add(5, 2);//access using class name when member is static
            calc.Add(5, 2);//access using object when the member is instance
            calc.Divide(5, 2);
            calc.Remainder(5, 2);//accessible since it is internal, no inheritance is needed here.
            
            program p = new program();
            //all members except private are accessible from child class.
            p.Add(5, 2);
            p.Divide(5, 2);
            p.Multiply(5, 2);
            p.Remainder(5, 2);            
        }
    }
}
