﻿using EFDemo.Repository.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo.ConsoleUI
{
    class CategoryManager
    {
        private CategoryRepository repo = new CategoryRepository();

        public void GetCategories(int id = 0)
        {
            IEnumerable<Category> categories;
            Category category;

            if (id == 0)
            {
                categories = repo.GetAllCategories();
                foreach (Category c in categories)
                {
                    Console.WriteLine("Category Id : {0}", c.CategoryId);
                    Console.WriteLine("Category Name : {0}", c.Name);
                    Console.WriteLine("Description : {0}", c.Description);

                    Console.WriteLine("================================");
                }
            }
            else
            {
                category = repo.GetCategory(id);
                Console.WriteLine("Category Id : {0}", category.CategoryId);
                Console.WriteLine("Category Name : {0}", category.Name);
                Console.WriteLine("Description : {0}", category.Description);
            }
        }
    }
}
