﻿using EFDemo.Repository.Concrete;
using System.Data.Entity;

namespace EFDemo.Repository.EntityDataModel
{
    class MyDbContext : DbContext
    {
        public MyDbContext()
            : base("name=con1")
        {

        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}
