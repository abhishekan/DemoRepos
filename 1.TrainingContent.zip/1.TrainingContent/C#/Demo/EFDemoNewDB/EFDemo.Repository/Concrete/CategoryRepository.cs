﻿using EFDemo.Repository.Abstract;
using EFDemo.Repository.EntityDataModel;
using System.Collections.Generic;
using System.Linq;

namespace EFDemo.Repository.Concrete
{
    public class CategoryRepository : ICategoryRepository
    {
        MyDbContext context = new MyDbContext();

        public IEnumerable<Category> GetAllCategories()
        {
            //query expression
            var products = (from p in context.Categories
                           select p).ToList();

            return products;

            //method syntax
            //return context.Categories.ToList();
        }

        public Category GetCategory(int categoryId)
        {
            Category categoryEntry = context.Categories.Find(categoryId);
            return categoryEntry;
        }

        public void SaveCategory(Category category)
        {
            if (category.CategoryId == 0)
            {
                context.Categories.Add(category);
            }
            else
            {
                Category categoryEntry = context.Categories.Find(category.CategoryId);
                if (categoryEntry != null)
                {
                    categoryEntry.Name = category.Name;
                    categoryEntry.Description = category.Description;
                }
            }
            context.SaveChanges();
        }

        public Category Delete(int categoryId)
        {
            Category categoryEntry = context.Categories.Find(categoryId);
            if (categoryEntry != null)
            {
                context.Categories.Remove(categoryEntry);
                context.SaveChanges();
            }
            return categoryEntry;
        }        
    }
}
