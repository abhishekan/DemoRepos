﻿
using System.ComponentModel.DataAnnotations;
namespace EFDemo.Repository.Concrete
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int? Quantity { get; set; }
        public int Price { get; set; }
        
        public int CategoryId { get; set; }
        //[Required]
        public Category Category { get; set; }
    }
}
