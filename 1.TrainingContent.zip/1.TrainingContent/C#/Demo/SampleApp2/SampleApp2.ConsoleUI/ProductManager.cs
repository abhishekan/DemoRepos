﻿using SampleApp2.Core;
using SampleApp2.Repository;
using System;

namespace SampleApp2.ConsoleUI
{
    class ProductManager
    {
        ProductRepository repo = new ProductRepository();
        public void GetProducts()
        {
            var products = repo.GetAllProducts(2);

            foreach (Product p in products)
            {
                Console.WriteLine("Product Id : {0}", p.ProductId);
                Console.WriteLine("Name : {0}", p.Name);
                Console.WriteLine("Price : {0}", p.Price);
                Console.WriteLine("Quantity : {0}", p.Quanity);
                Console.WriteLine("================================");
            }
        }
    }
}




