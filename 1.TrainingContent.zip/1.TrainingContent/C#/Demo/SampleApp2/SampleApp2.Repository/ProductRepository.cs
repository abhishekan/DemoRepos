﻿using SampleApp2.Core;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SampleApp2.Repository
{
    public class ProductRepository
    {
        private static string conStr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
        private static SqlConnection con;
        List<Product> productList;

        private static bool CheckConnection()
        {
            try
            {
                con = new SqlConnection(conStr);
                con.Open();
                Console.WriteLine("Connected successfully");
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        private static bool CloseConnection()
        {
            try
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                    Console.WriteLine("Connection closed successfully");
                }
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return false;
        }

        public IEnumerable<Product> GetAllProducts(int? id)
        {
            bool status;
            SqlCommand cmd;
            SqlDataReader reader = null;
            Product product;
            productList = new List<Product>();

            //opening connection first
            status = ProductRepository.CheckConnection();
            Console.WriteLine("Connection Status : {0}", status);

            cmd = new SqlCommand();
            cmd.Connection = con;
            //cmd.CommandText = "Select * from Employee";
            if (id == null)
            {
                cmd.CommandText = "prcGetAllProducts";
            }
            else
            {
                cmd.CommandText = "prcGetProduct";
                //creating parameters and pass to sp
                cmd.Parameters.Add(new SqlParameter("@id", SqlDbType.Int, 0, "ProductId")).Value = id;
            }
            cmd.CommandType = System.Data.CommandType.StoredProcedure;


            try
            {
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    product = new Product() { ProductId = (int)reader[0], Name = Convert.ToString(reader[1]), Price = (int)reader[2], Quanity = (int)reader[3] };
                    productList.Add(product);
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                ProductRepository.CloseConnection();
            }

            return productList;
        }
    }
}
