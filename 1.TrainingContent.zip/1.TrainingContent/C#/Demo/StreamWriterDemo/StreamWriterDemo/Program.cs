﻿using System;
using System.IO;

namespace StreamWriterDemo
{
    class Program
    {
        static void WriteToFile()
        {
            //you have to close fs and call flush
            //FileStream fs = new FileStream(@"c:\Demo\test.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);

            //StreamWriter writer = new StreamWriter(fs);           

            //writer.WriteLine("Line 1");
            //writer.WriteLine("Line 2");
            ////writer.Flush();
            //Console.WriteLine("Writing to the file...Done");
            //writer.Close();
            //fs.Close();

            //no need to close filestream or call Flush
            using (FileStream fs = new FileStream(@"c:\demo\test.txt", FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read))
            {
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine("Line 1");
                    writer.WriteLine("Line 2");
                    Console.WriteLine("Writing to the file");
                }
            }
        }

        static void ReadFromFile()
        {
            //FileStream fs = new FileStream(@"c:\Demo\test.txt", FileMode.Open, FileAccess.Read, FileShare.Read);

            //StreamReader reader = new StreamReader(fs);

            //Console.WriteLine("Reading from the file...");
            ////Console.WriteLine(reader.ReadLine());//reads data line by line
            //Console.WriteLine(reader.ReadToEnd());//reads all lines of the entire file
            //reader.Close();
            //fs.Close();

            using (FileStream fs2 = new FileStream(@"c:\demo\test.txt", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader reader = new StreamReader(fs2))
                {
                    Console.WriteLine("Reading from the file...");
                    //Console.WriteLine(reader.ReadLine());//reads data line by line
                    Console.WriteLine(reader.ReadToEnd());//reads all lines of the entire file

                }
            }
        }

        static void Main(string[] args)
        {
            WriteToFile();
            ReadFromFile();

            Console.ReadLine();
        }
    }
}
