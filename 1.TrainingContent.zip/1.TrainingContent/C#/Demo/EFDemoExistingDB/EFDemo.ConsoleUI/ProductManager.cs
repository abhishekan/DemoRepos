﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFDemo.Repository.Concrete;
using EFDemo.Repository.EntityDataModel;

namespace EFDemo.ConsoleUI
{
    class ProductManager
    {
        private ProductRepository repo = new ProductRepository();

        public void GetProducts(int id = 0)
        {
            IEnumerable<Product> products;
            Product product;

            if (id == 0)
            {
                products = repo.GetAllProducts();
                foreach (Product p in products)
                {
                    Console.WriteLine("Product Id : {0}", p.ProductId);
                    Console.WriteLine("Name : {0}", p.Name);
                    Console.WriteLine("Price : {0}", p.Price);
                    Console.WriteLine("Quantity : {0}", p.Quantity);
                    Console.WriteLine("Category : {0}", p.Category.Name);

                    Console.WriteLine("================================");
                }
            }
            else
            {
                product = repo.GetProduct(id);
                Console.WriteLine("Product Id : {0}", product.ProductId);
                Console.WriteLine("Name : {0}", product.Name);
                Console.WriteLine("Price : {0}", product.Price);
                Console.WriteLine("Quantity : {0}", product.Quantity);
                Console.WriteLine("Category : {0}", product.Category.Name);
            }
        }
    }
}
