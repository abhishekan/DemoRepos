﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            CategoryManager cm = new CategoryManager();
            cm.GetCategories();

            ProductManager pm = new ProductManager();
            pm.GetProducts();
        }
    }
}
