﻿using EFDemo.Repository.EntityDataModel;
using System.Collections.Generic;

namespace EFDemo.Repository.Abstract
{
    interface ICategoryRepository
    {
        IEnumerable<Category> GetAllCategories();
        Category GetCategory(int categoryId);
        void SaveCategory(Category category);
        Category Delete(int categoryId);
    }
}
