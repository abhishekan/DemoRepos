﻿using EFDemo.Repository.EntityDataModel;
using System.Collections.Generic;

namespace EFDemo.Repository.Abstract
{
    interface IProductRepository
    {
        IEnumerable<Product> GetAllProducts();
        Product GetProduct(int productId);
        void SaveProduct(Product product);
        Product Delete(int productId);
    }
}
