﻿using EFDemo.Repository.Abstract;
using EFDemo.Repository.EntityDataModel;
using System.Collections.Generic;
using System.Linq;

namespace EFDemo.Repository.Concrete
{
    public class ProductRepository : IProductRepository
    {
        TestDB2Entities context = new TestDB2Entities();

        public IEnumerable<Product> GetAllProducts()
        {
            return context.Products.Include("Category").ToList();
        }

        public Product GetProduct(int productId)
        {
            Product productEntry = context.Products.Find(productId);
            return productEntry;
        }

        public void SaveProduct(Product product)
        {
            if (product.ProductId == 0)
            {
                context.Products.Add(product);
            }
            else
            {
                Product productEntry = context.Products.Find(product.ProductId);
                if (productEntry != null)
                {
                    productEntry.Name = product.Name;
                    productEntry.Price = product.Price;
                    productEntry.Quantity = product.Quantity;
                }
            }
            context.SaveChanges();
        }

        public Product Delete(int productId)
        {
            Product productEntry = context.Products.Find(productId);
            if (productEntry != null)
            {
                context.Products.Remove(productEntry);
                context.SaveChanges();
            }
            return productEntry;
        }
    }
}
