﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionDemo
{
    //This class is using a delegate and named function
    class LambdaDemo1
    {
        public delegate void MyDelegate();

        public static void Example1()
        {
            MyDelegate del = SayHello;
            del.Invoke();
        }

        public static void SayHello()
        {
            Console.WriteLine("Hello ! I am named function");
        }
    }

    //This class is using a delegate and anonymous function
    class LambdaDemo2
    {
        public delegate void MyDelegate1();
        public delegate void MyDelegate2(int x);

        public static void Example2()
        {
            //this is a delegate with anonymous function and without parameter
            MyDelegate1 del1 = delegate()
            {
                
                Console.WriteLine("Hello ! I am anonymous function");
            };

            //this is a delegate with anonymous function and with parameter
            MyDelegate2 del2 = delegate(int a)
            {                
                Console.WriteLine("Hello ! I am anonymous function with parameter, parameter passed is {0}", a);
            };

            del1.Invoke();
            del2.Invoke(6);

            //An example of delegate with anonyous function with parameters in Windows form
            //button1.Click += delegate(object sender, EventArgs e) { MessageBox.Show("Button 1 Clicked"); };
        }
    }

    //This class is using a Lambda Expression
    //A lambda expression is an anonymous function, that we can use to create delegates or expression type
    class LambdaDemo3
    {
        public delegate int MyDelegate(int i);

        public static void Example3()
        {
            //The syntax is (parameters) => expression or statement block;
            //Here x maps to parameter i and x * x maps to return type int
            MyDelegate del = x => x * x; //Lambda Expression             
            Console.WriteLine("x * x = {0}", del.Invoke(5));

            MyDelegate del2 = x => { return x * x; };//Lambda Expression is written as statement block
            Console.WriteLine("x * x = {0}", del2.Invoke(25));

            MyDelegate del3 = (int x) => x * x; //Lambda Expression with specific parameter type
            Console.WriteLine("x * x = {0}", del2.Invoke(25));
        }
    }

    //Lamda Expression with Extension Methods
    class LambdaDemo4
    {
        public static void Example4()
        {
            var playerNames = new string[] { "Sachin", "Virat", "Suresh" };

            IEnumerable<string> filteredNames = playerNames.Where(s => s.StartsWith("S"));
            foreach (var item in filteredNames)
            {
                Console.WriteLine(item);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //LambdaDemo1.Example1();

            //LambdaDemo2.Example2();

            //LambdaDemo3.Example3();

            //LambdaDemo4.Example4();
        }
    }
}
