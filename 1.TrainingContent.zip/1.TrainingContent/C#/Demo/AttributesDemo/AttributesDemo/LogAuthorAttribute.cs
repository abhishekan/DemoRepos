﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    //This attribute can be applied only to class or struct
    //and can be applied multiple times to a single class or struct
    [System.AttributeUsage(System.AttributeTargets.Class |
                         System.AttributeTargets.Struct,
                         AllowMultiple = true)]//multiuse attribute
    //Author is a custom attribute class used to tag name
    //of the programmer who wrote the type
    class LogAuthorAttribute : Attribute
    {
        private string name;
        public double version;
        //Any constructor parameter is positional parameter
        public LogAuthorAttribute(string name)
        {
            //name is a positional parameter
            this.name = name;
            //version is a named parameter
            version = 1.0;
        }

        public string GetName()
        {
            return name;
        }
    }

    [LogAuthor("Saurav", version = 1.1)]
    [LogAuthor("Sachin", version=1.1)]
    class Employee
    {
        //write your logic here
    }
}
