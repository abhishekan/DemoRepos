﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayAndCollectionDemo
{
    class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //int[] intArray = new int[] { 1, 2, 3, 4, 5 };
            //intArray[0] = 5;

            Employee[] empArray = new Employee[]
            {
                new Employee{ EmployeeId=1, Name="Sachin", City="Mumbai"},
                new Employee{ EmployeeId=1, Name="Saurav", City="Kolkata"}
            };

            Console.WriteLine("Reading Employee data from Array");
            //foreach(Employee emp in empArray)
            //{
            //    Console.WriteLine("Employee Id : {0}, Name : {1} and City {2}", emp.EmployeeId, emp.Name, emp.City);
            //}

            //List<int> numColl = new List<int>() { 1, 2, 3, 4, 5 };
            //numColl.Add(5);

            List<Employee> empList = new List<Employee>()
            {
                new Employee{ EmployeeId=1, Name="Dhoni", City="Ranchi"},
                new Employee{ EmployeeId=2, Name="Virat", City="Delhi"}
            };

            empList.Add(new Employee { EmployeeId = 3, Name = "Suresh", City = "Delhi" });
            //empList.AddRange(empArray);
            empList.Insert(2, new Employee { EmployeeId = 4, Name = "Yuvraj", City = "Chandigarh" });

            //empList.RemoveRange(3, 2);



            Console.WriteLine("Reading Employee data from List");
            foreach (Employee em in empList)
            {
                Console.WriteLine("Employee Id : {0}, Name : {1} and City {2}", em.EmployeeId, em.Name, em.City);
            }

            Console.WriteLine("Enter Employee Id");
            int id = int.Parse(Console.ReadLine());
            //searching by id
            Employee emp = empList.Find(e => e.EmployeeId == id);
            Console.WriteLine("Employee Id : {0}, Name : {1} and City {2}", emp.EmployeeId, emp.Name, emp.City);

            //removing by id
            empList.Remove(emp);

            Console.WriteLine("Reading Employee data after removing from List");
            foreach (Employee em in empList)
            {
                Console.WriteLine("Employee Id : {0}, Name : {1} and City {2}", em.EmployeeId, em.Name, em.City);
            }
        }
    }
}
