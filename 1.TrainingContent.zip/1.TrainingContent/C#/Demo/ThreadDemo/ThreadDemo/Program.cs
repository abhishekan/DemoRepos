﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadDemo
{
    class Program
    {
        public static void PrintEvenNumbers()
        {
            int counter = 1;
            while (counter <= 10)
            {
                Console.WriteLine("Even Number");
                counter += 1;
                //Thread.Sleep(1000);
            }
        }

        public static void PrintOddNumbers()
        {
            int counter = 1;
            while (counter <= 10)
            {
                Console.WriteLine("Odd Number");
                counter += 1;
                //Thread.Sleep(1000);
            }
        }
        static void Main(string[] args)
        {
            Thread.CurrentThread.Name = "Main Thread";
            Console.WriteLine("{0} started", Thread.CurrentThread.Name);

            Thread wt1 = new Thread(PrintEvenNumbers);
            wt1.Priority = ThreadPriority.Lowest;
            wt1.Start();
            wt1.Name = "wt1:PrintEvenNumbers";
            Console.WriteLine("{0} started", wt1.Name);

            Thread wt2 = new Thread(PrintOddNumbers);
            wt2.Priority = ThreadPriority.Highest;
            wt2.Start();
            wt2.Name = "wt2:PrintOddNumbers";
            Console.WriteLine("{0} started", wt2.Name);
            Console.ReadLine();
        }
    }
}
