﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class CategoryController : ApiController
    {
        //  creating the instance of categoryRepository

        ICategoryRepository categoryRepository = new CategoryRepository();



        /// <summary>
        /// this is web Api Get method to
        /// get all the Categories from the database
        /// </summary>
        public IHttpActionResult Get()
        {
            IEnumerable<Category> categoryListToReturn = categoryRepository.GetAllCategories();
            if (categoryListToReturn == null)
            {
                return NotFound();
            }
            return Ok(categoryListToReturn);
        }



        /// <summary>
        /// this is web Api Get method to
        /// get category by id from the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult Get(int? id)
        {
            if (id != null)
            {
                Category categoryFound = categoryRepository.GetCategoryByCategoryId(id);
                if (categoryFound != null)
                {
                    return Ok(categoryFound);
                }
            }
            return NotFound();
        }



        /// <summary>
        /// this is web Api Post method to
        /// add new Category into database
        /// </summary>
        /// <param name="categoryToAddToDb"></param>
        /// <returns></returns>
        public IHttpActionResult PostCategory([FromBody]Category categoryToAddToDb)
        {
            categoryRepository.AddNewCategory(categoryToAddToDb);
            return Created(Request.RequestUri + "/" + categoryToAddToDb.CategoryId, categoryToAddToDb);
        }



        /// <summary>
        /// this is web Api Put method to
        /// Update  Category into database
        /// </summary>
        /// <param name="categoryToUpdate"></param>
        /// <returns></returns>
        public IHttpActionResult PutCategory([FromBody]Category categoryToUpdate)
        {
            if (categoryToUpdate != null)
            {
                categoryRepository.UpdateCategory(categoryToUpdate);
                return Ok();
            }
            return NotFound();
        }



        /// <summary>
        /// Web Api delete method to delete the Category By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult DeleteCategory(int? id)
        {
            if (id != 0)
            {
                categoryRepository.DeleteCategoryByCategoryId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
