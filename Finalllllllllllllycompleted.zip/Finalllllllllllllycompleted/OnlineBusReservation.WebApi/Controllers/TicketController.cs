﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class TicketController : ApiController
    {
        //  creating the instance of BusRepository

        ITicketRepository ticketRepository = new TicketRepository();


        /// <summary>
        /// this is web Api Get method to
        /// get all the Tickets from the database
        /// </summary>
        public IHttpActionResult Get()
        {
            IEnumerable<Ticket> ticketListToReturn = ticketRepository.GetAllTickets();
            if (ticketListToReturn == null)
            {
                return NotFound();
            }
            return Ok(ticketListToReturn);
        }



        /// <summary>
        /// this is web Api Get method to
        /// get ticket by id which is of the datatype string from the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult Get(string id)
        {
            IEnumerable<Ticket> ticketFound = ticketRepository.GetTicketByUserName(id);
            if (ticketFound == null)
            {
                return NotFound();
            }
            return Ok(ticketFound);
        }




        /// <summary>
        /// this is web Api Get method to
        /// get ticket by id which is of the datatype int from the database
        /// </summary>
        /// <param name="ticketId"></param>
        /// <returns></returns>
        public IHttpActionResult Get(int ticketId)
        {
            Ticket ticketFound = ticketRepository.GetTicketByTicket(ticketId);
            if (ticketFound == null)
            {
                return NotFound();
            }
            return Ok(ticketFound);
        }



        /// <summary>
        /// this is web Api Get method to
        /// get ticket by Ticket number and the Source from the database
        /// </summary>
        /// <param name="ticketNo"></param>
        /// <param name="source"></param>
        /// <returns></returns>
        public IHttpActionResult Get(string ticketNo, string source)
        {
            Ticket ticketIdFound = ticketRepository.GetTicketByTicketNo(ticketNo, source);
            if (ticketIdFound == null)
            {
                return NotFound();
            }
            return Ok(ticketIdFound);
        }




        /// <summary>
        /// this is web Api Post method to
        /// add new Ticket into database
        /// </summary>
        /// <param name="ticketToAddToDb"></param>
        /// <returns></returns>
        public IHttpActionResult PostTicket([FromBody]Ticket ticketToAddToDb)
        {
            ticketRepository.AddNewTicket(ticketToAddToDb);
            return Created(Request.RequestUri + "/" + ticketToAddToDb.TicketId, ticketToAddToDb);
        }




        /// <summary>
        /// this is web Api Put method to
        /// Update  Ticket into database
        /// </summary>
        /// <param name="ticketToUpdate"></param>
        /// <returns></returns>
        public IHttpActionResult PutTicket([FromBody]Ticket ticketToUpdate)
        {
            if (ticketToUpdate != null)
            {
                ticketRepository.UpdateTicket(ticketToUpdate);
                return Ok();
            }
            return NotFound();
        }



        /// <summary>
        /// Web Api delete method to delete the Ticket By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult DeleteTicket(int? id)
        {
            if (id != 0)
            {
                ticketRepository.DeleteTicketByTicketId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
