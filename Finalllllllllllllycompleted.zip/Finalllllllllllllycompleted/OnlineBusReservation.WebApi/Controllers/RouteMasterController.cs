﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace OnlineBusReservation.WebApi.Controllers
{
    [EnableCors(origins: "http://localhost:62359", headers: "*", methods: "*")]
    public class RouteMasterController : ApiController
    {

        // creating the instance of routeRepository

        IRouteRepository routeRepository = new RouteMasterRepository();

        /// <summary>
        /// this is web Api Post method to
        /// add new route into database
        /// </summary>
        /// <param name="routeToAddToDb"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult PostRoute([FromBody] RouteMaster routeToAddToDb)
        {
            routeRepository.AddNewRoute(routeToAddToDb);
            return Created(Request.RequestUri + "/" + routeToAddToDb.RouteMasterId, routeToAddToDb);

        }



        /// <summary>
        /// WebApi Get method to get all the Routes from DB
        /// </summary>
        /// <returns></returns>
        public IHttpActionResult Get()
        {
            IEnumerable<RouteMaster> routeListToReturn = routeRepository.GetAllRoutes();

            if (routeListToReturn == null)
            {
                return NotFound();
            }
            return Ok(routeListToReturn);
        }


        /// <summary>
        /// WebApi Get method to get 
        /// perticular Route by it's id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public IHttpActionResult Get(int Id)
        {
            RouteMaster routeFound = routeRepository.GetRouteByRouteId(Id);

            if (routeFound == null)
            {
                return NotFound();
            }
            return Ok(routeFound);
        }

        /// <summary>
        /// Web Api delete method to delete the Particular Route by its Ids
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult deleteRoute(int? id)
        {
            if (id != null)
            {
                routeRepository.DeleteRouteByRouteId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
