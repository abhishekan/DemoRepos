﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class SeatArrangementController : ApiController
    {

        //  creating the instance of SeatArrangementRepository

        ISeatArrangementRepository seatArrangementRepository = new SeatArrangementRepository();


        /// <summary>
        /// this is web Api Get method to
        /// get all the Seats from the database
        /// </summary>
        public IHttpActionResult Get()
        {
            IEnumerable<SeatArrangement> seatListToReturn = seatArrangementRepository.GetAllSeats();
            if (seatListToReturn == null)
            {
                return NotFound();
            }
            return Ok(seatListToReturn);
        }



        /// <summary>
        /// this is web Api Get method to
        /// get Seats by id from the database
        /// </summary>
        /// <param name="seatToReturnBySeatArrangementId"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult Get(int seatToReturnBySeatArrangementId)
        {
            SeatArrangement seatFound = seatArrangementRepository.GetSeatBySeatId(seatToReturnBySeatArrangementId);
            if (seatToReturnBySeatArrangementId == null)
            {
                return NotFound();
            }
            return Ok(seatToReturnBySeatArrangementId);
        }



        /// <summary>
        /// this is web Api Get method to
        /// get the seats according to the BusId and Booking Date from the database
        /// </summary>
        /// <param name="busId"></param>
        /// <param name="dateOfBooking"></param>        
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult Get(int busId, DateTime dateOfBooking)
        {
            IEnumerable<Ticket> seatFound = seatArrangementRepository.GetSeatByBusIDAndDateOfBooking(busId, dateOfBooking);
            if (seatFound == null)
            {
                return NotFound();
            }
            return Ok(seatFound);
        }




        /// <summary>
        /// this is web Api Post method to
        /// add new seats into database
        /// </summary>
        /// <param name="seatToAddToDb"></param>
        /// <returns></returns>
        public IHttpActionResult PostSeatArrangement([FromBody]SeatArrangement seatToAddToDb)
        {
            seatArrangementRepository.AddNewSeat(seatToAddToDb);
            return Created(Request.RequestUri + "/" + seatToAddToDb.SeatArrangementId, seatToAddToDb);
        }



        /// <summary>
        /// this is web Api Put method to
        /// Update  Seats into database
        /// </summary>
        /// <param name="seatToUpdate"></param>
        /// <returns></returns>
        public IHttpActionResult PutSeatArrangement([FromBody]SeatArrangement seatToUpdate)
        {
            if (seatToUpdate != null)
            {
                seatArrangementRepository.UpdateSeatArrangement(seatToUpdate);
                return Ok();
            }
            return NotFound();
        }




        /// <summary>
        /// Web Api delete method to delete the Seat By Id
        /// </summary>
        /// <param name="seatToDeleteBySeatArrangementId"></param>
        /// <returns></returns>
        public IHttpActionResult DeleteSeatArrangement(int? seatToDeleteBySeatArrangementId)
        {
            if (seatToDeleteBySeatArrangementId != 0)
            {
                seatArrangementRepository.DeleteSeatBySeatId(seatToDeleteBySeatArrangementId);
                return Ok();
            }
            return NotFound();
        }
    }
}
