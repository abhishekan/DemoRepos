﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class PassengerController : ApiController
    {

        //  creating the instance of passengersRepository

        IPassengersRepository passengersRepository = new PassengersRepository();




        /// <summary>
        /// this is web Api Get method to
        /// get all the Passengers from the database
        /// </summary>
        public IHttpActionResult Get()
        {
            IEnumerable<Passenger> passengersListToReturn = passengersRepository.GetAllPassengers();
            if (passengersListToReturn == null)
            {
                return NotFound();
            }
            return Ok(passengersListToReturn);
        }




        /// <summary>
        /// this is web Api Get method to
        /// get Passenger by id from the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            Passenger passengerFound = passengersRepository.GetPassengerByPassengerId(id);
            if (passengerFound == null)
            {
                return NotFound();
            }
            return Ok(passengerFound);
        }



        /// <summary>
        /// this is web Api Post method to
        /// add new Passenger into database
        /// </summary>
        /// <param name="passengerToAddToDb"></param>
        /// <returns></returns>
        public IHttpActionResult PostPassenger([FromBody]Passenger passengerToAddToDb)
        {
            passengersRepository.AddNewPassenger(passengerToAddToDb);
            return Created(Request.RequestUri + "/", passengerToAddToDb);
        }



        /// <summary>
        /// Web Api delete method to delete the Passenger By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult DeletePassenger(int? id)
        {
            if (id != 0)
            {
                passengersRepository.DeletePassengerByPassengerId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
