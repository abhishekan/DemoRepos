﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineBusReservation.WebApi.Controllers
{
    public class BusSeatAvailabilityController : ApiController
    {
        IBusSeatAvailability busSeatRepository = new BusSeatAvailabilityRepository();

        [HttpGet]
        public IHttpActionResult GetById(int busIdInBusSeatAvailability, DateTime journeyDate)
        {
            int busFound = busSeatRepository.GetBusSeatAvailability(busIdInBusSeatAvailability, journeyDate);
            if (busFound != null)
            {
                return Ok(busFound);
            }
            return NotFound();
        }


        public IHttpActionResult PutBus([FromBody]BusSeatAvailability busToUpdate)
        {
            if(busToUpdate!=null)
            {
                busSeatRepository.UpdateBusSeatAvailability(busToUpdate);
                return Ok();
            }
            return NotFound();
        }

    }
}
