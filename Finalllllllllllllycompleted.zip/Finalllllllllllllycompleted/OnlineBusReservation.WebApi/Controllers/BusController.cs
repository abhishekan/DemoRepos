﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.Concrete;
using OnlineBusReservation.Repository.EntityDataModel;
using OnlineBusReservation.WebApi.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace OnlineBusReservation.WebApi.Controllers
{
    [EnableCors(origins: "http://localhost:62359", headers: "*", methods: "*")]
    public class BusController : ApiController
    {

        //  creating the instance of BusRepository

        IBusRepository busRepository = new BusRepository();

        /// <summary>
        /// this is web Api Get method to
        /// get bus by id from the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult GetById(int? id)
        {
            Bus busFound = busRepository.GetBusByBusId(id);
            if (busFound != null)
            {
                return Ok(busFound);
            }
            return NotFound();
        }


        /// <summary>
        /// this is web Api Get method to
        /// get all the buses from the database
        /// </summary>
        public IHttpActionResult Get()
        {
            IEnumerable<Bus> busListToReturn = busRepository.GetAllBuses();
            if (busListToReturn == null)
            {
                return NotFound();
            }
            return Ok(busListToReturn);
        }


        /// <summary>
        /// this is web Api Get method to
        /// Search bus by source,destination,category,timeslot,journey date or return date  from the database
        /// </summary>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <param name="category"></param>
        /// <param name="timeSlot"></param>
        /// <param name="journetDate"></param>
        /// <param name="returnDateToSearch"></param>
        /// <returns></returns>
        public IHttpActionResult GetBusSearch(string source, string destination, string category, string timeSlot, DateTime journetDate, DateTime? returnDateToSearch)
        {
            IEnumerable<Bus> busListToReturn = busRepository.SearchBusByUserChoice(source, destination, category, timeSlot, journetDate, returnDateToSearch);
            if (busListToReturn == null)
            {
                return NotFound();
            }
            return Ok(busListToReturn);
        }


        /// <summary>
        /// this is web Api Get method to
        /// Search return bus by dateOfJourney and by Bus Id  from the database
        /// </summary>
        /// <param name="dateOfJourney"></param>
        /// <param name="id"></param>        
        /// <returns></returns>
        public IHttpActionResult Get(DateTime dateOfJourney, int id)
        {
            Bus busToReturn = busRepository.SearchReturnBusToGetBusId(id, dateOfJourney);
            if (busToReturn == null)
            {
                return NotFound();
            }
            return Ok(busToReturn);
        }



        /// <summary>
        /// this is web Api Post method to
        /// add new Bus into database
        /// </summary>
        /// <param name="busToAddToDb"></param>
        /// <returns></returns>
        public IHttpActionResult PostBus([FromBody]Bus busToAddToDb)
        {
            busRepository.AddNewBus(busToAddToDb);
            return Created(Request.RequestUri + "/", busToAddToDb);
        }



        /// <summary>
        /// this is web Api Put method to
        /// Update  Bus into database
        /// </summary>
        /// <param name="busToUpdate"></param>
        /// <returns></returns>
        public IHttpActionResult PutBus([FromBody]Bus busToUpdate)
        {
            Bus busToCompare = busRepository.GetBusByBusId(busToUpdate.BusId);
            if (busToCompare.ArrivalTime != busToUpdate.ArrivalTime || busToCompare.DepartureTime != busToUpdate.DepartureTime || busToCompare.RouteMasterId != busToUpdate.RouteMasterId)
            {
                busRepository.UpdateBusByAdmin(busToUpdate);
                return Ok();
            }
           
            return NotFound();
        }


        /// <summary>
        /// Web Api delete method to delete the Bus By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IHttpActionResult DeleteBus(int? id)
        {
            if (id != null)
            {
                busRepository.DeleteBusByBusId(id);
                return Ok();
            }
            return NotFound();
        }
    }
}
