﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace OnlineBusReservation.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.EnableCors();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
                  name: "GetTicketByTicketIdForDelete",
                  routeTemplate: "api/{controller}/{ticketId}",
                  defaults: new { ticketId = RouteParameter.Optional }
              );

            config.Routes.MapHttpRoute(
              name: "SearchToGetTicketIdForPassenger",
              routeTemplate: "api/{controller}/{ticketId}",
              defaults: new { ticketId = RouteParameter.Optional }
          );

            config.Routes.MapHttpRoute(
                 name: "GetSeatByBusIdAndJourneyDate",
                 routeTemplate: "api/{controller}/{busIdInBusSeatAvailability}/{journeyDate}",
                 defaults: new { busIdInBusSeatAvailability = RouteParameter.Optional, journeyDate = RouteParameter.Optional }
             );

            config.Routes.MapHttpRoute(
                  name: "GetSeatByBusIDAndDateOfBooking",
                  routeTemplate: "api/{controller}/{busId}/{dateOfBooking}",
                  defaults: new { busId = RouteParameter.Optional, dateOfBooking=RouteParameter.Optional }
              );

            config.Routes.MapHttpRoute(
           name: "SearchForSubRoute",
           routeTemplate: "api/{controller}/{routeMasterId}/{source}/{destination}",
           defaults: new { source = RouteParameter.Optional, destination = RouteParameter.Optional, routeMasterId = RouteParameter.Optional });


            config.Routes.MapHttpRoute(
           name: "SearchForReturnBus",
           routeTemplate: "api/{controller}/{dateOfJourney}/{id}",
           defaults: new { id = RouteParameter.Optional, dateOfJourney = RouteParameter.Optional });

    

            config.Routes.MapHttpRoute(
          name: "GetTicketbyTicketNo",
          routeTemplate: "api/{controller}/{ticketNo}/{source}",
          defaults: new { source = RouteParameter.Optional, ticketNo = RouteParameter.Optional});

            config.Routes.MapHttpRoute(
               name: "Search",
               routeTemplate: "api/{controller}/{source}/{destination}/{category}/{timeSlot}/{journetDate}/{returnDateToSearch}",
               defaults: new { source = RouteParameter.Optional, destination = RouteParameter.Optional, category = RouteParameter.Optional, timeSlot = RouteParameter.Optional, journetDate = RouteParameter.Optional, returnDateToSearch = RouteParameter.Optional });

          
          

        }
    }
}
