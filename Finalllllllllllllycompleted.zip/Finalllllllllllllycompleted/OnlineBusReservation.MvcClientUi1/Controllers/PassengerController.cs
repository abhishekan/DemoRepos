﻿using Newtonsoft.Json;
using OnlineBusReservation.MvcClientUi1.ViewModel;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace OnlineBusReservation.MvcClientUi1.Controllers
{
    [Authorize(Roles = "admin")]
    public class PassengerController : Controller
    {
        HttpClient client;

        string url = "http://localhost:50775/api/Passenger";


        public PassengerController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// This method is action method that will return all passengers. 
        /// </summary>
        /// <returns>Returns view showing all passeneger information.</returns>
        public async Task<ActionResult> Index()
        {
            try
            {
                //Calling web api to get the information of all passengers And pass that list to view.
                HttpResponseMessage responseMessage = await client.GetAsync(url);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var passengerListFromDb = JsonConvert.DeserializeObject<List<Passenger>>(responseData);

                    List<BusModel> passengerModel = new List<BusModel>();

                    foreach (var itr in passengerListFromDb)
                    {
                        BusModel passengerToPassToView = new BusModel();
                        passengerToPassToView.PassengerId = itr.PassengerId;
                        passengerToPassToView.PassengerName = itr.PassengerName;
                        passengerToPassToView.PassengerAge = itr.PassengerAge;
                        passengerToPassToView.TicketId = itr.TicketId;

                        string urlForTicket = String.Format("http://localhost:50775/api/Ticket?ticketId={0}", passengerToPassToView.TicketId);
                        HttpResponseMessage responseMessageForTicket = await client.GetAsync(urlForTicket);
                        if (responseMessageForTicket.IsSuccessStatusCode)
                        {
                            var responseDataForTicket = responseMessageForTicket.Content.ReadAsStringAsync().Result;

                            var ticketFromDb = JsonConvert.DeserializeObject<Ticket>(responseDataForTicket);

                            passengerToPassToView.Gender = itr.Gender;
                            passengerToPassToView.TicketNo = ticketFromDb.TicketNo;
                            passengerToPassToView.JourneyDate = ticketFromDb.JourneyDate;
                            passengerToPassToView.JourneyDateTodisplay =((DateTime) ticketFromDb.JourneyDate).Date.ToString("d");
                            passengerModel.Add(passengerToPassToView);
                        }
                    }

                    return View(passengerModel);
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This will show details of the selected passenger.
        /// </summary>
        /// <param name="id"> This is id of passenger.</param>
        /// <returns>Returns index page if successful.</returns>
        public async Task<ActionResult> Details(int id)
        {
            try
            {
                //Calling web api to get information of particular passenger. and pass it to view.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var passengerModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                    return View(passengerModel);
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }


        /// <summary>
        /// This will allow to create the new passenger. 
        /// </summary>
        /// <returns>Returns view allowing user to add passenger.</returns>
        public ActionResult Create()
        {
            return View(new BusModel());
        }

        /// <summary>
        /// This method will save the passenger passed from view into database.
        /// </summary>
        /// <param name="passengerToAdd">passenger object passed from view.</param>
        /// <returns>Returns index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Create(BusModel passengerToAdd)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Calling web api to save the passenger object into the database.
                    if (passengerToAdd != null)
                    {
                        HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, passengerToAdd);
                        if (responseMessage.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                    }
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }

        /// <summary>
        /// This method will show the data of particular passenger which he has selected.
        /// </summary>
        /// <param name="id">This is the id of passenger tobe edited.</param>
        /// <returns>Returns the view with passenger details.</returns>
        public async Task<ActionResult> Edit(int id)
        {
            try
            {
                //Querying database to get details of passenger.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    var passengerModel = JsonConvert.DeserializeObject<BusModel>(responseData);

                    return View(passengerModel);
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }



        /// <summary>
        /// This action method will save changes made by user to database.
        /// </summary>
        /// <param name="passenger">This category object edited by user.</param>
        /// <param name="id">This is passenger id edited by user.</param>
        /// <returns>Returns View with index if successful.</returns>
        [HttpPost]
        public async Task<ActionResult> Edit(int id, BusModel passenger)
        {
            try
            {
                //if (ModelState.IsValid)
                {
                    //Saving the altered object in database by calling web api.
                    HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url + "/" + id, passenger);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }


        /// <summary>
        /// This method will show the details of object to be deleted.
        /// </summary>
        /// <param name="categoryId">This is id of passenger object to be deleted.</param>
        /// <returns>Return the view with all passenger details.</returns>
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                //Querying the database to get details of passenger object.
                HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                    Passenger passengerToDelete = JsonConvert.DeserializeObject<Passenger>(responseData);

                    if (passengerToDelete != null)
                    {
                        BusModel passengerModel = new BusModel();
                        passengerModel.PassengerId = passengerToDelete.PassengerId;
                        passengerModel.PassengerName = passengerToDelete.PassengerName;
                        passengerModel.PassengerAge = passengerToDelete.PassengerAge;
                        passengerModel.TicketId = passengerToDelete.TicketId;
                        passengerModel.Gender = passengerToDelete.Gender;
                        return View(passengerModel);
                    }
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
               return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }


        /// <summary>
        /// This action method will delete the passenger object from databse.
        /// </summary>
        /// <param name="passengerId">This is the id of object to be deleted. </param>
        /// <returns>Return index if successful.</returns>
        [HttpPost]
        [ActionName("Delete")]
        public async Task<ActionResult> FinalDelete(int passengerId)
        {
            try
            {
                //Calling web api to delete passenger object using id.
                HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + passengerId);
                if (responseMessage.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
            catch (Exception e)
            {
              return View("~/Views/Shared/SomethingWentWrong.cshtml");
            }
        }
	}
}