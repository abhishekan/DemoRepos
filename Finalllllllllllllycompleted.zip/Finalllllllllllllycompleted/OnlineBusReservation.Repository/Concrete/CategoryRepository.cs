﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class CategoryRepository : ICategoryRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities categoryContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new Category to Database.
        /// </summary>
        /// <param name="categoryAddToDb">This category Object which is passed By client will be inserted into Database.</param>  
        public void AddNewCategory(Category categoryAddToDb)
        {
            //Adding category object to database.And Calling savechanges to reflect changes to database.
            categoryContext.Categories.Add(categoryAddToDb);
            categoryContext.SaveChanges();
        }

        /// <summary>
        /// This method is used to get all categories present in database.
        /// </summary>
        /// <returns>Returns List of categories present in Database</returns>
        public IEnumerable<Category> GetAllCategories()
        {
            //Querying database to get list of category objects
            return categoryContext.Categories.ToList();
        }

        /// <summary>
        /// This method is used to get  Category present in database according to the category Id passed by user.
        /// </summary>
        /// <param name="categoryIdToSearch">This is category Id passed by the user to get information about particular Bus.</param>
        /// <returns>Returns the Category object found in database.</returns>
        public Category GetCategoryByCategoryId(int? categoryIdToSearch)
        {
            //Querying database to get the category whose  Id is passed to the method.
            if (categoryIdToSearch != null)
            {
                Category categoryFound = categoryContext.Categories.Find(categoryIdToSearch);
                if (categoryFound != null)
                {
                    return categoryFound;
                }
            }
            return null;
        }

        /// <summary>
        ///  This method is used to Update category present in database.
        /// </summary>
        /// <param name="categoryFromApi">This is the category object passed from client whose information needs to be updated in database.</param>
        public void UpdateCategory(Category categoryFromApi)
        {
            //Querying database to get the category by using category object passed by user.
            if (categoryFromApi != null)
            {
                //After getting database object whose category Id is same as Passed objects category Id, changing the 
                //category name in database object.
                //And Calling savechanges to reflect changes to database.
                Category categoryFromDb = categoryContext.Categories.Find(categoryFromApi.CategoryId);
                if (categoryFromDb != null)
                {
                    categoryFromDb.CategoryName = categoryFromApi.CategoryName;
                    categoryContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method is used to delete category present in database according to the category Id passed by user.
        /// </summary>
        /// <param name="categoryIdDelete">This is category Id passed by the user to delete particular category.</param>
        public void DeleteCategoryByCategoryId(int? categoryIdDelete)
        {
            //First getting the category Object using the id passed by user.
            //Then removing the category object which we got, using remove() method.
            //And Calling savechanges to reflect changes to database.
            if (categoryIdDelete != null)
            {
                Category categoryToDeleteFromDb = categoryContext.Categories.Find(categoryIdDelete);
                categoryContext.Categories.Remove(categoryToDeleteFromDb);
                categoryContext.SaveChanges();
            }
        }
    }
}
