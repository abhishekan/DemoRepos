﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class BusSeatAvailabilityRepository : IBusSeatAvailability
    {
        OnlineBusReservationEntities busSeatAvailabilityContext = new OnlineBusReservationEntities();
       
        public int GetBusSeatAvailability(int id, DateTime journeyDate)
        {
           var busSeat= busSeatAvailabilityContext.BusSeatAvailabilities.Where(bus=>bus.BusId==id)
                      .Where(bus=>bus.JourneyDate==journeyDate).FirstOrDefault();
            if(busSeat==null)
            {
                return 30;
            }
            else
            {
                return busSeat.AvailableSeats;
            }

        }

        public void UpdateBusSeatAvailability(BusSeatAvailability busFromBusRepository)
        {
            //Querying database to get the bus by using bus object passed by user.
            if (busFromBusRepository != null)
            {
                int id = busFromBusRepository.BusId;
                BusSeatAvailability busFromDb = busSeatAvailabilityContext.BusSeatAvailabilities.Where(bus=>bus.BusId==id)
                                               .Where(bus=>bus.JourneyDate==busFromBusRepository.JourneyDate).FirstOrDefault();

                //After getting database object whose Bus Id is same as Passed objects bus Id, changing the 
                //availableseats in database object by 1.
                //And Calling savechanges to reflect changes to database.
                if (busFromDb != null)
                {
                    var busFound = busSeatAvailabilityContext.BusSeatAvailabilities.Where(bus => bus.BusId == busFromDb.BusId).FirstOrDefault();
                    busFromDb.AvailableSeats = busFound.AvailableSeats - 1; 
                    busSeatAvailabilityContext.SaveChanges();
                }
                else {
                    BusSeatAvailability busEntryToAdd = new BusSeatAvailability();
                    busEntryToAdd.BusId = busFromBusRepository.BusId;
                    busEntryToAdd.AvailableSeats = busSeatAvailabilityContext.Buses.Find(busFromBusRepository.BusId).TotalSeats-1;
                    busEntryToAdd.JourneyDate = busFromBusRepository.JourneyDate;
                    busSeatAvailabilityContext.BusSeatAvailabilities.Add(busEntryToAdd);
                    busSeatAvailabilityContext.SaveChanges();
                }
            }
        }


    }
}
