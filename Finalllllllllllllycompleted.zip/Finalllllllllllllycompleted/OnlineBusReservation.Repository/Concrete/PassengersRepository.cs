﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class PassengersRepository : IPassengersRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities passengersContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new passenger to Database.
        /// </summary>
        /// <param name="passengerToAddToDb">This passenger Object which is passed By client will be inserted into Database.</param>  
        public void AddNewPassenger(Passenger passengerToAddToDb)
        {
            //Adding passenger object to database.And Calling savechanges to reflect changes to database.
            passengersContext.Passengers.Add(passengerToAddToDb);
            passengersContext.SaveChanges();
        }


        /// <summary>
        /// This method is used to get all passengers present in database.
        /// </summary>
        /// <returns>Returns List of passengers present in Database</returns>
        public IEnumerable<Passenger> GetAllPassengers()
        {
            //Querying database to get list of passengers objects
            return passengersContext.Passengers.ToList();
        }

        /// <summary>
        /// This method is used to get  passenger present in database according to the passenger Id passed by user.
        /// </summary>
        /// <param name="passengerIdToSearch">This is passenger Id passed by the user to get information about particular passenger.</param>
        /// <returns>Returns the passenger object found in database.</returns>
        public Passenger GetPassengerByPassengerId(int? passengerIdToSearch)
        {
            //Querying database to get the passenger whose  Id is passed to the method.
            if (passengerIdToSearch != null)
            {
                Passenger passengerFound = passengersContext.Passengers.Find(passengerIdToSearch);
                if (passengerFound != null)
                {
                    return passengerFound;
                }
            }
            return null;
        }

        //public void UpdatePassenger(Passenger passengerFromApi)
        //{
        //    if (passengerFromApi != null)
        //    {
        //        Passenger passengerFromDb = passengersContext.Passengers.Find(passengerFromApi.PassengerId);
        //        if (passengerFromDb != null)
        //        {
        //            passengerFromDb.ArrivalTime = passengerFromApi.ArrivalTime;
        //            passengerFromDb.DepartureTime = passengerFromApi.DepartureTime;
        //            passengerFromDb.RouteMasterId = passengerFromApi.RouteMasterId;
        //            passengersContext.SaveChanges();
        //        }
        //    }
        //}


        /// <summary>
        /// This method is used to delete passenger present in database according to the passenger Id passed by user.
        /// </summary>
        /// <param name="passengerIdToDelete">This is passenger Id passed by the user to delete particular passenger.</param>
        public void DeletePassengerByPassengerId(int? passengerIdToDelete)
        {
            //First getting the passenger Object using the id passed by user.
            //Then removing the passenger object which we got, using remove() method.
            //And Calling savechanges to reflect changes to database.
            if (passengerIdToDelete != null)
            {
                Passenger passengerToDeleteFromDb = passengersContext.Passengers.Find(passengerIdToDelete);
                passengersContext.Passengers.Remove(passengerToDeleteFromDb);
                passengersContext.SaveChanges();
            }
        }

    }
}
