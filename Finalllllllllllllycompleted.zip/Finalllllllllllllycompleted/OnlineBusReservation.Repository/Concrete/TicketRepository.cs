﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OnlineBusReservation.Repository.Concrete
{
    public class TicketRepository : ITicketRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities ticketContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new ticket to Database.
        /// </summary>
        /// <param name="ticketAddToDb">This ticket Object which is passed By client will be inserted into Database.</param>  
        public void AddNewTicket(Ticket ticketAddToDb)
        {
            //First finding all the seats already allocated from database passenger table.
            var seatArrangementIdToAllocate = (from s in ticketContext.SeatArrangements
                                               join t in ticketContext.Tickets
                                               on s.SeatArrangementId equals t.SeatArrangementId
                                               where t.SeatArrangementId == s.SeatArrangementId &&
                                               t.BusId==ticketAddToDb.BusId &&
                                               t.SubRouteId==ticketAddToDb.SubRouteId
                                               select t.SeatArrangementId).ToList();

            //Using the seat allocated for the bus we got in previous step, get the first empty seat.
            var seatArrangementForPassenger = (from seat in ticketContext.SeatArrangements
                                    select seat.SeatArrangementId).Except(seatArrangementIdToAllocate).FirstOrDefault();


            //if (seatForPassenger != 0)
            //Assigning that seat to the particular ticket, making status booked, save the ticket in database ticket table.
               ticketAddToDb.SeatArrangementId = seatArrangementForPassenger;
               ticketAddToDb.BookingStatus="Booked";

               ticketAddToDb.UserId = ticketAddToDb.UserId;
             
               ticketContext.Tickets.Add(ticketAddToDb);
               ticketContext.SaveChanges();
            
        }

        /// <summary>
        /// This method is used to get all tickets present in database.
        /// </summary>
        /// <returns>Returns List of tickets present in Database</returns>
        public IEnumerable<Ticket> GetAllTickets()
        {
            //Querying database to get list of ticket objects
            return ticketContext.Tickets.ToList();
        }

        /// <summary>
        /// This method is used to get  ticket present in database according to the ticket Id passed by user.
        /// </summary>
        /// <param name="ticketIdToSearch">This is ticket Id passed by the user to get information about particular ticket.</param>
        /// <returns>Returns the ticket object found in database.</returns>
        public IEnumerable<Ticket> GetTicketByUserName(string userId)
        {
            //Querying database to get the ticket whose ticket Id is passed to the method.
            if (userId != null)
            {
                IEnumerable<Ticket> ticketFound = ticketContext.Tickets.Where(ticket => ticket.UserId == userId).ToList();
                if (ticketFound != null)
                {
                    return ticketFound;
                }
            }
            return null;
        }

        public Ticket GetTicketByTicket(int ticketIdToSearch)
        {
            //Querying database to get the ticket whose ticket Id is passed to the method.
            if (ticketIdToSearch != null)
            {
                Ticket ticketFound = ticketContext.Tickets.Find(ticketIdToSearch);
                if (ticketFound != null)
                {
                    return ticketFound;
                }
            }
            return null;
        }

        //public Ticket GetTicketByTicketId(int ticketId)
        //{
        //    //Querying database to get the ticket whose ticket Id is passed to the method.
        //    if (ticketId != 0)
        //    {
        //        Ticket ticketFound = ticketContext.Tickets.Find(ticketId);
        //        if (ticketFound != null)
        //        {
        //            return ticketFound;
        //        }
        //    }
        //    return null;
        //}

        /// <summary>
        /// This method is used to get  ticket present in database according to the ticket Id and source passed by user.
        /// </summary>
        /// <param name="ticketNo">This is ticket Id passed by the user to get information about particular ticket.</param>
        /// <param name="source">This is the name of staion from which user wishes to travel.</param>
        /// <returns>Returns the ticket  found in database.</returns>
        public Ticket GetTicketByTicketNo(string ticketNo, string source)
        {
            //Querying database to get the ticket whose ticket No is passed to the method.
            if (ticketNo != null)
            {
                Ticket ticketFound = ticketContext.Tickets.Where(x=>x.TicketNo==ticketNo).FirstOrDefault();
                if (ticketFound != null)
                {
                    return ticketFound;
                }
            }
            return null;
        }

        /// <summary>
        ///  This method is used to Update ticket present in database.
        /// </summary>
        /// <param name="ticketFromApi">This is the ticket object passed from client whose information needs to be updated in database.</param>
        public void UpdateTicket(Ticket ticketFromApi)
        {
            //Querying database to get the ticket by using ticket object passed by user.
            if (ticketFromApi != null)
            {
                //After getting database object whose ticket Id is same as Passed objects ticket Id, changing the 
                //bookingstatus in database.
                //And Calling savechanges to reflect changes to database.
                Ticket ticketFromDb = ticketContext.Tickets.Find(ticketFromApi.TicketId);
                if (ticketFromDb != null)
                {
                    ticketFromDb.BookingStatus = ticketFromApi.BookingStatus;
                    
                    ticketContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method is used to delete  ticket present in database according to the ticket Id passed by user.
        /// </summary>
        /// <param name="ticketIdToDelete">This is ticket Id passed by the user to delete particular ticket.</param>
        public void DeleteTicketByTicketId(int? ticketIdToDelete)
        {
            //First getting the ticket Object using the id passed by user.
            //Then removing the ticket object which we got using remove() methos.
            //And Calling savechanges to reflect changes to database.
            if (ticketIdToDelete != null)
            {
                Ticket ticketToDeleteFromDb = ticketContext.Tickets.Find(ticketIdToDelete);
                ticketContext.Tickets.Remove(ticketToDeleteFromDb);
                ticketContext.SaveChanges();
            }
        }

        /// <summary>
        /// This method is used to get  ticket present in database according to the ticket no passed by user.
        /// </summary>
        /// <param name="ticketNo">This is ticket No passed by the user to get information about particular ticket.</param>
        public IEnumerable<Ticket> SearchTicketByTicketNo(string name)
        {
            //Querying the database to get ticket whose name is same that in database.
            IEnumerable<Ticket> search = ticketContext.Tickets.Where(bus => bus.TicketNo.Contains(name));
            return search;
        }

       
    }
}
