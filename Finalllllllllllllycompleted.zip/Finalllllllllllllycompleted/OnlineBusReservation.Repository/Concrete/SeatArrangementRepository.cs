﻿using OnlineBusReservation.Repository.Abstract;
using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Concrete
{
    public class SeatArrangementRepository : ISeatArrangementRepository
    {
        //Dbcontext class instance to access Database
        OnlineBusReservationEntities seatContext = new OnlineBusReservationEntities();

        /// <summary>
        /// This method is used to Add new seat to Database.
        /// </summary>
        /// <param name="seatAddToDb">This seat Object which is passed By client will be inserted into Database.</param>  
        public void AddNewSeat(SeatArrangement seatAddToDb)
        {
            //Adding seat object to database.And Calling savechanges to reflect changes to database.
            seatContext.SeatArrangements.Add(seatAddToDb);
            seatContext.SaveChanges();
        }

        /// <summary>
        /// This method is used to get all seats present in database.
        /// </summary>
        /// <returns>Returns List of seats present in Database</returns>
        public IEnumerable<SeatArrangement> GetAllSeats()
        {
            //Querying database to get list of seat objects
            return seatContext.SeatArrangements.ToList();
        }

        /// <summary>
        /// This method is used to get  seat present in database according to the seat Id passed by user.
        /// </summary>
        /// <param name="seatIdToSearch">This is seat Id passed by the user to get information about particular seat.</param>
        /// <returns>Returns the seat object found in database.</returns>
        public SeatArrangement GetSeatBySeatId(int? seatIdToSearch)
        {
            //Querying database to get the seat whose  Id is passed to the method.
            if (seatIdToSearch != null)
            {
                SeatArrangement seatFound = seatContext.SeatArrangements.Find(seatIdToSearch);
                if (seatFound != null)
                {
                    return seatFound;
                }
            }
            return null;
        }

        public IEnumerable<Ticket> GetSeatByBusIDAndDateOfBooking(int busId, DateTime dateOfBooking)
        {
            if (busId != 0)
            {

                IEnumerable<Ticket> seatToReturn = seatContext.Tickets
                                                  .Where(seat => seat.BusId == busId)
                                                  .Where(seat=>seat.JourneyDate==dateOfBooking).ToList();
                if(seatToReturn!=null)
                {
                    return seatToReturn;
                }
            }
            return null;
        }

        /// <summary>
        ///  This method is used to Update seat present in database.
        /// </summary>
        /// <param name="seatFromApi">This is the seat object passed from client whose information needs to be updated in database.</param>
        public void UpdateSeatArrangement(SeatArrangement seatFromApi)
        {
            //Querying database to get the seat by using seat object passed by user.
            if (seatFromApi != null)
            {
                //After getting database object whose seat Id is same as Passed objects seat Id, changing the 
                //seat number in database object.
                //And Calling savechanges to reflect changes to database.
                SeatArrangement seatFromDb = seatContext.SeatArrangements.Find(seatFromApi.SeatArrangementId);
                if (seatFromDb != null)
                {
                    seatFromDb.SeatNumber = seatFromApi.SeatNumber;
                  
                    seatContext.SaveChanges();
                }
            }
        }

        /// <summary>
        /// This method is used to delete seat present in database according to the seat Id passed by user.
        /// </summary>
        /// <param name="seatIdToDelete">This is seat Id passed by the user to delete particular seat.</param>
        public void DeleteSeatBySeatId(int? seatIdToDelete)
        {
            //First getting the seat Object using the id passed by user.
            //Then removing the seat object which we got, using remove() method.
            //And Calling savechanges to reflect changes to database.
            if (seatIdToDelete != null)
            {
                SeatArrangement seatToDeleteFromDb = seatContext.SeatArrangements.Find(seatIdToDelete);
                seatContext.SeatArrangements.Remove(seatToDeleteFromDb);
                seatContext.SaveChanges();
            }
        }

    }
}
