﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface IBusSeatAvailability
    {
        int GetBusSeatAvailability(int id, DateTime journeyDate);
        void UpdateBusSeatAvailability(BusSeatAvailability busFromBusRepository);
    }
}
