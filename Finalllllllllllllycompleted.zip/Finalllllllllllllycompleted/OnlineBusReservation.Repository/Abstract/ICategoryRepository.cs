﻿using OnlineBusReservation.Repository.EntityDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBusReservation.Repository.Abstract
{
    public interface ICategoryRepository
    {
        void AddNewCategory(Category categoryAddToDb);
        IEnumerable<Category> GetAllCategories();
        Category GetCategoryByCategoryId(int? categoryIdToSearch);
        void UpdateCategory(Category categoryFromApi);
        void DeleteCategoryByCategoryId(int? categoryIdDelete);

    }
}
